* SANKHYA synthetic large sparse LP - issue #18
* rows=3000 cols=3000 nnz_per_col=5 seed=7
* Built backwards from a known KKT-satisfying primal-dual pair (see this file's
* generate_large_lp.py docstring, same construction as tests/oracles/lp_generator
* .cpp's kkt_lp). Reproduce with the seed above; analytic optimum below is exact.
* analytic optimum = 10329
* structure = staircase, 15 periods
NAME          LARGELP
ROWS
 N  COST
 G  R0
 G  R1
 G  R2
 G  R3
 G  R4
 G  R5
 G  R6
 G  R7
 G  R8
 G  R9
 G  R10
 G  R11
 G  R12
 G  R13
 G  R14
 G  R15
 G  R16
 G  R17
 G  R18
 G  R19
 G  R20
 G  R21
 G  R22
 G  R23
 G  R24
 G  R25
 G  R26
 G  R27
 G  R28
 G  R29
 G  R30
 G  R31
 G  R32
 G  R33
 G  R34
 G  R35
 G  R36
 G  R37
 G  R38
 G  R39
 G  R40
 G  R41
 G  R42
 G  R43
 G  R44
 G  R45
 G  R46
 G  R47
 G  R48
 G  R49
 G  R50
 G  R51
 G  R52
 G  R53
 G  R54
 G  R55
 G  R56
 G  R57
 G  R58
 G  R59
 G  R60
 G  R61
 G  R62
 G  R63
 G  R64
 G  R65
 G  R66
 G  R67
 G  R68
 G  R69
 G  R70
 G  R71
 G  R72
 G  R73
 G  R74
 G  R75
 G  R76
 G  R77
 G  R78
 G  R79
 G  R80
 G  R81
 G  R82
 G  R83
 G  R84
 G  R85
 G  R86
 G  R87
 G  R88
 G  R89
 G  R90
 G  R91
 G  R92
 G  R93
 G  R94
 G  R95
 G  R96
 G  R97
 G  R98
 G  R99
 G  R100
 G  R101
 G  R102
 G  R103
 G  R104
 G  R105
 G  R106
 G  R107
 G  R108
 G  R109
 G  R110
 G  R111
 G  R112
 G  R113
 G  R114
 G  R115
 G  R116
 G  R117
 G  R118
 G  R119
 G  R120
 G  R121
 G  R122
 G  R123
 G  R124
 G  R125
 G  R126
 G  R127
 G  R128
 G  R129
 G  R130
 G  R131
 G  R132
 G  R133
 G  R134
 G  R135
 G  R136
 G  R137
 G  R138
 G  R139
 G  R140
 G  R141
 G  R142
 G  R143
 G  R144
 G  R145
 G  R146
 G  R147
 G  R148
 G  R149
 G  R150
 G  R151
 G  R152
 G  R153
 G  R154
 G  R155
 G  R156
 G  R157
 G  R158
 G  R159
 G  R160
 G  R161
 G  R162
 G  R163
 G  R164
 G  R165
 G  R166
 G  R167
 G  R168
 G  R169
 G  R170
 G  R171
 G  R172
 G  R173
 G  R174
 G  R175
 G  R176
 G  R177
 G  R178
 G  R179
 G  R180
 G  R181
 G  R182
 G  R183
 G  R184
 G  R185
 G  R186
 G  R187
 G  R188
 G  R189
 G  R190
 G  R191
 G  R192
 G  R193
 G  R194
 G  R195
 G  R196
 G  R197
 G  R198
 G  R199
 G  R200
 G  R201
 G  R202
 G  R203
 G  R204
 G  R205
 G  R206
 G  R207
 G  R208
 G  R209
 G  R210
 G  R211
 G  R212
 G  R213
 G  R214
 G  R215
 G  R216
 G  R217
 G  R218
 G  R219
 G  R220
 G  R221
 G  R222
 G  R223
 G  R224
 G  R225
 G  R226
 G  R227
 G  R228
 G  R229
 G  R230
 G  R231
 G  R232
 G  R233
 G  R234
 G  R235
 G  R236
 G  R237
 G  R238
 G  R239
 G  R240
 G  R241
 G  R242
 G  R243
 G  R244
 G  R245
 G  R246
 G  R247
 G  R248
 G  R249
 G  R250
 G  R251
 G  R252
 G  R253
 G  R254
 G  R255
 G  R256
 G  R257
 G  R258
 G  R259
 G  R260
 G  R261
 G  R262
 G  R263
 G  R264
 G  R265
 G  R266
 G  R267
 G  R268
 G  R269
 G  R270
 G  R271
 G  R272
 G  R273
 G  R274
 G  R275
 G  R276
 G  R277
 G  R278
 G  R279
 G  R280
 G  R281
 G  R282
 G  R283
 G  R284
 G  R285
 G  R286
 G  R287
 G  R288
 G  R289
 G  R290
 G  R291
 G  R292
 G  R293
 G  R294
 G  R295
 G  R296
 G  R297
 G  R298
 G  R299
 G  R300
 G  R301
 G  R302
 G  R303
 G  R304
 G  R305
 G  R306
 G  R307
 G  R308
 G  R309
 G  R310
 G  R311
 G  R312
 G  R313
 G  R314
 G  R315
 G  R316
 G  R317
 G  R318
 G  R319
 G  R320
 G  R321
 G  R322
 G  R323
 G  R324
 G  R325
 G  R326
 G  R327
 G  R328
 G  R329
 G  R330
 G  R331
 G  R332
 G  R333
 G  R334
 G  R335
 G  R336
 G  R337
 G  R338
 G  R339
 G  R340
 G  R341
 G  R342
 G  R343
 G  R344
 G  R345
 G  R346
 G  R347
 G  R348
 G  R349
 G  R350
 G  R351
 G  R352
 G  R353
 G  R354
 G  R355
 G  R356
 G  R357
 G  R358
 G  R359
 G  R360
 G  R361
 G  R362
 G  R363
 G  R364
 G  R365
 G  R366
 G  R367
 G  R368
 G  R369
 G  R370
 G  R371
 G  R372
 G  R373
 G  R374
 G  R375
 G  R376
 G  R377
 G  R378
 G  R379
 G  R380
 G  R381
 G  R382
 G  R383
 G  R384
 G  R385
 G  R386
 G  R387
 G  R388
 G  R389
 G  R390
 G  R391
 G  R392
 G  R393
 G  R394
 G  R395
 G  R396
 G  R397
 G  R398
 G  R399
 G  R400
 G  R401
 G  R402
 G  R403
 G  R404
 G  R405
 G  R406
 G  R407
 G  R408
 G  R409
 G  R410
 G  R411
 G  R412
 G  R413
 G  R414
 G  R415
 G  R416
 G  R417
 G  R418
 G  R419
 G  R420
 G  R421
 G  R422
 G  R423
 G  R424
 G  R425
 G  R426
 G  R427
 G  R428
 G  R429
 G  R430
 G  R431
 G  R432
 G  R433
 G  R434
 G  R435
 G  R436
 G  R437
 G  R438
 G  R439
 G  R440
 G  R441
 G  R442
 G  R443
 G  R444
 G  R445
 G  R446
 G  R447
 G  R448
 G  R449
 G  R450
 G  R451
 G  R452
 G  R453
 G  R454
 G  R455
 G  R456
 G  R457
 G  R458
 G  R459
 G  R460
 G  R461
 G  R462
 G  R463
 G  R464
 G  R465
 G  R466
 G  R467
 G  R468
 G  R469
 G  R470
 G  R471
 G  R472
 G  R473
 G  R474
 G  R475
 G  R476
 G  R477
 G  R478
 G  R479
 G  R480
 G  R481
 G  R482
 G  R483
 G  R484
 G  R485
 G  R486
 G  R487
 G  R488
 G  R489
 G  R490
 G  R491
 G  R492
 G  R493
 G  R494
 G  R495
 G  R496
 G  R497
 G  R498
 G  R499
 G  R500
 G  R501
 G  R502
 G  R503
 G  R504
 G  R505
 G  R506
 G  R507
 G  R508
 G  R509
 G  R510
 G  R511
 G  R512
 G  R513
 G  R514
 G  R515
 G  R516
 G  R517
 G  R518
 G  R519
 G  R520
 G  R521
 G  R522
 G  R523
 G  R524
 G  R525
 G  R526
 G  R527
 G  R528
 G  R529
 G  R530
 G  R531
 G  R532
 G  R533
 G  R534
 G  R535
 G  R536
 G  R537
 G  R538
 G  R539
 G  R540
 G  R541
 G  R542
 G  R543
 G  R544
 G  R545
 G  R546
 G  R547
 G  R548
 G  R549
 G  R550
 G  R551
 G  R552
 G  R553
 G  R554
 G  R555
 G  R556
 G  R557
 G  R558
 G  R559
 G  R560
 G  R561
 G  R562
 G  R563
 G  R564
 G  R565
 G  R566
 G  R567
 G  R568
 G  R569
 G  R570
 G  R571
 G  R572
 G  R573
 G  R574
 G  R575
 G  R576
 G  R577
 G  R578
 G  R579
 G  R580
 G  R581
 G  R582
 G  R583
 G  R584
 G  R585
 G  R586
 G  R587
 G  R588
 G  R589
 G  R590
 G  R591
 G  R592
 G  R593
 G  R594
 G  R595
 G  R596
 G  R597
 G  R598
 G  R599
 G  R600
 G  R601
 G  R602
 G  R603
 G  R604
 G  R605
 G  R606
 G  R607
 G  R608
 G  R609
 G  R610
 G  R611
 G  R612
 G  R613
 G  R614
 G  R615
 G  R616
 G  R617
 G  R618
 G  R619
 G  R620
 G  R621
 G  R622
 G  R623
 G  R624
 G  R625
 G  R626
 G  R627
 G  R628
 G  R629
 G  R630
 G  R631
 G  R632
 G  R633
 G  R634
 G  R635
 G  R636
 G  R637
 G  R638
 G  R639
 G  R640
 G  R641
 G  R642
 G  R643
 G  R644
 G  R645
 G  R646
 G  R647
 G  R648
 G  R649
 G  R650
 G  R651
 G  R652
 G  R653
 G  R654
 G  R655
 G  R656
 G  R657
 G  R658
 G  R659
 G  R660
 G  R661
 G  R662
 G  R663
 G  R664
 G  R665
 G  R666
 G  R667
 G  R668
 G  R669
 G  R670
 G  R671
 G  R672
 G  R673
 G  R674
 G  R675
 G  R676
 G  R677
 G  R678
 G  R679
 G  R680
 G  R681
 G  R682
 G  R683
 G  R684
 G  R685
 G  R686
 G  R687
 G  R688
 G  R689
 G  R690
 G  R691
 G  R692
 G  R693
 G  R694
 G  R695
 G  R696
 G  R697
 G  R698
 G  R699
 G  R700
 G  R701
 G  R702
 G  R703
 G  R704
 G  R705
 G  R706
 G  R707
 G  R708
 G  R709
 G  R710
 G  R711
 G  R712
 G  R713
 G  R714
 G  R715
 G  R716
 G  R717
 G  R718
 G  R719
 G  R720
 G  R721
 G  R722
 G  R723
 G  R724
 G  R725
 G  R726
 G  R727
 G  R728
 G  R729
 G  R730
 G  R731
 G  R732
 G  R733
 G  R734
 G  R735
 G  R736
 G  R737
 G  R738
 G  R739
 G  R740
 G  R741
 G  R742
 G  R743
 G  R744
 G  R745
 G  R746
 G  R747
 G  R748
 G  R749
 G  R750
 G  R751
 G  R752
 G  R753
 G  R754
 G  R755
 G  R756
 G  R757
 G  R758
 G  R759
 G  R760
 G  R761
 G  R762
 G  R763
 G  R764
 G  R765
 G  R766
 G  R767
 G  R768
 G  R769
 G  R770
 G  R771
 G  R772
 G  R773
 G  R774
 G  R775
 G  R776
 G  R777
 G  R778
 G  R779
 G  R780
 G  R781
 G  R782
 G  R783
 G  R784
 G  R785
 G  R786
 G  R787
 G  R788
 G  R789
 G  R790
 G  R791
 G  R792
 G  R793
 G  R794
 G  R795
 G  R796
 G  R797
 G  R798
 G  R799
 G  R800
 G  R801
 G  R802
 G  R803
 G  R804
 G  R805
 G  R806
 G  R807
 G  R808
 G  R809
 G  R810
 G  R811
 G  R812
 G  R813
 G  R814
 G  R815
 G  R816
 G  R817
 G  R818
 G  R819
 G  R820
 G  R821
 G  R822
 G  R823
 G  R824
 G  R825
 G  R826
 G  R827
 G  R828
 G  R829
 G  R830
 G  R831
 G  R832
 G  R833
 G  R834
 G  R835
 G  R836
 G  R837
 G  R838
 G  R839
 G  R840
 G  R841
 G  R842
 G  R843
 G  R844
 G  R845
 G  R846
 G  R847
 G  R848
 G  R849
 G  R850
 G  R851
 G  R852
 G  R853
 G  R854
 G  R855
 G  R856
 G  R857
 G  R858
 G  R859
 G  R860
 G  R861
 G  R862
 G  R863
 G  R864
 G  R865
 G  R866
 G  R867
 G  R868
 G  R869
 G  R870
 G  R871
 G  R872
 G  R873
 G  R874
 G  R875
 G  R876
 G  R877
 G  R878
 G  R879
 G  R880
 G  R881
 G  R882
 G  R883
 G  R884
 G  R885
 G  R886
 G  R887
 G  R888
 G  R889
 G  R890
 G  R891
 G  R892
 G  R893
 G  R894
 G  R895
 G  R896
 G  R897
 G  R898
 G  R899
 G  R900
 G  R901
 G  R902
 G  R903
 G  R904
 G  R905
 G  R906
 G  R907
 G  R908
 G  R909
 G  R910
 G  R911
 G  R912
 G  R913
 G  R914
 G  R915
 G  R916
 G  R917
 G  R918
 G  R919
 G  R920
 G  R921
 G  R922
 G  R923
 G  R924
 G  R925
 G  R926
 G  R927
 G  R928
 G  R929
 G  R930
 G  R931
 G  R932
 G  R933
 G  R934
 G  R935
 G  R936
 G  R937
 G  R938
 G  R939
 G  R940
 G  R941
 G  R942
 G  R943
 G  R944
 G  R945
 G  R946
 G  R947
 G  R948
 G  R949
 G  R950
 G  R951
 G  R952
 G  R953
 G  R954
 G  R955
 G  R956
 G  R957
 G  R958
 G  R959
 G  R960
 G  R961
 G  R962
 G  R963
 G  R964
 G  R965
 G  R966
 G  R967
 G  R968
 G  R969
 G  R970
 G  R971
 G  R972
 G  R973
 G  R974
 G  R975
 G  R976
 G  R977
 G  R978
 G  R979
 G  R980
 G  R981
 G  R982
 G  R983
 G  R984
 G  R985
 G  R986
 G  R987
 G  R988
 G  R989
 G  R990
 G  R991
 G  R992
 G  R993
 G  R994
 G  R995
 G  R996
 G  R997
 G  R998
 G  R999
 G  R1000
 G  R1001
 G  R1002
 G  R1003
 G  R1004
 G  R1005
 G  R1006
 G  R1007
 G  R1008
 G  R1009
 G  R1010
 G  R1011
 G  R1012
 G  R1013
 G  R1014
 G  R1015
 G  R1016
 G  R1017
 G  R1018
 G  R1019
 G  R1020
 G  R1021
 G  R1022
 G  R1023
 G  R1024
 G  R1025
 G  R1026
 G  R1027
 G  R1028
 G  R1029
 G  R1030
 G  R1031
 G  R1032
 G  R1033
 G  R1034
 G  R1035
 G  R1036
 G  R1037
 G  R1038
 G  R1039
 G  R1040
 G  R1041
 G  R1042
 G  R1043
 G  R1044
 G  R1045
 G  R1046
 G  R1047
 G  R1048
 G  R1049
 G  R1050
 G  R1051
 G  R1052
 G  R1053
 G  R1054
 G  R1055
 G  R1056
 G  R1057
 G  R1058
 G  R1059
 G  R1060
 G  R1061
 G  R1062
 G  R1063
 G  R1064
 G  R1065
 G  R1066
 G  R1067
 G  R1068
 G  R1069
 G  R1070
 G  R1071
 G  R1072
 G  R1073
 G  R1074
 G  R1075
 G  R1076
 G  R1077
 G  R1078
 G  R1079
 G  R1080
 G  R1081
 G  R1082
 G  R1083
 G  R1084
 G  R1085
 G  R1086
 G  R1087
 G  R1088
 G  R1089
 G  R1090
 G  R1091
 G  R1092
 G  R1093
 G  R1094
 G  R1095
 G  R1096
 G  R1097
 G  R1098
 G  R1099
 G  R1100
 G  R1101
 G  R1102
 G  R1103
 G  R1104
 G  R1105
 G  R1106
 G  R1107
 G  R1108
 G  R1109
 G  R1110
 G  R1111
 G  R1112
 G  R1113
 G  R1114
 G  R1115
 G  R1116
 G  R1117
 G  R1118
 G  R1119
 G  R1120
 G  R1121
 G  R1122
 G  R1123
 G  R1124
 G  R1125
 G  R1126
 G  R1127
 G  R1128
 G  R1129
 G  R1130
 G  R1131
 G  R1132
 G  R1133
 G  R1134
 G  R1135
 G  R1136
 G  R1137
 G  R1138
 G  R1139
 G  R1140
 G  R1141
 G  R1142
 G  R1143
 G  R1144
 G  R1145
 G  R1146
 G  R1147
 G  R1148
 G  R1149
 G  R1150
 G  R1151
 G  R1152
 G  R1153
 G  R1154
 G  R1155
 G  R1156
 G  R1157
 G  R1158
 G  R1159
 G  R1160
 G  R1161
 G  R1162
 G  R1163
 G  R1164
 G  R1165
 G  R1166
 G  R1167
 G  R1168
 G  R1169
 G  R1170
 G  R1171
 G  R1172
 G  R1173
 G  R1174
 G  R1175
 G  R1176
 G  R1177
 G  R1178
 G  R1179
 G  R1180
 G  R1181
 G  R1182
 G  R1183
 G  R1184
 G  R1185
 G  R1186
 G  R1187
 G  R1188
 G  R1189
 G  R1190
 G  R1191
 G  R1192
 G  R1193
 G  R1194
 G  R1195
 G  R1196
 G  R1197
 G  R1198
 G  R1199
 G  R1200
 G  R1201
 G  R1202
 G  R1203
 G  R1204
 G  R1205
 G  R1206
 G  R1207
 G  R1208
 G  R1209
 G  R1210
 G  R1211
 G  R1212
 G  R1213
 G  R1214
 G  R1215
 G  R1216
 G  R1217
 G  R1218
 G  R1219
 G  R1220
 G  R1221
 G  R1222
 G  R1223
 G  R1224
 G  R1225
 G  R1226
 G  R1227
 G  R1228
 G  R1229
 G  R1230
 G  R1231
 G  R1232
 G  R1233
 G  R1234
 G  R1235
 G  R1236
 G  R1237
 G  R1238
 G  R1239
 G  R1240
 G  R1241
 G  R1242
 G  R1243
 G  R1244
 G  R1245
 G  R1246
 G  R1247
 G  R1248
 G  R1249
 G  R1250
 G  R1251
 G  R1252
 G  R1253
 G  R1254
 G  R1255
 G  R1256
 G  R1257
 G  R1258
 G  R1259
 G  R1260
 G  R1261
 G  R1262
 G  R1263
 G  R1264
 G  R1265
 G  R1266
 G  R1267
 G  R1268
 G  R1269
 G  R1270
 G  R1271
 G  R1272
 G  R1273
 G  R1274
 G  R1275
 G  R1276
 G  R1277
 G  R1278
 G  R1279
 G  R1280
 G  R1281
 G  R1282
 G  R1283
 G  R1284
 G  R1285
 G  R1286
 G  R1287
 G  R1288
 G  R1289
 G  R1290
 G  R1291
 G  R1292
 G  R1293
 G  R1294
 G  R1295
 G  R1296
 G  R1297
 G  R1298
 G  R1299
 G  R1300
 G  R1301
 G  R1302
 G  R1303
 G  R1304
 G  R1305
 G  R1306
 G  R1307
 G  R1308
 G  R1309
 G  R1310
 G  R1311
 G  R1312
 G  R1313
 G  R1314
 G  R1315
 G  R1316
 G  R1317
 G  R1318
 G  R1319
 G  R1320
 G  R1321
 G  R1322
 G  R1323
 G  R1324
 G  R1325
 G  R1326
 G  R1327
 G  R1328
 G  R1329
 G  R1330
 G  R1331
 G  R1332
 G  R1333
 G  R1334
 G  R1335
 G  R1336
 G  R1337
 G  R1338
 G  R1339
 G  R1340
 G  R1341
 G  R1342
 G  R1343
 G  R1344
 G  R1345
 G  R1346
 G  R1347
 G  R1348
 G  R1349
 G  R1350
 G  R1351
 G  R1352
 G  R1353
 G  R1354
 G  R1355
 G  R1356
 G  R1357
 G  R1358
 G  R1359
 G  R1360
 G  R1361
 G  R1362
 G  R1363
 G  R1364
 G  R1365
 G  R1366
 G  R1367
 G  R1368
 G  R1369
 G  R1370
 G  R1371
 G  R1372
 G  R1373
 G  R1374
 G  R1375
 G  R1376
 G  R1377
 G  R1378
 G  R1379
 G  R1380
 G  R1381
 G  R1382
 G  R1383
 G  R1384
 G  R1385
 G  R1386
 G  R1387
 G  R1388
 G  R1389
 G  R1390
 G  R1391
 G  R1392
 G  R1393
 G  R1394
 G  R1395
 G  R1396
 G  R1397
 G  R1398
 G  R1399
 G  R1400
 G  R1401
 G  R1402
 G  R1403
 G  R1404
 G  R1405
 G  R1406
 G  R1407
 G  R1408
 G  R1409
 G  R1410
 G  R1411
 G  R1412
 G  R1413
 G  R1414
 G  R1415
 G  R1416
 G  R1417
 G  R1418
 G  R1419
 G  R1420
 G  R1421
 G  R1422
 G  R1423
 G  R1424
 G  R1425
 G  R1426
 G  R1427
 G  R1428
 G  R1429
 G  R1430
 G  R1431
 G  R1432
 G  R1433
 G  R1434
 G  R1435
 G  R1436
 G  R1437
 G  R1438
 G  R1439
 G  R1440
 G  R1441
 G  R1442
 G  R1443
 G  R1444
 G  R1445
 G  R1446
 G  R1447
 G  R1448
 G  R1449
 G  R1450
 G  R1451
 G  R1452
 G  R1453
 G  R1454
 G  R1455
 G  R1456
 G  R1457
 G  R1458
 G  R1459
 G  R1460
 G  R1461
 G  R1462
 G  R1463
 G  R1464
 G  R1465
 G  R1466
 G  R1467
 G  R1468
 G  R1469
 G  R1470
 G  R1471
 G  R1472
 G  R1473
 G  R1474
 G  R1475
 G  R1476
 G  R1477
 G  R1478
 G  R1479
 G  R1480
 G  R1481
 G  R1482
 G  R1483
 G  R1484
 G  R1485
 G  R1486
 G  R1487
 G  R1488
 G  R1489
 G  R1490
 G  R1491
 G  R1492
 G  R1493
 G  R1494
 G  R1495
 G  R1496
 G  R1497
 G  R1498
 G  R1499
 G  R1500
 G  R1501
 G  R1502
 G  R1503
 G  R1504
 G  R1505
 G  R1506
 G  R1507
 G  R1508
 G  R1509
 G  R1510
 G  R1511
 G  R1512
 G  R1513
 G  R1514
 G  R1515
 G  R1516
 G  R1517
 G  R1518
 G  R1519
 G  R1520
 G  R1521
 G  R1522
 G  R1523
 G  R1524
 G  R1525
 G  R1526
 G  R1527
 G  R1528
 G  R1529
 G  R1530
 G  R1531
 G  R1532
 G  R1533
 G  R1534
 G  R1535
 G  R1536
 G  R1537
 G  R1538
 G  R1539
 G  R1540
 G  R1541
 G  R1542
 G  R1543
 G  R1544
 G  R1545
 G  R1546
 G  R1547
 G  R1548
 G  R1549
 G  R1550
 G  R1551
 G  R1552
 G  R1553
 G  R1554
 G  R1555
 G  R1556
 G  R1557
 G  R1558
 G  R1559
 G  R1560
 G  R1561
 G  R1562
 G  R1563
 G  R1564
 G  R1565
 G  R1566
 G  R1567
 G  R1568
 G  R1569
 G  R1570
 G  R1571
 G  R1572
 G  R1573
 G  R1574
 G  R1575
 G  R1576
 G  R1577
 G  R1578
 G  R1579
 G  R1580
 G  R1581
 G  R1582
 G  R1583
 G  R1584
 G  R1585
 G  R1586
 G  R1587
 G  R1588
 G  R1589
 G  R1590
 G  R1591
 G  R1592
 G  R1593
 G  R1594
 G  R1595
 G  R1596
 G  R1597
 G  R1598
 G  R1599
 G  R1600
 G  R1601
 G  R1602
 G  R1603
 G  R1604
 G  R1605
 G  R1606
 G  R1607
 G  R1608
 G  R1609
 G  R1610
 G  R1611
 G  R1612
 G  R1613
 G  R1614
 G  R1615
 G  R1616
 G  R1617
 G  R1618
 G  R1619
 G  R1620
 G  R1621
 G  R1622
 G  R1623
 G  R1624
 G  R1625
 G  R1626
 G  R1627
 G  R1628
 G  R1629
 G  R1630
 G  R1631
 G  R1632
 G  R1633
 G  R1634
 G  R1635
 G  R1636
 G  R1637
 G  R1638
 G  R1639
 G  R1640
 G  R1641
 G  R1642
 G  R1643
 G  R1644
 G  R1645
 G  R1646
 G  R1647
 G  R1648
 G  R1649
 G  R1650
 G  R1651
 G  R1652
 G  R1653
 G  R1654
 G  R1655
 G  R1656
 G  R1657
 G  R1658
 G  R1659
 G  R1660
 G  R1661
 G  R1662
 G  R1663
 G  R1664
 G  R1665
 G  R1666
 G  R1667
 G  R1668
 G  R1669
 G  R1670
 G  R1671
 G  R1672
 G  R1673
 G  R1674
 G  R1675
 G  R1676
 G  R1677
 G  R1678
 G  R1679
 G  R1680
 G  R1681
 G  R1682
 G  R1683
 G  R1684
 G  R1685
 G  R1686
 G  R1687
 G  R1688
 G  R1689
 G  R1690
 G  R1691
 G  R1692
 G  R1693
 G  R1694
 G  R1695
 G  R1696
 G  R1697
 G  R1698
 G  R1699
 G  R1700
 G  R1701
 G  R1702
 G  R1703
 G  R1704
 G  R1705
 G  R1706
 G  R1707
 G  R1708
 G  R1709
 G  R1710
 G  R1711
 G  R1712
 G  R1713
 G  R1714
 G  R1715
 G  R1716
 G  R1717
 G  R1718
 G  R1719
 G  R1720
 G  R1721
 G  R1722
 G  R1723
 G  R1724
 G  R1725
 G  R1726
 G  R1727
 G  R1728
 G  R1729
 G  R1730
 G  R1731
 G  R1732
 G  R1733
 G  R1734
 G  R1735
 G  R1736
 G  R1737
 G  R1738
 G  R1739
 G  R1740
 G  R1741
 G  R1742
 G  R1743
 G  R1744
 G  R1745
 G  R1746
 G  R1747
 G  R1748
 G  R1749
 G  R1750
 G  R1751
 G  R1752
 G  R1753
 G  R1754
 G  R1755
 G  R1756
 G  R1757
 G  R1758
 G  R1759
 G  R1760
 G  R1761
 G  R1762
 G  R1763
 G  R1764
 G  R1765
 G  R1766
 G  R1767
 G  R1768
 G  R1769
 G  R1770
 G  R1771
 G  R1772
 G  R1773
 G  R1774
 G  R1775
 G  R1776
 G  R1777
 G  R1778
 G  R1779
 G  R1780
 G  R1781
 G  R1782
 G  R1783
 G  R1784
 G  R1785
 G  R1786
 G  R1787
 G  R1788
 G  R1789
 G  R1790
 G  R1791
 G  R1792
 G  R1793
 G  R1794
 G  R1795
 G  R1796
 G  R1797
 G  R1798
 G  R1799
 G  R1800
 G  R1801
 G  R1802
 G  R1803
 G  R1804
 G  R1805
 G  R1806
 G  R1807
 G  R1808
 G  R1809
 G  R1810
 G  R1811
 G  R1812
 G  R1813
 G  R1814
 G  R1815
 G  R1816
 G  R1817
 G  R1818
 G  R1819
 G  R1820
 G  R1821
 G  R1822
 G  R1823
 G  R1824
 G  R1825
 G  R1826
 G  R1827
 G  R1828
 G  R1829
 G  R1830
 G  R1831
 G  R1832
 G  R1833
 G  R1834
 G  R1835
 G  R1836
 G  R1837
 G  R1838
 G  R1839
 G  R1840
 G  R1841
 G  R1842
 G  R1843
 G  R1844
 G  R1845
 G  R1846
 G  R1847
 G  R1848
 G  R1849
 G  R1850
 G  R1851
 G  R1852
 G  R1853
 G  R1854
 G  R1855
 G  R1856
 G  R1857
 G  R1858
 G  R1859
 G  R1860
 G  R1861
 G  R1862
 G  R1863
 G  R1864
 G  R1865
 G  R1866
 G  R1867
 G  R1868
 G  R1869
 G  R1870
 G  R1871
 G  R1872
 G  R1873
 G  R1874
 G  R1875
 G  R1876
 G  R1877
 G  R1878
 G  R1879
 G  R1880
 G  R1881
 G  R1882
 G  R1883
 G  R1884
 G  R1885
 G  R1886
 G  R1887
 G  R1888
 G  R1889
 G  R1890
 G  R1891
 G  R1892
 G  R1893
 G  R1894
 G  R1895
 G  R1896
 G  R1897
 G  R1898
 G  R1899
 G  R1900
 G  R1901
 G  R1902
 G  R1903
 G  R1904
 G  R1905
 G  R1906
 G  R1907
 G  R1908
 G  R1909
 G  R1910
 G  R1911
 G  R1912
 G  R1913
 G  R1914
 G  R1915
 G  R1916
 G  R1917
 G  R1918
 G  R1919
 G  R1920
 G  R1921
 G  R1922
 G  R1923
 G  R1924
 G  R1925
 G  R1926
 G  R1927
 G  R1928
 G  R1929
 G  R1930
 G  R1931
 G  R1932
 G  R1933
 G  R1934
 G  R1935
 G  R1936
 G  R1937
 G  R1938
 G  R1939
 G  R1940
 G  R1941
 G  R1942
 G  R1943
 G  R1944
 G  R1945
 G  R1946
 G  R1947
 G  R1948
 G  R1949
 G  R1950
 G  R1951
 G  R1952
 G  R1953
 G  R1954
 G  R1955
 G  R1956
 G  R1957
 G  R1958
 G  R1959
 G  R1960
 G  R1961
 G  R1962
 G  R1963
 G  R1964
 G  R1965
 G  R1966
 G  R1967
 G  R1968
 G  R1969
 G  R1970
 G  R1971
 G  R1972
 G  R1973
 G  R1974
 G  R1975
 G  R1976
 G  R1977
 G  R1978
 G  R1979
 G  R1980
 G  R1981
 G  R1982
 G  R1983
 G  R1984
 G  R1985
 G  R1986
 G  R1987
 G  R1988
 G  R1989
 G  R1990
 G  R1991
 G  R1992
 G  R1993
 G  R1994
 G  R1995
 G  R1996
 G  R1997
 G  R1998
 G  R1999
 G  R2000
 G  R2001
 G  R2002
 G  R2003
 G  R2004
 G  R2005
 G  R2006
 G  R2007
 G  R2008
 G  R2009
 G  R2010
 G  R2011
 G  R2012
 G  R2013
 G  R2014
 G  R2015
 G  R2016
 G  R2017
 G  R2018
 G  R2019
 G  R2020
 G  R2021
 G  R2022
 G  R2023
 G  R2024
 G  R2025
 G  R2026
 G  R2027
 G  R2028
 G  R2029
 G  R2030
 G  R2031
 G  R2032
 G  R2033
 G  R2034
 G  R2035
 G  R2036
 G  R2037
 G  R2038
 G  R2039
 G  R2040
 G  R2041
 G  R2042
 G  R2043
 G  R2044
 G  R2045
 G  R2046
 G  R2047
 G  R2048
 G  R2049
 G  R2050
 G  R2051
 G  R2052
 G  R2053
 G  R2054
 G  R2055
 G  R2056
 G  R2057
 G  R2058
 G  R2059
 G  R2060
 G  R2061
 G  R2062
 G  R2063
 G  R2064
 G  R2065
 G  R2066
 G  R2067
 G  R2068
 G  R2069
 G  R2070
 G  R2071
 G  R2072
 G  R2073
 G  R2074
 G  R2075
 G  R2076
 G  R2077
 G  R2078
 G  R2079
 G  R2080
 G  R2081
 G  R2082
 G  R2083
 G  R2084
 G  R2085
 G  R2086
 G  R2087
 G  R2088
 G  R2089
 G  R2090
 G  R2091
 G  R2092
 G  R2093
 G  R2094
 G  R2095
 G  R2096
 G  R2097
 G  R2098
 G  R2099
 G  R2100
 G  R2101
 G  R2102
 G  R2103
 G  R2104
 G  R2105
 G  R2106
 G  R2107
 G  R2108
 G  R2109
 G  R2110
 G  R2111
 G  R2112
 G  R2113
 G  R2114
 G  R2115
 G  R2116
 G  R2117
 G  R2118
 G  R2119
 G  R2120
 G  R2121
 G  R2122
 G  R2123
 G  R2124
 G  R2125
 G  R2126
 G  R2127
 G  R2128
 G  R2129
 G  R2130
 G  R2131
 G  R2132
 G  R2133
 G  R2134
 G  R2135
 G  R2136
 G  R2137
 G  R2138
 G  R2139
 G  R2140
 G  R2141
 G  R2142
 G  R2143
 G  R2144
 G  R2145
 G  R2146
 G  R2147
 G  R2148
 G  R2149
 G  R2150
 G  R2151
 G  R2152
 G  R2153
 G  R2154
 G  R2155
 G  R2156
 G  R2157
 G  R2158
 G  R2159
 G  R2160
 G  R2161
 G  R2162
 G  R2163
 G  R2164
 G  R2165
 G  R2166
 G  R2167
 G  R2168
 G  R2169
 G  R2170
 G  R2171
 G  R2172
 G  R2173
 G  R2174
 G  R2175
 G  R2176
 G  R2177
 G  R2178
 G  R2179
 G  R2180
 G  R2181
 G  R2182
 G  R2183
 G  R2184
 G  R2185
 G  R2186
 G  R2187
 G  R2188
 G  R2189
 G  R2190
 G  R2191
 G  R2192
 G  R2193
 G  R2194
 G  R2195
 G  R2196
 G  R2197
 G  R2198
 G  R2199
 G  R2200
 G  R2201
 G  R2202
 G  R2203
 G  R2204
 G  R2205
 G  R2206
 G  R2207
 G  R2208
 G  R2209
 G  R2210
 G  R2211
 G  R2212
 G  R2213
 G  R2214
 G  R2215
 G  R2216
 G  R2217
 G  R2218
 G  R2219
 G  R2220
 G  R2221
 G  R2222
 G  R2223
 G  R2224
 G  R2225
 G  R2226
 G  R2227
 G  R2228
 G  R2229
 G  R2230
 G  R2231
 G  R2232
 G  R2233
 G  R2234
 G  R2235
 G  R2236
 G  R2237
 G  R2238
 G  R2239
 G  R2240
 G  R2241
 G  R2242
 G  R2243
 G  R2244
 G  R2245
 G  R2246
 G  R2247
 G  R2248
 G  R2249
 G  R2250
 G  R2251
 G  R2252
 G  R2253
 G  R2254
 G  R2255
 G  R2256
 G  R2257
 G  R2258
 G  R2259
 G  R2260
 G  R2261
 G  R2262
 G  R2263
 G  R2264
 G  R2265
 G  R2266
 G  R2267
 G  R2268
 G  R2269
 G  R2270
 G  R2271
 G  R2272
 G  R2273
 G  R2274
 G  R2275
 G  R2276
 G  R2277
 G  R2278
 G  R2279
 G  R2280
 G  R2281
 G  R2282
 G  R2283
 G  R2284
 G  R2285
 G  R2286
 G  R2287
 G  R2288
 G  R2289
 G  R2290
 G  R2291
 G  R2292
 G  R2293
 G  R2294
 G  R2295
 G  R2296
 G  R2297
 G  R2298
 G  R2299
 G  R2300
 G  R2301
 G  R2302
 G  R2303
 G  R2304
 G  R2305
 G  R2306
 G  R2307
 G  R2308
 G  R2309
 G  R2310
 G  R2311
 G  R2312
 G  R2313
 G  R2314
 G  R2315
 G  R2316
 G  R2317
 G  R2318
 G  R2319
 G  R2320
 G  R2321
 G  R2322
 G  R2323
 G  R2324
 G  R2325
 G  R2326
 G  R2327
 G  R2328
 G  R2329
 G  R2330
 G  R2331
 G  R2332
 G  R2333
 G  R2334
 G  R2335
 G  R2336
 G  R2337
 G  R2338
 G  R2339
 G  R2340
 G  R2341
 G  R2342
 G  R2343
 G  R2344
 G  R2345
 G  R2346
 G  R2347
 G  R2348
 G  R2349
 G  R2350
 G  R2351
 G  R2352
 G  R2353
 G  R2354
 G  R2355
 G  R2356
 G  R2357
 G  R2358
 G  R2359
 G  R2360
 G  R2361
 G  R2362
 G  R2363
 G  R2364
 G  R2365
 G  R2366
 G  R2367
 G  R2368
 G  R2369
 G  R2370
 G  R2371
 G  R2372
 G  R2373
 G  R2374
 G  R2375
 G  R2376
 G  R2377
 G  R2378
 G  R2379
 G  R2380
 G  R2381
 G  R2382
 G  R2383
 G  R2384
 G  R2385
 G  R2386
 G  R2387
 G  R2388
 G  R2389
 G  R2390
 G  R2391
 G  R2392
 G  R2393
 G  R2394
 G  R2395
 G  R2396
 G  R2397
 G  R2398
 G  R2399
 G  R2400
 G  R2401
 G  R2402
 G  R2403
 G  R2404
 G  R2405
 G  R2406
 G  R2407
 G  R2408
 G  R2409
 G  R2410
 G  R2411
 G  R2412
 G  R2413
 G  R2414
 G  R2415
 G  R2416
 G  R2417
 G  R2418
 G  R2419
 G  R2420
 G  R2421
 G  R2422
 G  R2423
 G  R2424
 G  R2425
 G  R2426
 G  R2427
 G  R2428
 G  R2429
 G  R2430
 G  R2431
 G  R2432
 G  R2433
 G  R2434
 G  R2435
 G  R2436
 G  R2437
 G  R2438
 G  R2439
 G  R2440
 G  R2441
 G  R2442
 G  R2443
 G  R2444
 G  R2445
 G  R2446
 G  R2447
 G  R2448
 G  R2449
 G  R2450
 G  R2451
 G  R2452
 G  R2453
 G  R2454
 G  R2455
 G  R2456
 G  R2457
 G  R2458
 G  R2459
 G  R2460
 G  R2461
 G  R2462
 G  R2463
 G  R2464
 G  R2465
 G  R2466
 G  R2467
 G  R2468
 G  R2469
 G  R2470
 G  R2471
 G  R2472
 G  R2473
 G  R2474
 G  R2475
 G  R2476
 G  R2477
 G  R2478
 G  R2479
 G  R2480
 G  R2481
 G  R2482
 G  R2483
 G  R2484
 G  R2485
 G  R2486
 G  R2487
 G  R2488
 G  R2489
 G  R2490
 G  R2491
 G  R2492
 G  R2493
 G  R2494
 G  R2495
 G  R2496
 G  R2497
 G  R2498
 G  R2499
 G  R2500
 G  R2501
 G  R2502
 G  R2503
 G  R2504
 G  R2505
 G  R2506
 G  R2507
 G  R2508
 G  R2509
 G  R2510
 G  R2511
 G  R2512
 G  R2513
 G  R2514
 G  R2515
 G  R2516
 G  R2517
 G  R2518
 G  R2519
 G  R2520
 G  R2521
 G  R2522
 G  R2523
 G  R2524
 G  R2525
 G  R2526
 G  R2527
 G  R2528
 G  R2529
 G  R2530
 G  R2531
 G  R2532
 G  R2533
 G  R2534
 G  R2535
 G  R2536
 G  R2537
 G  R2538
 G  R2539
 G  R2540
 G  R2541
 G  R2542
 G  R2543
 G  R2544
 G  R2545
 G  R2546
 G  R2547
 G  R2548
 G  R2549
 G  R2550
 G  R2551
 G  R2552
 G  R2553
 G  R2554
 G  R2555
 G  R2556
 G  R2557
 G  R2558
 G  R2559
 G  R2560
 G  R2561
 G  R2562
 G  R2563
 G  R2564
 G  R2565
 G  R2566
 G  R2567
 G  R2568
 G  R2569
 G  R2570
 G  R2571
 G  R2572
 G  R2573
 G  R2574
 G  R2575
 G  R2576
 G  R2577
 G  R2578
 G  R2579
 G  R2580
 G  R2581
 G  R2582
 G  R2583
 G  R2584
 G  R2585
 G  R2586
 G  R2587
 G  R2588
 G  R2589
 G  R2590
 G  R2591
 G  R2592
 G  R2593
 G  R2594
 G  R2595
 G  R2596
 G  R2597
 G  R2598
 G  R2599
 G  R2600
 G  R2601
 G  R2602
 G  R2603
 G  R2604
 G  R2605
 G  R2606
 G  R2607
 G  R2608
 G  R2609
 G  R2610
 G  R2611
 G  R2612
 G  R2613
 G  R2614
 G  R2615
 G  R2616
 G  R2617
 G  R2618
 G  R2619
 G  R2620
 G  R2621
 G  R2622
 G  R2623
 G  R2624
 G  R2625
 G  R2626
 G  R2627
 G  R2628
 G  R2629
 G  R2630
 G  R2631
 G  R2632
 G  R2633
 G  R2634
 G  R2635
 G  R2636
 G  R2637
 G  R2638
 G  R2639
 G  R2640
 G  R2641
 G  R2642
 G  R2643
 G  R2644
 G  R2645
 G  R2646
 G  R2647
 G  R2648
 G  R2649
 G  R2650
 G  R2651
 G  R2652
 G  R2653
 G  R2654
 G  R2655
 G  R2656
 G  R2657
 G  R2658
 G  R2659
 G  R2660
 G  R2661
 G  R2662
 G  R2663
 G  R2664
 G  R2665
 G  R2666
 G  R2667
 G  R2668
 G  R2669
 G  R2670
 G  R2671
 G  R2672
 G  R2673
 G  R2674
 G  R2675
 G  R2676
 G  R2677
 G  R2678
 G  R2679
 G  R2680
 G  R2681
 G  R2682
 G  R2683
 G  R2684
 G  R2685
 G  R2686
 G  R2687
 G  R2688
 G  R2689
 G  R2690
 G  R2691
 G  R2692
 G  R2693
 G  R2694
 G  R2695
 G  R2696
 G  R2697
 G  R2698
 G  R2699
 G  R2700
 G  R2701
 G  R2702
 G  R2703
 G  R2704
 G  R2705
 G  R2706
 G  R2707
 G  R2708
 G  R2709
 G  R2710
 G  R2711
 G  R2712
 G  R2713
 G  R2714
 G  R2715
 G  R2716
 G  R2717
 G  R2718
 G  R2719
 G  R2720
 G  R2721
 G  R2722
 G  R2723
 G  R2724
 G  R2725
 G  R2726
 G  R2727
 G  R2728
 G  R2729
 G  R2730
 G  R2731
 G  R2732
 G  R2733
 G  R2734
 G  R2735
 G  R2736
 G  R2737
 G  R2738
 G  R2739
 G  R2740
 G  R2741
 G  R2742
 G  R2743
 G  R2744
 G  R2745
 G  R2746
 G  R2747
 G  R2748
 G  R2749
 G  R2750
 G  R2751
 G  R2752
 G  R2753
 G  R2754
 G  R2755
 G  R2756
 G  R2757
 G  R2758
 G  R2759
 G  R2760
 G  R2761
 G  R2762
 G  R2763
 G  R2764
 G  R2765
 G  R2766
 G  R2767
 G  R2768
 G  R2769
 G  R2770
 G  R2771
 G  R2772
 G  R2773
 G  R2774
 G  R2775
 G  R2776
 G  R2777
 G  R2778
 G  R2779
 G  R2780
 G  R2781
 G  R2782
 G  R2783
 G  R2784
 G  R2785
 G  R2786
 G  R2787
 G  R2788
 G  R2789
 G  R2790
 G  R2791
 G  R2792
 G  R2793
 G  R2794
 G  R2795
 G  R2796
 G  R2797
 G  R2798
 G  R2799
 G  R2800
 G  R2801
 G  R2802
 G  R2803
 G  R2804
 G  R2805
 G  R2806
 G  R2807
 G  R2808
 G  R2809
 G  R2810
 G  R2811
 G  R2812
 G  R2813
 G  R2814
 G  R2815
 G  R2816
 G  R2817
 G  R2818
 G  R2819
 G  R2820
 G  R2821
 G  R2822
 G  R2823
 G  R2824
 G  R2825
 G  R2826
 G  R2827
 G  R2828
 G  R2829
 G  R2830
 G  R2831
 G  R2832
 G  R2833
 G  R2834
 G  R2835
 G  R2836
 G  R2837
 G  R2838
 G  R2839
 G  R2840
 G  R2841
 G  R2842
 G  R2843
 G  R2844
 G  R2845
 G  R2846
 G  R2847
 G  R2848
 G  R2849
 G  R2850
 G  R2851
 G  R2852
 G  R2853
 G  R2854
 G  R2855
 G  R2856
 G  R2857
 G  R2858
 G  R2859
 G  R2860
 G  R2861
 G  R2862
 G  R2863
 G  R2864
 G  R2865
 G  R2866
 G  R2867
 G  R2868
 G  R2869
 G  R2870
 G  R2871
 G  R2872
 G  R2873
 G  R2874
 G  R2875
 G  R2876
 G  R2877
 G  R2878
 G  R2879
 G  R2880
 G  R2881
 G  R2882
 G  R2883
 G  R2884
 G  R2885
 G  R2886
 G  R2887
 G  R2888
 G  R2889
 G  R2890
 G  R2891
 G  R2892
 G  R2893
 G  R2894
 G  R2895
 G  R2896
 G  R2897
 G  R2898
 G  R2899
 G  R2900
 G  R2901
 G  R2902
 G  R2903
 G  R2904
 G  R2905
 G  R2906
 G  R2907
 G  R2908
 G  R2909
 G  R2910
 G  R2911
 G  R2912
 G  R2913
 G  R2914
 G  R2915
 G  R2916
 G  R2917
 G  R2918
 G  R2919
 G  R2920
 G  R2921
 G  R2922
 G  R2923
 G  R2924
 G  R2925
 G  R2926
 G  R2927
 G  R2928
 G  R2929
 G  R2930
 G  R2931
 G  R2932
 G  R2933
 G  R2934
 G  R2935
 G  R2936
 G  R2937
 G  R2938
 G  R2939
 G  R2940
 G  R2941
 G  R2942
 G  R2943
 G  R2944
 G  R2945
 G  R2946
 G  R2947
 G  R2948
 G  R2949
 G  R2950
 G  R2951
 G  R2952
 G  R2953
 G  R2954
 G  R2955
 G  R2956
 G  R2957
 G  R2958
 G  R2959
 G  R2960
 G  R2961
 G  R2962
 G  R2963
 G  R2964
 G  R2965
 G  R2966
 G  R2967
 G  R2968
 G  R2969
 G  R2970
 G  R2971
 G  R2972
 G  R2973
 G  R2974
 G  R2975
 G  R2976
 G  R2977
 G  R2978
 G  R2979
 G  R2980
 G  R2981
 G  R2982
 G  R2983
 G  R2984
 G  R2985
 G  R2986
 G  R2987
 G  R2988
 G  R2989
 G  R2990
 G  R2991
 G  R2992
 G  R2993
 G  R2994
 G  R2995
 G  R2996
 G  R2997
 G  R2998
 G  R2999
COLUMNS
    X0        COST                 6   R82                  2
    X0        R38                 -2   R101                 1
    X0        R166                -4   R212                -7
    X1        COST               -15   R61                  2
    X1        R23                  1   R141                -7
    X1        R108                -4   R215                -3
    X2        COST               108   R36                  9
    X2        R138                -3   R30                 -4
    X2        R146                 9   R278                 1
    X3        COST                -4   R127                -6
    X3        R174                -8   R136                 4
    X3        R109                -4   R398                 5
    X4        COST               -60   R87                 -2
    X4        R186                -7   R114                -6
    X4        R73                 -8   R355                 2
    X5        COST                14   R146                 8
    X5        R80                 -8   R87                  2
    X5        R177                 8   R289                -2
    X6        COST               -72   R179                -8
    X6        R79                  7   R165                -6
    X6        R147                -8   R374                -2
    X7        COST                -5   R55                 -4
    X7        R196                -8   R73                 -8
    X7        R33                  5   R389                 7
    X8        COST                 1   R71                  7
    X8        R180                -3   R106                -3
    X8        R91                 -4   R374                -3
    X9        COST                18   R1                   6
    X9        R37                  9   R107                -1
    X9        R136                -9   R294                -7
    X10       R123                 2   R162                -8
    X10       R102                 6   R15                 -2
    X10       R248                 3
    X11       COST               -66   R93                 -7
    X11       R157                 5   R6                  -6
    X11       R18                  2   R253                -8
    X12       COST                99   R79                  6
    X12       R21                  8   R36                  3
    X12       R26                  4   R391                -9
    X13       COST                47   R176                 5
    X13       R139                 2   R6                   5
    X13       R194                -3   R335                 4
    X14       R199                 4   R128                 7
    X14       R84                 -4   R162                -8
    X14       R257                 1
    X15       COST               -16   R71                 -6
    X15       R120                 6   R66                 -6
    X15       R49                 -2   R377                -4
    X16       COST                26   R123                 6
    X16       R159                 2   R156                 2
    X16       R0                  -4   R322                -3
    X17       COST                24   R162                -8
    X17       R85                  2   R22                  3
    X17       R184                -1   R301                 8
    X18       COST              -113   R37                 -6
    X18       R156                -9   R152                 1
    X18       R121                 2   R368                -3
    X19       COST                70   R49                  5
    X19       R54                 -6   R7                   7
    X19       R64                  1   R254                 6
    X20       COST                24   R169                 3
    X20       R149                 9   R132                 8
    X20       R107                 1   R328                -3
    X21       COST                -7   R121                -1
    X21       R158                 9   R185                 8
    X21       R30                  2   R342                -1
    X22       COST                 9   R70                  8
    X22       R10                 -2   R197                 9
    X22       R25                  4   R329                 8
    X23       COST                28   R122                 5
    X23       R129                 4   R63                 -3
    X23       R178                -7   R333                 2
    X24       COST                46   R109                 2
    X24       R18                  3   R54                 -6
    X24       R171                 3   R277                 4
    X25       COST               -22   R24                 -4
    X25       R101                 7   R124                -7
    X25       R41                 -4   R370                 2
    X26       COST                20   R4                  -1
    X26       R86                  9   R141                 9
    X26       R117                 2   R312                 4
    X27       COST               -18   R26                 -3
    X27       R21                  3   R67                 -5
    X27       R69                  9   R210                 8
    X28       COST                27   R22                  7
    X28       R71                  5   R14                  2
    X28       R176                 2   R246                -4
    X29       COST                 7   R31                  7
    X29       R116                 5   R2                   1
    X29       R86                  4   R341                -3
    X30       COST               -39   R46                  9
    X30       R51                 -5   R79                 -3
    X30       R160                 1   R278                -1
    X31       COST                24   R187                -8
    X31       R129                -8   R141                 7
    X31       R48                  9   R331                 7
    X32       COST               -14   R78                  4
    X32       R176                -3   R55                  6
    X32       R58                 -3   R287                -5
    X33       COST               -16   R14                  5
    X33       R21                 -5   R170                -3
    X33       R97                 -8   R329                 6
    X34       COST                 8   R140                -4
    X34       R82                 -1   R62                 -2
    X34       R8                   9   R279                 4
    X35       R1                   7   R23                 -7
    X35       R67                  5   R22                  2
    X35       R236                 9
    X36       COST               -90   R39                  6
    X36       R168                -8   R183                -3
    X36       R152                 9   R299                -9
    X37       COST                 7   R134                -4
    X37       R192                -1   R129                 6
    X37       R145                 7   R204                -9
    X38       COST                 5   R4                  -8
    X38       R160                 8   R136                 9
    X38       R174                 2   R262                 2
    X39       COST               -48   R121                -4
    X39       R64                 -8   R19                 -7
    X39       R67                  5   R260                -4
    X40       COST                49   R37                  5
    X40       R84                 -3   R65                 -1
    X40       R166                 2   R390                -8
    X41       COST               -52   R132                 2
    X41       R73                 -9   R118                 2
    X41       R119                -1   R319                 2
    X42       COST                 2   R115                 2
    X42       R68                  3   R99                  5
    X42       R53                  3   R253                -9
    X43       COST               -83   R28                 -8
    X43       R180                -3   R93                  8
    X43       R59                 -7   R327                -3
    X44       COST               -41   R96                  6
    X44       R80                 -7   R30                  4
    X44       R84                 -5   R200                -2
    X45       COST                -4   R150                 5
    X45       R19                 -5   R92                  5
    X45       R109                -3   R393                -5
    X46       COST               -14   R80                  1
    X46       R48                  7   R197                 9
    X46       R95                 -2   R309                -7
    X47       COST               -94   R192                 1
    X47       R35                 -9   R164                -8
    X47       R73                 -5   R324                -5
    X48       COST                13   R61                 -7
    X48       R77                 -3   R123                 9
    X48       R142                 8   R371                 8
    X49       COST               -46   R194                -4
    X49       R115                -3   R109                -2
    X49       R35                 -6   R340                 4
    X50       COST                59   R191                -4
    X50       R105                 6   R98                 -8
    X50       R190                -6   R334                 9
    X51       COST                40   R55                  7
    X51       R23                  7   R69                 -1
    X51       R63                  7   R298                 8
    X52       COST                76   R125                 8
    X52       R0                   4   R18                 -4
    X52       R100                 9   R335                 2
    X53       COST                -1   R184                 2
    X53       R179                -1   R165                -3
    X53       R195                 1   R317                 5
    X54       COST                -2   R160                -2
    X54       R64                  5   R135                -4
    X54       R162                 4   R311                -1
    X55       COST               -37   R77                 -4
    X55       R117                 4   R71                  1
    X55       R80                 -5   R365                -4
    X56       COST               -49   R172                 4
    X56       R165                -6   R107                 1
    X56       R20                 -7   R265                -7
    X57       COST                -4   R74                  8
    X57       R189                 5   R129                -4
    X57       R17                 -4   R252                -5
    X58       COST                -3   R159                -8
    X58       R126                 1   R156                 3
    X58       R47                 -1   R257                -3
    X59       COST                36   R181                 6
    X59       R15                  2   R47                 -6
    X59       R100                 9   R315                -1
    X60       COST                -2   R185                -3
    X60       R96                 -2   R95                 -6
    X60       R84                  2   R313                -4
    X61       COST                50   R196                -8
    X61       R79                  9   R110                -4
    X61       R22                 -8   R212                -7
    X62       COST                 6   R160                -1
    X62       R196                -1   R103                 2
    X62       R10                 -6   R296                 6
    X63       COST                 2   R157                 6
    X63       R11                 -5   R67                 -2
    X63       R191                -4   R383                 8
    X64       COST                48   R98                 -8
    X64       R64                  5   R110                 3
    X64       R126                 6   R233                -8
    X65       COST               -12   R152                -3
    X65       R20                  2   R131                 8
    X65       R50                 -6   R300                 7
    X66       COST                -6   R18                 -2
    X66       R67                 -8   R159                -3
    X66       R21                  4   R253                 2
    X67       COST               -33   R75                  5
    X67       R71                 -4   R145                -3
    X67       R68                 -3   R295                -4
    X68       COST                20   R101                 4
    X68       R64                  2   R62                 -1
    X68       R129                 8   R334                 4
    X69       COST                 1   R95                 -1
    X69       R10                  4   R75                  6
    X69       R59                 -3   R230                 5
    X70       COST                 8   R170                -6
    X70       R1                  -6   R27                 -1
    X70       R163                -5   R352                 4
    X71       COST                 8   R83                 -5
    X71       R104                 1   R173                -9
    X71       R95                 -7   R247                 7
    X72       COST                60   R39                 -3
    X72       R163                -5   R136                 5
    X72       R23                  7   R367                 5
    X73       COST               -12   R91                 -4
    X73       R106                -7   R4                  -1
    X73       R196                -3   R293                -2
    X74       COST                40   R93                 -1
    X74       R117                 3   R197                -7
    X74       R41                  6   R233                -3
    X75       COST               -28   R72                 -2
    X75       R41                 -4   R133                 1
    X75       R43                 -8   R217                -7
    X76       COST               -40   R182                 4
    X76       R158                 4   R176                 3
    X76       R41                 -1   R363                -9
    X77       COST                31   R91                 -4
    X77       R31                  9   R38                  1
    X77       R63                 -6   R385                 8
    X78       R160                 5   R199                -7
    X78       R78                 -6   R166                -8
    X78       R307                 1
    X79       COST                15   R125                 8
    X79       R119                -8   R60                 -2
    X79       R114                -7   R395                 8
    X80       COST                 8   R168                 6
    X80       R10                 -9   R162                 9
    X80       R33                 -3   R221                 2
    X81       COST               -69   R187                -8
    X81       R177                 3   R28                 -4
    X81       R49                  6   R233                -5
    X82       COST               -35   R157                 9
    X82       R70                 -8   R116                 5
    X82       R36                 -4   R265                -1
    X83       COST                32   R103                 6
    X83       R41                  3   R162                -5
    X83       R71                 -9   R373                 6
    X84       COST                 2   R115                -2
    X84       R142                 9   R133                 7
    X84       R148                -6   R376                 6
    X85       COST               -84   R92                 -4
    X85       R84                 -1   R195                -9
    X85       R20                  6   R313                -1
    X86       COST                -6   R74                 -9
    X86       R157                -1   R160                 4
    X86       R110                -1   R306                 1
    X87       COST                 9   R77                 -4
    X87       R27                  5   R133                -4
    X87       R91                 -8   R336                 1
    X88       R62                  2   R181                -5
    X88       R38                  5   R115                 1
    X88       R224                 9
    X89       COST                12   R152                 9
    X89       R165                -4   R148                -1
    X89       R113                -9   R354                -3
    X90       COST               123   R14                  9
    X90       R199                -4   R26                  4
    X90       R3                   9   R356                 7
    X91       COST                39   R44                  1
    X91       R130                 8   R79                 -1
    X91       R16                  7   R276                -8
    X92       COST                58   R167                -5
    X92       R115                -1   R44                  5
    X92       R57                  5   R226                 7
    X93       COST                41   R133                 2
    X93       R67                 -1   R75                  4
    X93       R164                 4   R255                -6
    X94       COST               -18   R99                 -9
    X94       R84                  9   R153                -1
    X94       R61                  4   R297                 5
    X95       COST               -30   R100                -3
    X95       R159                -1   R149                -3
    X95       R19                  3   R344                -1
    X96       COST                43   R177                 2
    X96       R164                 2   R162                -6
    X96       R10                  9   R378                 2
    X97       COST               -44   R193                -4
    X97       R182                -1   R98                  2
    X97       R27                 -5   R263                -3
    X98       COST               -74   R193                -6
    X98       R165                -1   R52                 -5
    X98       R75                  6   R281                -9
    X99       COST                32   R73                 -1
    X99       R158                -2   R190                 1
    X99       R7                   4   R305                 2
    X100      COST                -6   R73                 -4
    X100      R43                 -1   R111                -8
    X100      R0                   3   R334                 6
    X101      COST                59   R131                 4
    X101      R66                 -4   R147                 2
    X101      R40                 -2   R272                 9
    X102      COST               -18   R160                 7
    X102      R83                 -2   R91                 -1
    X102      R24                 -5   R302                 9
    X103      COST                70   R97                  9
    X103      R161                -1   R59                  6
    X103      R117                 8   R232                -6
    X104      COST                28   R112                -4
    X104      R176                 8   R197                 4
    X104      R65                 -5   R348                 3
    X105      COST                 4   R63                 -6
    X105      R185                 6   R83                  5
    X105      R154                -2   R333                -2
    X106      COST               -46   R38                 -7
    X106      R37                  2   R77                 -2
    X106      R187                -7   R276                -1
    X107      COST                 8   R111                -5
    X107      R177                -3   R56                 -7
    X107      R128                 4   R361                 7
    X108      R150                 4   R191                -2
    X108      R165                -6   R107                 2
    X108      R258                 4
    X109      COST                 4   R182                -8
    X109      R161                 7   R40                  3
    X109      R64                  6   R308                 7
    X110      COST                30   R27                  3
    X110      R9                   4   R64                  2
    X110      R139                 8   R255                 8
    X111      COST               -64   R163                -8
    X111      R94                 -3   R133                 2
    X111      R87                  6   R305                -5
    X112      COST                -8   R102                 7
    X112      R15                  6   R3                  -2
    X112      R19                  7   R307                 9
    X113      COST                17   R100                 2
    X113      R118                -4   R54                  9
    X113      R42                 -3   R233                -7
    X114      COST               -48   R75                 -8
    X114      R194                -4   R140                 7
    X114      R166                 7   R232                -8
    X115      COST                 8   R184                -5
    X115      R71                 -8   R91                  2
    X115      R62                 -6   R367                 5
    X116      COST                12   R14                  9
    X116      R21                  1   R144                 4
    X116      R83                 -5   R235                 2
    X117      COST                72   R59                 -3
    X117      R47                  7   R198                 3
    X117      R115                 2   R288                 9
    X118      COST               -67   R76                 -9
    X118      R50                  8   R126                 2
    X118      R177                -5   R254                -3
    X119      COST               -24   R142                -8
    X119      R14                  3   R123                -1
    X119      R119                -6   R236                 8
    X120      COST                -2   R119                -2
    X120      R95                  6   R109                -1
    X120      R107                 1   R373                 6
    X121      COST                70   R24                 -3
    X121      R130                 7   R123                -6
    X121      R124                -6   R393                 9
    X122      COST                 5   R53                  5
    X122      R72                 -5   R111                -8
    X122      R87                  9   R308                -9
    X123      COST                66   R52                 -4
    X123      R167                -5   R126                 2
    X123      R30                 -1   R284                 9
    X124      COST                46   R139                -2
    X124      R146                 4   R12                  8
    X124      R102                 1   R276                 9
    X125      COST                71   R157                -2
    X125      R37                  8   R160                -3
    X125      R172                 3   R378                 7
    X126      COST               -19   R167                 9
    X126      R3                  -5   R94                 -1
    X126      R35                  7   R279                -1
    X127      COST                 4   R133                -7
    X127      R10                  1   R30                 -3
    X127      R198                 7   R307                 2
    X128      COST               -17   R54                 -1
    X128      R38                  2   R160                -2
    X128      R3                  -2   R309                -1
    X129      COST                12   R145                 3
    X129      R62                  6   R115                 3
    X129      R187                -2   R390                 9
    X130      COST                 3   R117                -1
    X130      R171                 1   R65                 -2
    X130      R13                  5   R383                 3
    X131      COST                -5   R124                -8
    X131      R155                -3   R15                 -2
    X131      R80                  3   R294                -7
    X132      R199                -6   R115                 1
    X132      R69                  6   R193                 1
    X132      R345                 5
    X133      COST               -65   R63                  4
    X133      R96                  5   R99                 -6
    X133      R175                -7   R296                -1
    X134      COST                25   R36                 -8
    X134      R146                 2   R37                  8
    X134      R70                  4   R340                -4
    X135      COST                40   R14                  4
    X135      R173                 1   R101                 8
    X135      R119                 9   R381                -2
    X136      COST                 5   R148                 9
    X136      R133                -4   R66                 -2
    X136      R82                 -5   R322                -6
    X137      COST                19   R132                 6
    X137      R38                  6   R63                 -2
    X137      R11                 -1   R326                 9
    X138      COST                 3   R24                 -4
    X138      R8                  -5   R52                  8
    X138      R144                -3   R324                -1
    X139      COST                20   R46                  1
    X139      R96                 -8   R21                  2
    X139      R7                   7   R213                -2
    X140      COST                40   R144                -9
    X140      R59                  8   R164                 6
    X140      R22                 -4   R371                 5
    X141      COST               -12   R15                  9
    X141      R141                -8   R7                  -3
    X141      R12                  1   R266                 5
    X142      COST               -77   R112                -6
    X142      R194                -7   R167                -8
    X142      R26                 -8   R320                 3
    X143      COST                45   R3                   3
    X143      R119                -4   R183                 6
    X143      R49                  3   R209                 2
    X144      COST               -19   R98                 -6
    X144      R5                  -4   R160                -6
    X144      R19                  4   R315                 3
    X145      COST               -24   R141                -7
    X145      R37                 -3   R112                -5
    X145      R38                 -3   R268                -2
    X146      R123                 4   R29                 -5
    X146      R39                  4   R131                 7
    X146      R214                 4
    X147      COST                -3   R24                  1
    X147      R99                 -5   R74                 -1
    X147      R106                -9   R241                -3
    X148      COST                11   R134                 1
    X148      R73                 -4   R47                 -3
    X148      R92                  3   R311                 4
    X149      COST               -11   R50                  8
    X149      R153                -3   R20                  4
    X149      R22                 -4   R355                -9
    X150      COST                 9   R184                 5
    X150      R14                 -8   R132                 7
    X150      R88                 -8   R285                -5
    X151      COST                40   R144                 6
    X151      R93                 -1   R9                   8
    X151      R41                 -2   R379                 4
    X152      COST                 2   R82                 -1
    X152      R199                 2   R182                -8
    X152      R97                  1   R347                -9
    X153      COST                 4   R62                 -3
    X153      R22                  5   R57                 -1
    X153      R158                -4   R246                 8
    X154      COST                16   R179                -3
    X154      R113                -2   R26                  9
    X154      R89                 -2   R224                 7
    X155      COST                71   R138                 8
    X155      R151                 3   R58                  1
    X155      R37                  7   R371                -9
    X156      COST                30   R13                  4
    X156      R198                 7   R92                  6
    X156      R86                 -9   R302                -9
    X157      COST                53   R174                -1
    X157      R90                 -9   R63                 -6
    X157      R108                 9   R369                -4
    X158      R101                -1   R198                 5
    X158      R116                 5   R162                 1
    X158      R211                -5
    X159      COST                 6   R3                  -2
    X159      R111                -3   R60                  9
    X159      R10                 -2   R273                 9
    X160      COST                19   R112                 7
    X160      R31                 -5   R130                 2
    X160      R33                  5   R275                 4
    X161      COST               -27   R51                 -9
    X161      R140                -8   R181                -5
    X161      R93                 -6   R317                 9
    X162      COST                20   R149                -4
    X162      R101                -6   R3                   5
    X162      R90                 -4   R241                -1
    X163      COST               -56   R17                  1
    X163      R155                -8   R89                  2
    X163      R112                -3   R368                -6
    X164      COST                -9   R51                  2
    X164      R157                -8   R156                -3
    X164      R70                 -2   R332                 9
    X165      COST                56   R127                 5
    X165      R101                -2   R146                 8
    X165      R38                  5   R306                -5
    X166      COST               -21   R134                -6
    X166      R142                -8   R152                -5
    X166      R98                  5   R365                 7
    X167      COST               -16   R148                 4
    X167      R59                  4   R22                 -1
    X167      R84                  5   R282                -8
    X168      COST               -40   R137                 9
    X168      R198                -7   R79                 -6
    X168      R158                -6   R311                 1
    X169      COST                 1   R134                -9
    X169      R58                  9   R25                  3
    X169      R104                -7   R295                 8
    X170      COST                 5   R150                -2
    X170      R87                 -6   R177                 2
    X170      R135                -9   R391                 5
    X171      COST                29   R130                 5
    X171      R107                 4   R161                -4
    X171      R40                  1   R334                -2
    X172      COST                -2   R161                -7
    X172      R162                -1   R185                -9
    X172      R10                 -5   R377                 2
    X173      COST               123   R171                 9
    X173      R7                   9   R50                  3
    X173      R44                  7   R327                -3
    X174      COST               -13   R194                -2
    X174      R130                -9   R27                  8
    X174      R7                   1   R225                -6
    X175      COST                 7   R60                  5
    X175      R90                 -2   R70                  8
    X175      R43                 -1   R208                 7
    X176      COST                17   R11                 -4
    X176      R112                 3   R13                 -3
    X176      R158                -8   R261                 5
    X177      COST               -18   R126                -4
    X177      R17                  7   R62                 -8
    X177      R173                -4   R299                -3
    X178      COST                -4   R47                 -6
    X178      R1                   9   R74                 -6
    X178      R101                 2   R343                 7
    X179      COST               -51   R89                 -8
    X179      R141                -4   R62                  5
    X179      R99                  6   R248                 4
    X180      COST               -12   R23                 -9
    X180      R50                 -4   R69                 -6
    X180      R139                -7   R232                -4
    X181      COST                56   R121                 3
    X181      R129                 5   R52                  8
    X181      R58                  6   R315                 7
    X182      COST               -19   R54                 -9
    X182      R32                  5   R192                -7
    X182      R31                 -3   R373                 7
    X183      COST               -46   R177                 4
    X183      R45                 -2   R198                 6
    X183      R59                 -5   R282                -5
    X184      COST                10   R73                 -6
    X184      R32                  8   R183                 3
    X184      R102                -3   R272                 6
    X185      COST                 8   R6                   4
    X185      R168                -7   R180                -2
    X185      R179                -2   R318                 4
    X186      COST                11   R10                  4
    X186      R103                -3   R155                 1
    X186      R41                  3   R310                 4
    X187      COST                40   R183                 6
    X187      R133                 2   R65                  5
    X187      R111                 1   R371                -2
    X188      COST                49   R81                 -2
    X188      R53                  7   R198                -4
    X188      R88                 -2   R391                -7
    X189      COST                -6   R87                  8
    X189      R177                -4   R128                 9
    X189      R189                -3   R376                -4
    X190      COST                -8   R179                 3
    X190      R143                 4   R66                  4
    X190      R44                 -3   R339                -7
    X191      COST                41   R162                 8
    X191      R79                  4   R35                  1
    X191      R34                 -8   R375                 6
    X192      COST                93   R34                 -4
    X192      R181                 2   R36                  3
    X192      R150                 3   R344                 8
    X193      COST               -22   R103                -1
    X193      R52                 -4   R29                 -5
    X193      R176                 2   R274                 8
    X194      COST               -84   R41                 -6
    X194      R83                 -9   R113                -1
    X194      R119                -8   R345                 6
    X195      COST                18   R144                -7
    X195      R67                 -9   R27                  6
    X195      R165                 5   R325                 5
    X196      COST                11   R20                  7
    X196      R35                 -5   R191                 9
    X196      R7                  -3   R206                 5
    X197      R83                 -6   R97                  3
    X197      R47                  6   R165                -5
    X197      R291                -1
    X198      COST                 4   R160                -8
    X198      R180                 3   R103                -2
    X198      R12                 -4   R255                 8
    X199      COST               -18   R102                -4
    X199      R22                 -6   R10                 -9
    X199      R112                -5   R322                 1
    X200      COST                15   R307                 3
    X200      R286                -3   R216                -1
    X200      R312                 6   R402                -8
    X201      COST                68   R282                 3
    X201      R332                 2   R317                 1
    X201      R309                 6   R536                 5
    X202      COST                 5   R307                -3
    X202      R294                 6   R323                 1
    X202      R368                 4   R565                 8
    X203      COST               -22   R237                -7
    X203      R369                 4   R348                -7
    X203      R295                -4   R542                 4
    X204      COST                54   R228                 4
    X204      R256                 5   R264                 4
    X204      R366                 4   R424                 2
    X205      COST                75   R350                 2
    X205      R345                 3   R220                 9
    X205      R304                 2   R573                -9
    X206      COST                -6   R375                 8
    X206      R300                -3   R339                -1
    X206      R243                -1   R449                 1
    X207      COST                -7   R254                -3
    X207      R317                 2   R276                 4
    X207      R230                -6   R581                 6
    X208      COST               -90   R388                -4
    X208      R374                 9   R202                -8
    X208      R265                -6   R431                -9
    X209      COST              -111   R354                -5
    X209      R228                -8   R208                -8
    X209      R372                -1   R462                 2
    X210      COST                81   R247                 7
    X210      R238                 5   R341                 5
    X210      R274                -1   R575                -3
    X211      COST                48   R323                 7
    X211      R208                 3   R209                -8
    X211      R219                -9   R446                 6
    X212      COST                 8   R279                -4
    X212      R233                 6   R350                 6
    X212      R359                 7   R411                -6
    X213      COST               -75   R348                -4
    X213      R323                 1   R285                -3
    X213      R258                -5   R405                -5
    X214      COST                21   R346                 1
    X214      R335                 2   R349                 7
    X214      R235                -2   R578                 5
    X215      COST                 8   R260                 6
    X215      R236                 9   R374                -4
    X215      R218                 9   R477                -6
    X216      COST                15   R286                 6
    X216      R371                 4   R282                -3
    X216      R323                 1   R528                -8
    X217      COST                -6   R301                -2
    X217      R345                -5   R397                 9
    X217      R277                -6   R443                 4
    X218      COST                91   R220                 6
    X218      R349                 6   R245                 7
    X218      R277                 2   R548                 6
    X219      COST                48   R270                 3
    X219      R265                 4   R339                -4
    X219      R205                -8   R594                 5
    X220      COST                89   R365                 1
    X220      R225                -1   R250                 6
    X220      R261                -1   R587                 9
    X221      COST                29   R203                -6
    X221      R363                 1   R282                 7
    X221      R207                -6   R454                 7
    X222      COST               114   R222                 8
    X222      R360                -7   R356                 8
    X222      R285                 1   R598                -6
    X223      COST               -54   R357                -2
    X223      R381                -4   R385                -2
    X223      R284                -6   R440                 9
    X224      COST               135   R342                -6
    X224      R239                 5   R368                 8
    X224      R354                 5   R547                 9
    X225      COST              -113   R316                 9
    X225      R343                -3   R271                -9
    X225      R292                -6   R533                -4
    X226      COST                 7   R223                 1
    X226      R207                 4   R359                -3
    X226      R234                 6   R431                 3
    X227      COST                42   R399                -4
    X227      R241                -8   R335                 6
    X227      R207                -7   R489                 6
    X228      COST                67   R206                 2
    X228      R227                 7   R368                -6
    X228      R387                -7   R403                 7
    X229      COST                49   R360                 5
    X229      R257                -4   R207                -4
    X229      R264                 7   R405                 5
    X230      COST               -32   R327                 5
    X230      R255                 3   R345                -5
    X230      R240                -1   R522                -4
    X231      COST                -8   R374                 1
    X231      R356                 4   R352                -6
    X231      R315                -8   R454                 3
    X232      COST               -53   R276                -1
    X232      R375                -5   R206                -6
    X232      R228                -3   R438                -7
    X233      COST                13   R286                 6
    X233      R364                 1   R370                 4
    X233      R383                -1   R501                 9
    X234      COST               -27   R347                -1
    X234      R310                -6   R378                -2
    X234      R226                 8   R586                -9
    X235      COST                68   R245                 9
    X235      R257                 2   R375                 8
    X235      R338                -2   R437                 4
    X236      COST                22   R257                -3
    X236      R387                -5   R218                -1
    X236      R269                -1   R580                 9
    X237      COST               -19   R268                 8
    X237      R202                -9   R283                 7
    X237      R376                -5   R410                 6
    X238      COST               137   R298                 7
    X238      R238                -1   R299                 9
    X238      R394                 5   R498                 7
    X239      COST               -59   R250                 1
    X239      R369                -1   R229                -9
    X239      R222                 8   R558                -6
    X240      COST                60   R347                 8
    X240      R200                 9   R321                 4
    X240      R391                -7   R565                -2
    X241      COST               -52   R334                -6
    X241      R268                 9   R356                -5
    X241      R368                 8   R573                 6
    X242      R322                -9   R346                 4
    X242      R256                -6   R236                -3
    X242      R416                -8
    X243      COST               -26   R366                -7
    X243      R211                 3   R282                -7
    X243      R297                 6   R492                 9
    X244      COST                52   R315                 5
    X244      R369                -2   R222                 8
    X244      R270                 3   R501                -3
    X245      COST              -130   R233                 4
    X245      R293                -9   R325                -7
    X245      R333                -9   R569                -5
    X246      COST                20   R245                -6
    X246      R278                 5   R383                 2
    X246      R339                 8   R470                -4
    X247      COST               -38   R274                -8
    X247      R358                 1   R399                 5
    X247      R295                 7   R411                -5
    X248      COST               -56   R298                -6
    X248      R348                -4   R233                -2
    X248      R358                -8   R449                -9
    X249      COST               -45   R364                 8
    X249      R393                -7   R206                -8
    X249      R227                -2   R551                -8
    X250      COST                 2   R392                -4
    X250      R202                 1   R371                 5
    X250      R259                 7   R589                -2
    X251      COST                29   R219                 2
    X251      R346                 4   R203                 1
    X251      R226                 4   R527                 8
    X252      R340                 3   R376                 1
    X252      R391                -3   R306                 4
    X252      R549                -1
    X253      COST                50   R337                -6
    X253      R270                 5   R333                 9
    X253      R267                -1   R422                 4
    X254      COST                32   R311                -3
    X254      R338                 9   R265                 8
    X254      R278                -3   R451                -6
    X255      COST               -58   R380                -6
    X255      R342                -2   R369                -6
    X255      R213                 4   R586                -5
    X256      COST                23   R253                -8
    X256      R351                -4   R356                 7
    X256      R316                -2   R503                 2
    X257      COST                21   R327                -3
    X257      R246                 5   R203                 9
    X257      R384                 3   R543                 4
    X258      COST                22   R319                -7
    X258      R224                 5   R251                 8
    X258      R223                 3   R412                -3
    X259      COST               -24   R314                 6
    X259      R275                -3   R394                -5
    X259      R259                -4   R549                -4
    X260      COST                45   R208                -5
    X260      R283                 9   R297                -4
    X260      R239                -3   R564                -7
    X261      COST               -10   R290                 9
    X261      R231                -5   R368                 1
    X261      R253                 8   R567                -2
    X262      COST               -14   R271                -2
    X262      R277                -8   R353                 4
    X262      R349                -5   R538                 2
    X263      COST               -14   R288                -1
    X263      R249                -6   R238                -4
    X263      R368                -6   R476                 5
    X264      COST               -18   R385                -9
    X264      R343                 3   R316                -8
    X264      R224                 1   R591                -2
    X265      COST                -2   R378                -2
    X265      R233                -3   R306                -2
    X265      R347                -8   R490                -5
    X266      COST               -18   R261                 9
    X266      R229                -6   R239                 3
    X266      R327                 1   R469                 6
    X267      COST                99   R272                 4
    X267      R303                 9   R342                -2
    X267      R252                -1   R432                 4
    X268      COST              -111   R258                 5
    X268      R222                -7   R392                -9
    X268      R243                -2   R439                -4
    X269      COST               -34   R352                -4
    X269      R398                 6   R331                -1
    X269      R381                 3   R415                -6
    X270      COST                83   R394                 6
    X270      R318                 7   R351                -1
    X270      R246                -4   R402                 9
    X271      COST                85   R238                 4
    X271      R288                 6   R397                 2
    X271      R235                -8   R452                 9
    X272      COST               -47   R217                 4
    X272      R392                 1   R354                -7
    X272      R362                 6   R416                 8
    X273      COST                -6   R390                 5
    X273      R327                 8   R234                -3
    X273      R266                -9   R577                 9
    X274      COST                49   R361                -4
    X274      R229                 8   R217                 8
    X274      R264                -1   R592                 7
    X275      COST                18   R374                -2
    X275      R398                 6   R287                 7
    X275      R297                -1   R503                 1
    X276      COST                 1   R321                -8
    X276      R307                -9   R305                -6
    X276      R354                 8   R476                -5
    X277      COST                65   R269                 9
    X277      R247                -2   R379                -1
    X277      R313                -3   R504                 6
    X278      COST               -45   R292                -7
    X278      R242                 6   R257                 9
    X278      R289                 4   R556                -3
    X279      COST               153   R202                 8
    X279      R200                 5   R244                 2
    X279      R226                 9   R462                 3
    X280      COST               -12   R264                -6
    X280      R370                -5   R306                 7
    X280      R219                 1   R531                -8
    X281      COST               -12   R377                -9
    X281      R204                 5   R214                 3
    X281      R374                -8   R430                -6
    X282      COST               -63   R201                -9
    X282      R269                -7   R236                 5
    X282      R248                -4   R550                -9
    X283      COST                 8   R340                -7
    X283      R304                 6   R366                -5
    X283      R221                 8   R573                -9
    X284      COST                11   R235                 5
    X284      R251                 3   R332                 1
    X284      R215                 7   R441                 6
    X285      COST               -31   R247                 6
    X285      R269                -7   R279                -5
    X285      R321                -6   R450                -8
    X286      COST               -45   R252                 3
    X286      R359                -6   R315                 5
    X286      R328                 8   R504                 7
    X287      COST                41   R270                 9
    X287      R300                -2   R292                -1
    X287      R383                -5   R501                -6
    X288      COST                21   R262                 7
    X288      R217                 2   R340                 3
    X288      R224                 2   R592                 7
    X289      COST                 9   R390                -6
    X289      R287                 3   R302                 3
    X289      R300                -9   R527                -5
    X290      COST                44   R286                -9
    X290      R374                 4   R216                -7
    X290      R305                 5   R417                -3
    X291      COST                72   R371                 5
    X291      R393                 7   R261                 3
    X291      R328                 7   R431                 5
    X292      COST              -145   R397                 4
    X292      R354                -5   R330                -2
    X292      R269                -9   R555                -6
    X293      COST               -15   R317                 5
    X293      R361                 8   R395                -1
    X293      R235                -8   R514                -4
    X294      COST                43   R287                 4
    X294      R284                -4   R335                 9
    X294      R345                 4   R458                 1
    X295      R268                 5   R308                -2
    X295      R295                 9   R216                -7
    X295      R561                 1
    X296      COST               -78   R336                 8
    X296      R284                -7   R368                -8
    X296      R264                -4   R418                -3
    X297      COST                 6   R249                 8
    X297      R219                 4   R388                 4
    X297      R332                 5   R404                 1
    X298      COST               -57   R384                -4
    X298      R356                -9   R204                 6
    X298      R216                 6   R490                -5
    X299      COST                14   R389                 1
    X299      R244                 8   R376                -6
    X299      R290                -3   R507                -8
    X300      COST                -1   R221                 2
    X300      R286                 5   R281                -4
    X300      R321                 1   R432                 4
    X301      COST               -61   R332                -7
    X301      R311                -7   R398                -1
    X301      R387                -9   R585                 1
    X302      COST               -30   R222                 9
    X302      R318                -6   R399                 9
    X302      R211                 8   R452                -4
    X303      COST               -17   R252                 3
    X303      R290                -8   R297                 8
    X303      R226                 1   R425                -3
    X304      COST                28   R372                 8
    X304      R382                 8   R261                 2
    X304      R383                -7   R566                 4
    X305      COST                -3   R258                 4
    X305      R201                -1   R300                 4
    X305      R344                -1   R590                -7
    X306      COST                 9   R256                -7
    X306      R398                -3   R372                 8
    X306      R211                 2   R542                -2
    X307      COST                27   R335                 2
    X307      R241                 7   R357                -1
    X307      R331                 1   R482                 2
    X308      COST               -65   R358                 1
    X308      R356                -5   R352                 1
    X308      R337                -4   R419                 9
    X309      COST                20   R317                 4
    X309      R253                 2   R231                 2
    X309      R381                 6   R566                 2
    X310      COST                -7   R225                 5
    X310      R222                -3   R294                 6
    X310      R270                -1   R477                -1
    X311      COST                70   R377                -7
    X311      R396                 7   R353                 4
    X311      R254                 2   R533                 1
    X312      COST               -25   R207                -1
    X312      R371                -5   R374                -3
    X312      R234                 5   R510                -1
    X313      COST               -64   R224                 8
    X313      R241                -6   R313                -4
    X313      R367                -9   R567                 4
    X314      COST                 4   R291                 4
    X314      R284                 2   R200                -2
    X314      R397                -6   R597                -6
    X315      COST              -126   R337                -9
    X315      R231                -9   R317                 7
    X315      R241                 9   R454                 2
    X316      COST                36   R255                -5
    X316      R273                 2   R393                 3
    X316      R203                 3   R582                 5
    X317      COST                23   R263                 4
    X317      R287                 3   R265                 2
    X317      R207                -5   R423                 2
    X318      COST                47   R218                 2
    X318      R292                 9   R219                 5
    X318      R236                -8   R542                -2
    X319      COST                25   R301                 8
    X319      R304                 2   R378                -8
    X319      R376                -4   R444                -4
    X320      COST                39   R253                 1
    X320      R289                 2   R371                 3
    X320      R285                 5   R471                -3
    X321      COST               -22   R323                 2
    X321      R224                -4   R214                -5
    X321      R298                 3   R465                -6
    X322      COST                20   R384                -5
    X322      R245                 3   R235                 2
    X322      R294                -3   R588                 7
    X323      COST                63   R207                 7
    X323      R257                 4   R366                -8
    X323      R249                -1   R456                 7
    X324      COST                17   R260                -8
    X324      R272                 8   R207                -8
    X324      R320                -2   R512                 3
    X325      COST                -6   R309                -2
    X325      R312                -8   R215                 6
    X325      R230                 2   R448                 8
    X326      COST                69   R344                 7
    X326      R356                 4   R296                 9
    X326      R228                -4   R415                -8
    X327      COST                 5   R317                -6
    X327      R387                 5   R233                -6
    X327      R219                -8   R515                 3
    X328      COST                41   R360                 8
    X328      R367                 1   R331                 4
    X328      R206                 3   R564                -3
    X329      COST                21   R282                 3
    X329      R389                 1   R210                -2
    X329      R294                -1   R568                 3
    X330      COST                -8   R277                -2
    X330      R391                -3   R280                -8
    X330      R349                -8   R451                 8
    X331      COST               -82   R254                -4
    X331      R359                -8   R255                -6
    X331      R249                -3   R520                 1
    X332      COST                10   R397                 5
    X332      R241                 8   R261                -7
    X332      R200                 4   R439                 5
    X333      COST                -2   R238                 6
    X333      R235                -1   R333                -7
    X333      R234                 8   R548                 5
    X334      COST                28   R369                -7
    X334      R257                 7   R238                 2
    X334      R390                -5   R468                 3
    X335      COST                50   R307                 9
    X335      R218                -8   R335                 9
    X335      R296                 6   R476                -9
    X336      COST                14   R219                 3
    X336      R351                 5   R264                -7
    X336      R346                -9   R497                 2
    X337      COST               -11   R214                 6
    X337      R359                -1   R374                 6
    X337      R320                -3   R454                 6
    X338      COST               -33   R259                -7
    X338      R310                 3   R222                -4
    X338      R253                -6   R538                 8
    X339      COST                58   R232                -2
    X339      R256                 3   R363                 7
    X339      R255                 8   R468                 6
    X340      COST               100   R291                -6
    X340      R288                 8   R380                -3
    X340      R394                 2   R511                 5
    X341      COST                 6   R364                -4
    X341      R252                 5   R362                 3
    X341      R263                 8   R580                -1
    X342      COST               -35   R203                -9
    X342      R352                 2   R336                -3
    X342      R305                -4   R585                -4
    X343      COST               -64   R382                 2
    X343      R260                -4   R204                -6
    X343      R206                -6   R429                 7
    X344      R266                -3   R285                 2
    X344      R214                -5   R221                -6
    X344      R467                -8
    X345      COST               -76   R354                -7
    X345      R343                -1   R213                 2
    X345      R392                -2   R439                -3
    X346      COST               -21   R381                 2
    X346      R315                 8   R319                -3
    X346      R259                -4   R559                -8
    X347      COST               -30   R266                 6
    X347      R328                -1   R308                -1
    X347      R333                -5   R536                 8
    X348      COST               -28   R247                -3
    X348      R252                -4   R279                 6
    X348      R369                -5   R466                 9
    X349      COST                -4   R214                -5
    X349      R398                -9   R355                 3
    X349      R280                -4   R422                -4
    X350      COST               -37   R329                 8
    X350      R383                -2   R333                 2
    X350      R292                -7   R575                 5
    X351      COST                63   R331                 7
    X351      R256                 6   R315                 6
    X351      R281                 2   R522                 2
    X352      COST                -9   R271                -2
    X352      R234                -1   R209                 2
    X352      R342                -6   R433                -2
    X353      COST                -1   R378                -1
    X353      R224                 3   R383                -2
    X353      R388                 9   R413                -7
    X354      COST               -44   R244                -6
    X354      R299                -4   R395                -9
    X354      R309                 5   R581                -7
    X355      COST                37   R247                 7
    X355      R354                 3   R273                -8
    X355      R394                -9   R519                -4
    X356      COST                21   R331                -6
    X356      R320                 6   R378                -7
    X356      R238                 1   R557                -6
    X357      COST                -4   R395                -6
    X357      R265                 6   R355                 5
    X357      R210                -5   R409                -6
    X358      COST                78   R272                 7
    X358      R228                 4   R258                 1
    X358      R203                 3   R573                -5
    X359      COST                42   R367                -3
    X359      R283                 6   R297                -1
    X359      R311                 3   R478                 3
    X360      COST                -8   R390                 9
    X360      R373                -6   R338                 8
    X360      R367                 4   R412                -6
    X361      COST                21   R225                -4
    X361      R230                -2   R283                -1
    X361      R206                 8   R406                 5
    X362      COST                30   R296                -8
    X362      R279                 6   R363                 5
    X362      R361                 6   R547                 2
    X363      COST                 7   R332                 1
    X363      R217                -4   R323                 6
    X363      R314                 2   R506                -1
    X364      COST                36   R345                 7
    X364      R310                 3   R206                 9
    X364      R383                -6   R433                -1
    X365      R388                 2   R310                -4
    X365      R240                 6   R297                -3
    X365      R563                -9
    X366      COST                62   R236                -3
    X366      R354                 9   R296                 2
    X366      R343                -6   R442                -1
    X367      R205                 8   R328                -9
    X367      R382                 3   R255                -1
    X367      R530                 5
    X368      COST                12   R259                -8
    X368      R307                 1   R255                 3
    X368      R331                 4   R560                 4
    X369      COST                54   R244                 2
    X369      R259                -4   R354                 7
    X369      R251                -1   R549                -1
    X370      COST               -18   R222                -3
    X370      R217                 3   R343                -9
    X370      R373                 4   R506                -4
    X371      COST               -40   R304                -5
    X371      R291                -4   R358                -3
    X371      R311                -6   R477                -5
    X372      COST               109   R322                 8
    X372      R312                 8   R396                 8
    X372      R351                 3   R524                -4
    X373      COST               -40   R379                 6
    X373      R298                -6   R217                 7
    X373      R303                 8   R425                -9
    X374      R386                 7   R322                -5
    X374      R290                 1   R330                 3
    X374      R561                 7
    X375      COST                 8   R351                 3
    X375      R346                 7   R373                -5
    X375      R256                 1   R487                -8
    X376      COST                33   R270                 9
    X376      R293                 6   R333                -8
    X376      R205                -5   R489                -5
    X377      COST               -64   R299                -1
    X377      R217                -6   R292                -8
    X377      R360                -7   R537                -4
    X378      R388                -4   R235                -5
    X378      R237                 2   R279                 9
    X378      R458                 2
    X379      COST               -24   R238                 8
    X379      R311                -7   R249                 3
    X379      R210                -5   R591                -1
    X380      COST                28   R209                -3
    X380      R205                -3   R283                 4
    X380      R381                -4   R577                -7
    X381      R304                 1   R264                -3
    X381      R314                 3   R259                -1
    X381      R523                 1
    X382      COST                90   R340                 1
    X382      R347                 6   R203                 9
    X382      R315                 1   R512                 9
    X383      COST                37   R327                 1
    X383      R244                 9   R376                -6
    X383      R298                 4   R440                -7
    X384      COST                32   R322                -7
    X384      R348                 4   R357                 1
    X384      R241                -6   R480                -9
    X385      COST                70   R356                 8
    X385      R286                -2   R240                -1
    X385      R346                 2   R539                 5
    X386      COST               -24   R309                -3
    X386      R380                 5   R201                -7
    X386      R222                -5   R550                 8
    X387      COST               -18   R224                -4
    X387      R209                -5   R326                -6
    X387      R384                 9   R476                -9
    X388      COST                13   R346                 8
    X388      R377                -6   R365                 8
    X388      R394                 1   R471                 3
    X389      COST                40   R275                -3
    X389      R213                 7   R354                 5
    X389      R338                -1   R588                -1
    X390      COST                18   R208                 2
    X390      R255                 6   R318                 3
    X390      R353                 2   R520                -9
    X391      COST                 6   R242                -5
    X391      R241                -1   R257                 5
    X391      R321                 2   R457                 9
    X392      COST               -65   R313                 6
    X392      R254                -7   R225                -8
    X392      R306                 9   R520                -5
    X393      COST                12   R375                 3
    X393      R230                -8   R341                 5
    X393      R281                 2   R503                -6
    X394      COST                -5   R224                 8
    X394      R294                -6   R297                -9
    X394      R228                -1   R435                -8
    X395      COST               -30   R272                -6
    X395      R316                 4   R361                -3
    X395      R294                -4   R544                 4
    X396      COST                28   R350                -9
    X396      R216                 9   R307                 2
    X396      R202                 4   R453                 5
    X397      COST               -49   R249                -1
    X397      R373                -7   R348                -5
    X397      R382                 1   R570                 6
    X398      COST                 9   R350                 4
    X398      R336                -4   R246                -2
    X398      R203                 9   R546                -7
    X399      COST                21   R378                -7
    X399      R206                 5   R217                -7
    X399      R352                 1   R578                 1
    X400      COST                13   R559                 6
    X400      R536                -9   R567                -6
    X400      R498                -3   R641                -3
    X401      COST                 8   R550                 2
    X401      R431                -7   R440                 1
    X401      R479                -4   R728                 4
    X402      COST                11   R401                 8
    X402      R461                -7   R491                -1
    X402      R598                -1   R623                -9
    X403      COST                47   R409                -5
    X403      R554                 6   R446                 6
    X403      R450                 7   R617                 2
    X404      COST                10   R514                -5
    X404      R462                 2   R575                 7
    X404      R439                -1   R644                 3
    X405      COST               -12   R414                -1
    X405      R472                 4   R529                -3
    X405      R410                -4   R685                -8
    X406      COST               -63   R519                -7
    X406      R400                -7   R579                 5
    X406      R457                -6   R769                -6
    X407      COST               -42   R502                -3
    X407      R506                 1   R576                 5
    X407      R510                -2   R617                -8
    X408      COST               -74   R425                -5
    X408      R571                -8   R526                -2
    X408      R544                 3   R714                 1
    X409      COST               -69   R548                 2
    X409      R584                -4   R411                -5
    X409      R583                -6   R619                -5
    X410      COST               132   R512                 9
    X410      R445                 4   R400                 3
    X410      R433                 5   R623                 2
    X411      COST                95   R423                 1
    X411      R571                 2   R456                 6
    X411      R400                 9   R639                 8
    X412      COST                17   R564                -9
    X412      R544                -6   R536                 6
    X412      R450                 4   R679                -9
    X413      COST               -31   R405                -3
    X413      R507                -5   R510                 8
    X413      R570                -9   R753                 9
    X414      COST                -8   R539                 1
    X414      R474                -8   R475                 4
    X414      R502                 6   R781                -8
    X415      COST                26   R593                 4
    X415      R492                 7   R587                 5
    X415      R567                -1   R653                -1
    X416      COST              -114   R504                 5
    X416      R408                -4   R511                -8
    X416      R555                -3   R734                -6
    X417      COST               -77   R524                 7
    X417      R411                -8   R582                -3
    X417      R433                 3   R686                -6
    X418      COST                46   R572                -1
    X418      R462                -4   R484                 6
    X418      R409                 2   R644                 8
    X419      COST               -11   R552                -3
    X419      R465                 1   R405                 2
    X419      R500                -6   R699                 1
    X420      COST               -24   R448                -4
    X420      R452                 4   R405                -4
    X420      R548                -6   R772                 6
    X421      COST               -45   R554                -4
    X421      R423                 5   R530                -6
    X421      R517                -4   R631                -7
    X422      COST                82   R508                 7
    X422      R462                 9   R485                -5
    X422      R550                -8   R661                -1
    X423      COST                 4   R497                 3
    X423      R518                 8   R458                -7
    X423      R553                 2   R759                 8
    X424      COST                24   R423                -1
    X424      R479                -2   R518                -1
    X424      R454                -9   R777                 6
    X425      COST               -68   R582                -8
    X425      R443                 5   R425                -4
    X425      R530                -7   R735                 6
    X426      COST                33   R543                 2
    X426      R544                 6   R470                 6
    X426      R472                 9   R794                -3
    X427      R429                -6   R486                -1
    X427      R441                 4   R506                -8
    X427      R605                -5
    X428      COST                -3   R580                -1
    X428      R517                 4   R442                 6
    X428      R495                -1   R787                 8
    X429      COST               -63   R538                -3
    X429      R444                -9   R417                 3
    X429      R565                -6   R644                -9
    X430      COST                 4   R523                -5
    X430      R587                 4   R557                 4
    X430      R428                 6   R634                -6
    X431      COST                -4   R540                 2
    X431      R442                 1   R415                 9
    X431      R567                 5   R627                -2
    X432      COST                95   R533                -8
    X432      R405                 8   R404                -3
    X432      R558                 6   R658                -3
    X433      COST                56   R416                -2
    X433      R418                 5   R405                 5
    X433      R559                 2   R784                 8
    X434      COST               -63   R471                -5
    X434      R541                 2   R401                -9
    X434      R415                -3   R787                -9
    X435      COST               -37   R516                -9
    X435      R450                -5   R456                -4
    X435      R471                 8   R669                -6
    X436      R489                -6   R528                -3
    X436      R524                -7   R406                -3
    X436      R759                -3
    X437      COST                12   R529                -4
    X437      R453                -2   R450                 6
    X437      R567                -8   R784                -4
    X438      COST                44   R400                 9
    X438      R477                 3   R465                -3
    X438      R435                 2   R741                 7
    X439      COST                -1   R511                -3
    X439      R572                 9   R582                -6
    X439      R448                -7   R625                -3
    X440      COST               -81   R584                -9
    X440      R547                -9   R448                -2
    X440      R441                -4   R721                 2
    X441      COST                 3   R455                 4
    X441      R599                 3   R478                -6
    X441      R561                 2   R786                 3
    X442      COST                18   R439                 1
    X442      R464                -1   R540                -4
    X442      R587                 5   R625                -5
    X443      COST               -27   R464                -6
    X443      R400                -7   R476                 4
    X443      R518                -2   R657                -2
    X444      COST                24   R525                -6
    X444      R599                -7   R405                -9
    X444      R457                -5   R653                 9
    X445      COST                64   R573                -8
    X445      R511                 7   R549                -7
    X445      R596                 1   R735                 8
    X446      COST                68   R462                 6
    X446      R542                 7   R530                -1
    X446      R430                 8   R620                -4
    X447      COST                17   R433                -4
    X447      R476                 7   R511                -5
    X447      R582                 8   R762                 9
    X448      COST                23   R486                -2
    X448      R417                -5   R432                 9
    X448      R412                -3   R771                 2
    X449      COST               -56   R476                 3
    X449      R406                 9   R599                -2
    X449      R585                -8   R694                -8
    X450      COST                72   R511                 8
    X450      R458                -7   R497                -9
    X450      R451                 2   R682                -8
    X451      COST                -9   R451                -5
    X451      R439                -9   R512                 3
    X451      R499                -4   R795                -1
    X452      R408                 8   R557                -2
    X452      R513                -2   R569                 9
    X452      R677                 1
    X453      COST                 4   R493                -1
    X453      R432                 4   R521                 2
    X453      R422                -9   R604                 5
    X454      COST                13   R506                 6
    X454      R512                 1   R464                 2
    X454      R550                -7   R661                 1
    X455      COST                68   R425                 4
    X455      R509                 5   R416                -5
    X455      R546                -7   R777                 8
    X456      COST              -122   R476                -9
    X456      R540                -9   R470                -4
    X456      R563                 6   R764                -9
    X457      COST                45   R478                 5
    X457      R495                 4   R463                -8
    X457      R505                -4   R731                 9
    X458      COST               -89   R542                -3
    X458      R403                -4   R420                 3
    X458      R465                -2   R780                -2
    X459      COST               -82   R564                 1
    X459      R566                -7   R535                -7
    X459      R575                 9   R707                -5
    X460      COST                53   R545                 7
    X460      R502                 9   R531                -9
    X460      R501                -2   R648                 2
    X461      COST                15   R444                -6
    X461      R492                 6   R468                 3
    X461      R517                -3   R721                 3
    X462      COST               -35   R535                -9
    X462      R454                -9   R522                 6
    X462      R486                -5   R626                -5
    X463      COST                72   R403                -1
    X463      R511                 7   R456                 2
    X463      R497                -4   R719                -4
    X464      COST               -74   R425                -9
    X464      R518                -8   R581                -1
    X464      R507                 1   R748                 2
    X465      COST               -73   R551                 8
    X465      R405                -7   R560                -9
    X465      R582                -6   R750                -4
    X466      COST                 1   R546                 7
    X466      R599                 5   R569                -6
    X466      R560                -9   R685                -2
    X467      COST                18   R465                 5
    X467      R580                -9   R590                -8
    X467      R565                 6   R666                 3
    X468      COST               -72   R463                -3
    X468      R590                -4   R575                -6
    X468      R573                 6   R780                -8
    X469      COST              -113   R411                -8
    X469      R561                -8   R444                 8
    X469      R414                 9   R644                -7
    X470      COST                 5   R435                -4
    X470      R599                -8   R412                 1
    X470      R550                -9   R705                 1
    X471      COST                72   R510                -1
    X471      R451                 1   R456                 8
    X471      R485                 6   R603                 7
    X472      COST               -38   R403                -2
    X472      R498                -9   R560                -8
    X472      R466                -2   R704                 7
    X473      COST                35   R553                 8
    X473      R406                -5   R429                 7
    X473      R587                 5   R753                 1
    X474      COST               -81   R463                -2
    X474      R489                -1   R547                -9
    X474      R519                 7   R696                -1
    X475      COST               -35   R541                -8
    X475      R562                -9   R586                 5
    X475      R548                -1   R637                 1
    X476      COST                31   R462                 4
    X476      R407                 4   R565                 9
    X476      R442                 6   R667                 3
    X477      COST                81   R599                 7
    X477      R425                 3   R463                 3
    X477      R512                 5   R732                 1
    X478      COST                17   R526                 7
    X478      R413                -2   R431                -2
    X478      R441                 3   R600                 9
    X479      COST                -2   R548                -3
    X479      R431                -2   R517                 3
    X479      R529                 4   R792                 1
    X480      COST                67   R466                 8
    X480      R424                 6   R596                 3
    X480      R446                 6   R797                 7
    X481      COST                40   R573                -9
    X481      R545                 6   R514                 4
    X481      R470                 1   R664                -2
    X482      COST               -47   R478                 5
    X482      R596                 8   R401                -9
    X482      R482                -2   R625                 7
    X483      COST                41   R441                 2
    X483      R453                -7   R418                -4
    X483      R592                 1   R601                 7
    X484      COST                -1   R429                 4
    X484      R407                 7   R501                 8
    X484      R487                 3   R651                -2
    X485      COST               -67   R472                -7
    X485      R474                -5   R589                -8
    X485      R430                 2   R654                -8
    X486      COST               102   R513                -7
    X486      R509                 9   R465                 3
    X486      R526                 4   R666                 8
    X487      COST               -58   R487                 2
    X487      R496                -3   R564                -9
    X487      R431                -6   R742                -8
    X488      COST                -8   R598                -3
    X488      R550                 5   R522                -1
    X488      R556                -1   R759                 9
    X489      COST                49   R495                 8
    X489      R454                 4   R509                -2
    X489      R592                -4   R605                -4
    X490      COST               -63   R547                -7
    X490      R569                -2   R575                 5
    X490      R516                 8   R762                 7
    X491      COST               -11   R546                 9
    X491      R507                -7   R561                -7
    X491      R443                 8   R661                 1
    X492      COST                -3   R544                -3
    X492      R530                 5   R452                -4
    X492      R569                -5   R613                -9
    X493      COST                84   R419                 4
    X493      R410                -7   R587                 9
    X493      R416                -5   R644                 3
    X494      COST               -32   R567                -2
    X494      R509                 1   R457                 7
    X494      R431                -5   R611                -4
    X495      COST                26   R519                 6
    X495      R446                 3   R440                 7
    X495      R595                -2   R716                 6
    X496      COST                -3   R536                -6
    X496      R460                -6   R563                 8
    X496      R425                 7   R742                -6
    X497      COST               -31   R459                 4
    X497      R546                 6   R580                 8
    X497      R456                -7   R676                 1
    X498      COST               -12   R592                 7
    X498      R407                -6   R550                 7
    X498      R539                 9   R777                -4
    X499      COST                19   R409                 8
    X499      R520                -5   R597                 3
    X499      R455                 8   R683                -4
    X500      COST                60   R525                -5
    X500      R553                -1   R447                 6
    X500      R586                 4   R650                -3
    X501      COST               -54   R473                 3
    X501      R429                -5   R495                -9
    X501      R592                 8   R750                 5
    X502      COST                12   R573                -1
    X502      R578                -4   R543                 4
    X502      R487                 5   R665                 1
    X503      COST               -92   R565                -5
    X503      R479                -6   R472                -6
    X503      R403                -9   R731                -5
    X504      COST                 8   R514                 9
    X504      R527                -1   R478                 5
    X504      R493                -8   R734                -3
    X505      COST                69   R466                 4
    X505      R555                -1   R576                -9
    X505      R425                 9   R660                -8
    X506      COST               -57   R527                -4
    X506      R495                -8   R570                -6
    X506      R414                -5   R649                -8
    X507      COST               -41   R535                 3
    X507      R444                -3   R561                -6
    X507      R424                -8   R732                -7
    X508      COST                14   R597                -4
    X508      R488                 9   R405                 2
    X508      R525                 8   R725                 4
    X509      COST               150   R425                 9
    X509      R486                -6   R438                -2
    X509      R426                -9   R648                 7
    X510      COST                -4   R518                 9
    X510      R520                -4   R469                -2
    X510      R487                 6   R677                -7
    X511      COST               -48   R586                 1
    X511      R416                 1   R571                -8
    X511      R421                -5   R735                -1
    X512      COST               -24   R544                -3
    X512      R469                 4   R535                -4
    X512      R410                 1   R669                -5
    X513      COST               -88   R505                 1
    X513      R492                -2   R400                -1
    X513      R511                -3   R707                -8
    X514      COST                81   R599                -7
    X514      R531                -2   R503                 8
    X514      R433                 6   R728                 9
    X515      COST               -12   R446                -2
    X515      R532                -6   R455                -1
    X515      R435                -1   R604                -8
    X516      COST                77   R568                -7
    X516      R578                -4   R586                 8
    X516      R454                -3   R794                 9
    X517      COST                66   R485                -2
    X517      R430                 6   R587                 9
    X517      R453                 3   R712                 1
    X518      COST                -6   R550                 7
    X518      R401                -3   R526                -7
    X518      R547                 4   R793                 6
    X519      COST                 2   R437                -2
    X519      R509                 6   R466                -7
    X519      R495                 3   R676                -6
    X520      COST                10   R544                 5
    X520      R403                 6   R438                 4
    X520      R413                -4   R781                -8
    X521      COST               -16   R429                 6
    X521      R459                 8   R447                -1
    X521      R493                -4   R629                 8
    X522      COST                 2   R521                -1
    X522      R595                 4   R557                 2
    X522      R433                -8   R625                -6
    X523      COST                -2   R556                 6
    X523      R446                -2   R586                -1
    X523      R584                 7   R732                 3
    X524      COST               -24   R487                -9
    X524      R408                 5   R514                 3
    X524      R431                -9   R682                -5
    X525      COST               -88   R585                -8
    X525      R439                 3   R475                -8
    X525      R467                 4   R779                -3
    X526      COST                19   R594                 3
    X526      R478                -1   R503                -5
    X526      R521                -9   R701                -4
    X527      COST                24   R469                 8
    X527      R434                -4   R432                 6
    X527      R492                -9   R778                -7
    X528      COST                 3   R466                -9
    X528      R423                 4   R454                 5
    X528      R427                 1   R675                 2
    X529      COST                23   R405                 2
    X529      R442                -7   R544                 8
    X529      R466                -6   R735                -5
    X530      COST                11   R596                 6
    X530      R430                -9   R501                 2
    X530      R567                -6   R799                 5
    X531      COST                72   R459                -7
    X531      R599                 3   R411                 6
    X531      R421                 4   R756                 9
    X532      COST                16   R445                -1
    X532      R547                 9   R428                 3
    X532      R541                 7   R644                -8
    X533      COST               -13   R495                -3
    X533      R422                 1   R404                -3
    X533      R566                 2   R681                 3
    X534      COST                14   R504                -5
    X534      R566                -3   R439                -8
    X534      R538                -3   R768                 3
    X535      COST                20   R541                -9
    X535      R461                 8   R503                 2
    X535      R494                 9   R622                 2
    X536      COST               -10   R556                -7
    X536      R424                -2   R438                 7
    X536      R484                -5   R682                 3
    X537      COST                40   R470                 6
    X537      R577                -8   R431                -1
    X537      R495                 6   R688                 2
    X538      COST                43   R414                 7
    X538      R490                 6   R582                 9
    X538      R577                -8   R735                 2
    X539      COST               -63   R478                -7
    X539      R560                -9   R421                -9
    X539      R577                 9   R649                 3
    X540      COST               -27   R426                 1
    X540      R574                -1   R435                 4
    X540      R572                -3   R713                -3
    X541      COST                98   R535                 8
    X541      R594                 1   R591                 4
    X541      R547                 5   R701                 8
    X542      COST               -26   R408                -8
    X542      R493                -9   R511                 1
    X542      R432                 8   R775                -9
    X543      COST               -24   R486                 1
    X543      R522                 1   R582                -8
    X543      R501                -7   R695                 5
    X544      COST                 9   R565                 8
    X544      R420                 9   R513                -6
    X544      R537                 4   R743                -2
    X545      COST               -80   R530                 7
    X545      R488                 4   R582                -4
    X545      R432                -6   R738                -5
    X546      COST               -33   R403                -9
    X546      R535                 5   R507                -3
    X546      R476                 8   R772                -7
    X547      COST               -16   R519                 9
    X547      R557                 8   R482                -4
    X547      R447                -2   R762                 6
    X548      COST                52   R499                 6
    X548      R553                 6   R592                -3
    X548      R428                 1   R686                -2
    X549      COST              -124   R587                -1
    X549      R480                 7   R456                -6
    X549      R528                -1   R626                -9
    X550      COST                27   R543                 9
    X550      R564                 7   R492                 5
    X550      R418                -1   R747                 1
    X551      COST               -27   R465                -1
    X551      R404                 9   R494                 2
    X551      R412                -6   R748                -5
    X552      COST               -18   R436                 4
    X552      R419                 9   R589                -9
    X552      R517                 8   R715                -5
    X553      COST               -44   R543                 9
    X553      R546                -1   R450                -8
    X553      R421                -7   R606                -5
    X554      COST                19   R400                -3
    X554      R574                 8   R423                 3
    X554      R582                 1   R739                -6
    X555      COST               -36   R415                 2
    X555      R510                 4   R467                -4
    X555      R460                -4   R661                -2
    X556      COST               -56   R480                -3
    X556      R521                -8   R441                 2
    X556      R502                -2   R720                -8
    X557      COST               -52   R591                 2
    X557      R461                -7   R571                -8
    X557      R494                 3   R632                -7
    X558      COST                16   R518                -9
    X558      R473                -6   R540                -4
    X558      R424                 7   R753                -8
    X559      COST                 2   R566                -6
    X559      R436                -5   R452                 3
    X559      R458                -8   R688                 2
    X560      COST               -40   R533                -3
    X560      R510                -6   R448                -4
    X560      R406                 4   R734                -5
    X561      COST                57   R401                -1
    X561      R463                -5   R482                -2
    X561      R590                 7   R728                 7
    X562      COST              -123   R491                -8
    X562      R404                -1   R562                -8
    X562      R588                 5   R759                -9
    X563      COST                29   R473                 2
    X563      R487                 1   R489                 2
    X563      R404                 8   R617                 2
    X564      COST               129   R430                 9
    X564      R468                 9   R403                 7
    X564      R499                 2   R623                 1
    X565      R532                 3   R506                -1
    X565      R577                -4   R597                 6
    X565      R745                 7
    X566      COST                38   R415                 9
    X566      R488                -8   R511                 5
    X566      R570                -4   R632                -7
    X567      COST               -19   R515                 6
    X567      R579                -4   R459                -7
    X567      R479                -2   R610                -9
    X568      COST               -77   R412                -1
    X568      R583                 3   R422                -9
    X568      R587                -7   R777                -5
    X569      COST               -57   R564                -8
    X569      R486                -9   R561                -5
    X569      R517                -4   R644                -9
    X570      COST                 7   R400                -2
    X570      R587                 4   R538                 3
    X570      R586                -3   R632                 1
    X571      R493                 5   R497                -6
    X571      R452                -5   R523                -6
    X571      R600                 9
    X572      COST                12   R588                -4
    X572      R552                -8   R526                 4
    X572      R569                 8   R600                 2
    X573      COST                 5   R516                 3
    X573      R543                 4   R430                 7
    X573      R401                -1   R681                -5
    X574      COST                -7   R596                -2
    X574      R429                -7   R443                -4
    X574      R513                 2   R688                -4
    X575      COST               -53   R505                -3
    X575      R425                -5   R508                 3
    X575      R535                -4   R647                -3
    X576      COST                26   R447                 6
    X576      R437                 6   R500                 2
    X576      R419                 2   R720                -9
    X577      COST                18   R572                -2
    X577      R424                -6   R547                 7
    X577      R544                -6   R753                 7
    X578      COST                28   R543                 9
    X578      R538                 1   R577                -4
    X578      R441                -7   R797                -4
    X579      COST                80   R520                 8
    X579      R456                 7   R588                 5
    X579      R581                 7   R618                 5
    X580      COST               -41   R526                 6
    X580      R578                -8   R411                -5
    X580      R514                -8   R727                 2
    X581      COST               -81   R512                 5
    X581      R513                 7   R489                -8
    X581      R522                -9   R728                -6
    X582      COST                 7   R490                -7
    X582      R599                -1   R481                 4
    X582      R482                -4   R790                -7
    X583      COST                -1   R544                 1
    X583      R512                -4   R549                 1
    X583      R547                 3   R732                 2
    X584      COST               -74   R478                -5
    X584      R495                -9   R506                 5
    X584      R564                -4   R725                -5
    X585      COST                31   R590                 2
    X585      R540                 9   R429                 5
    X585      R453                 2   R720                -2
    X586      COST                 6   R457                 5
    X586      R520                -8   R420                 3
    X586      R522                 4   R694                -3
    X587      COST                75   R468                 5
    X587      R519                 4   R401                 5
    X587      R427                 5   R701                -1
    X588      COST                89   R562                 9
    X588      R442                -8   R461                -1
    X588      R564                -9   R635                 5
    X589      COST                -4   R413                -7
    X589      R481                -3   R518                -2
    X589      R417                 9   R658                 4
    X590      COST                 3   R515                 6
    X590      R442                -3   R426                 5
    X590      R480                -7   R716                -8
    X591      COST                17   R592                -2
    X591      R421                -1   R508                 2
    X591      R441                -9   R657                 1
    X592      COST                16   R432                 8
    X592      R538                 2   R530                -2
    X592      R425                -2   R721                -4
    X593      COST                85   R562                 2
    X593      R542                 8   R412                 4
    X593      R485                -2   R690                -3
    X594      COST                34   R434                -1
    X594      R559                -3   R596                -5
    X594      R576                -2   R602                 6
    X595      COST                69   R543                 4
    X595      R555                 9   R401                -2
    X595      R446                 3   R755                 2
    X596      COST                22   R473                -7
    X596      R464                 1   R587                -4
    X596      R496                 8   R739                 6
    X597      COST                44   R518                -7
    X597      R547                 6   R497                 1
    X597      R554                 1   R763                -5
    X598      COST               -17   R553                -5
    X598      R527                 3   R519                 9
    X598      R561                 7   R623                -8
    X599      COST               -68   R484                -6
    X599      R464                 2   R434                -1
    X599      R477                -5   R773                -8
    X600      R676                 2   R641                -2
    X600      R696                -9   R693                -1
    X600      R858                 8
    X601      COST              -179   R741                -9
    X601      R779                -1   R707                -8
    X601      R720                -6   R804                -4
    X602      COST                46   R604                 4
    X602      R730                -2   R740                 6
    X602      R721                 2   R891                -9
    X603      COST                12   R698                -3
    X603      R715                 2   R733                 2
    X603      R604                -3   R954                -2
    X604      COST                12   R705                -6
    X604      R687                 2   R772                 8
    X604      R636                 2   R846                -6
    X605      COST               -11   R684                 4
    X605      R638                -2   R718                -9
    X605      R781                -6   R811                -2
    X606      COST               -24   R644                -9
    X606      R738                 5   R786                 8
    X606      R636                -7   R926                -9
    X607      COST               -26   R640                -7
    X607      R675                -5   R723                -1
    X607      R693                -5   R968                -2
    X608      COST               -81   R798                -7
    X608      R682                 4   R612                -3
    X608      R780                -8   R958                -5
    X609      COST                 4   R629                -8
    X609      R745                 9   R730                -6
    X609      R781                 5   R919                 2
    X610      COST               -55   R640                 2
    X610      R725                -5   R661                 9
    X610      R672                -4   R912                -7
    X611      COST                47   R742                -5
    X611      R619                 9   R795                -8
    X611      R746                -6   R975                 3
    X612      COST               -70   R727                -1
    X612      R771                -6   R666                -9
    X612      R657                -2   R971                 2
    X613      COST                35   R631                 5
    X613      R718                 1   R795                -4
    X613      R662                -4   R893                -7
    X614      COST                13   R694                -4
    X614      R734                 9   R693                -2
    X614      R739                 4   R883                 6
    X615      COST                24   R603                -1
    X615      R649                 9   R747                -3
    X615      R762                 6   R853                 3
    X616      COST               -18   R783                -9
    X616      R648                -6   R740                 8
    X616      R719                -4   R961                -9
    X617      COST                72   R615                -3
    X617      R718                -7   R683                 2
    X617      R786                 8   R819                -9
    X618      COST                95   R734                 3
    X618      R776                 2   R722                -7
    X618      R636                 7   R852                 3
    X619      COST                -1   R780                 5
    X619      R611                 2   R766                 7
    X619      R740                -6   R837                 9
    X620      COST               -43   R615                 9
    X620      R731                 4   R648                -1
    X620      R780                -6   R833                 5
    X621      COST                37   R654                 5
    X621      R681                -8   R737                -6
    X621      R736                 8   R830                 6
    X622      COST                24   R767                -2
    X622      R709                -6   R707                 3
    X622      R621                -6   R875                 4
    X623      COST                36   R646                -5
    X623      R718                 2   R636                 7
    X623      R779                -9   R974                 2
    X624      COST                21   R721                -2
    X624      R695                 2   R629                -6
    X624      R763                 9   R818                -1
    X625      COST                23   R632                 6
    X625      R616                 8   R775                -7
    X625      R730                -3   R860                 6
    X626      COST               -14   R757                -3
    X626      R668                 3   R758                -8
    X626      R680                -2   R911                 7
    X627      COST               -13   R796                 1
    X627      R675                 4   R747                 3
    X627      R766                -6   R870                -3
    X628      COST                -6   R733                 3
    X628      R794                 4   R766                -4
    X628      R652                -3   R896                 2
    X629      COST               -64   R738                -8
    X629      R727                 7   R691                -1
    X629      R628                 9   R931                 7
    X630      COST                43   R748                 7
    X630      R688                 1   R611                 4
    X630      R672                 3   R847                 3
    X631      COST                 7   R729                 4
    X631      R604                 2   R699                 7
    X631      R605                -1   R842                 8
    X632      COST                30   R610                -2
    X632      R654                 2   R721                -8
    X632      R621                -8   R855                 8
    X633      COST                27   R782                -1
    X633      R709                 9   R747                 9
    X633      R675                -5   R919                 1
    X634      COST                16   R637                 8
    X634      R686                 8   R735                 5
    X634      R603                 9   R973                -4
    X635      COST               109   R603                 9
    X635      R661                -2   R718                -4
    X635      R754                 6   R824                 7
    X636      COST               -11   R606                 2
    X636      R741                -8   R692                 3
    X636      R787                 2   R929                 8
    X637      COST               -10   R794                -6
    X637      R623                 2   R739                -3
    X637      R723                 8   R890                -8
    X638      COST                35   R720                 9
    X638      R647                -4   R652                 5
    X638      R685                -8   R956                -7
    X639      COST               104   R723                 8
    X639      R711                 4   R780                 5
    X639      R720                 5   R892                 4
    X640      COST                -6   R623                -9
    X640      R652                 5   R691                -6
    X640      R639                -5   R823                 8
    X641      COST                24   R752                 2
    X641      R628                -8   R769                 3
    X641      R733                -9   R802                -3
    X642      COST                52   R790                -1
    X642      R638                 8   R616                 9
    X642      R735                 1   R906                -5
    X643      COST               -76   R696                -3
    X643      R667                -3   R721                 6
    X643      R619                -9   R935                -3
    X644      COST                 4   R608                 4
    X644      R778                 1   R795                -4
    X644      R614                 2   R841                -3
    X645      COST               -30   R789                -2
    X645      R628                 2   R726                -9
    X645      R799                -4   R930                 4
    X646      COST                74   R685                 6
    X646      R757                -6   R606                 5
    X646      R683                 4   R817                 7
    X647      COST               -32   R749                -1
    X647      R667                -9   R635                -2
    X647      R657                 8   R876                 9
    X648      COST                -7   R618                -5
    X648      R730                -3   R639                 6
    X648      R666                 1   R950                -5
    X649      COST               104   R792                 9
    X649      R602                 8   R786                 5
    X649      R761                 9   R828                -2
    X650      COST                48   R727                 2
    X650      R633                -1   R677                -5
    X650      R667                 9   R982                -8
    X651      COST                30   R682                 7
    X651      R746                 9   R642                 4
    X651      R788                 8   R934                 6
    X652      COST                53   R776                 3
    X652      R619                 1   R730                 5
    X652      R763                -4   R946                -1
    X653      COST                 8   R665                 7
    X653      R716                 5   R638                -7
    X653      R608                 8   R876                -9
    X654      COST                -3   R602                -5
    X654      R628                 2   R622                 4
    X654      R601                 4   R985                 6
    X655      COST                50   R619                 4
    X655      R785                -6   R610                 6
    X655      R621                 8   R948                -3
    X656      COST                16   R721                -2
    X656      R620                -3   R603                -3
    X656      R742                 6   R811                 1
    X657      COST               102   R699                 5
    X657      R730                 6   R754                -2
    X657      R666                 9   R874                -2
    X658      COST               -84   R694                -2
    X658      R785                 5   R798                -7
    X658      R691                 3   R972                -8
    X659      COST                26   R670                 1
    X659      R647                 3   R762                 1
    X659      R628                 9   R938                -5
    X660      COST               -45   R617                 5
    X660      R663                 3   R655                -9
    X660      R728                -2   R803                 2
    X661      COST               -34   R752                -5
    X661      R610                -7   R726                -1
    X661      R660                -6   R966                 1
    X662      COST                 7   R708                 5
    X662      R765                -4   R637                -4
    X662      R792                -3   R970                -9
    X663      COST                10   R752                -9
    X663      R726                 4   R790                -4
    X663      R793                 7   R941                -3
    X664      COST                35   R730                -1
    X664      R780                 9   R749                 8
    X664      R781                -9   R948                 1
    X665      COST                60   R630                -5
    X665      R790                 8   R666                 8
    X665      R705                -5   R880                 9
    X666      COST               -18   R640                 9
    X666      R797                 6   R761                 8
    X666      R674                -7   R896                -6
    X667      COST               -58   R786                -6
    X667      R706                -6   R700                -1
    X667      R728                 6   R996                -8
    X668      COST                 7   R782                -4
    X668      R767                -1   R768                 1
    X668      R705                 4   R857                 5
    X669      COST                14   R663                 1
    X669      R778                -1   R703                 7
    X669      R637                 3   R800                 2
    X670      COST                45   R658                -4
    X670      R791                 9   R640                -4
    X670      R646                -3   R863                -2
    X671      COST                65   R617                 7
    X671      R640                -5   R770                 1
    X671      R635                 6   R822                -1
    X672      COST                 4   R785                -4
    X672      R632                 4   R729                -2
    X672      R788                 1   R995                -5
    X673      COST                39   R737                -5
    X673      R783                 6   R775                -1
    X673      R606                 6   R850                 3
    X674      COST               -18   R766                 8
    X674      R790                 4   R732                -7
    X674      R717                -7   R996                 5
    X675      COST                42   R655                -3
    X675      R773                 4   R716                -7
    X675      R657                 8   R931                 6
    X676      COST                -4   R607                 3
    X676      R746                 3   R646                 3
    X676      R703                -3   R877                -2
    X677      COST                 2   R799                 5
    X677      R785                 5   R797                -2
    X677      R770                -1   R953                 6
    X678      COST                35   R618                 2
    X678      R672                 2   R707                 2
    X678      R785                -9   R971                 4
    X679      COST               -56   R645                 6
    X679      R656                -9   R707                -7
    X679      R636                -1   R981                -1
    X680      COST               -66   R633                -9
    X680      R647                -4   R629                -2
    X680      R676                -4   R947                 2
    X681      COST               -15   R782                -2
    X681      R695                 9   R612                 1
    X681      R754                -2   R846                -9
    X682      COST               -27   R664                 5
    X682      R780                 5   R606                -7
    X682      R754                -7   R919                -7
    X683      COST                39   R627                 5
    X683      R702                -1   R729                -4
    X683      R747                -4   R992                 4
    X684      COST                35   R679                -2
    X684      R690                 6   R788                 2
    X684      R630                 8   R805                -1
    X685      COST                12   R799                -6
    X685      R766                -2   R765                 7
    X685      R683                -7   R998                 6
    X686      COST               -19   R664                 8
    X686      R647                 8   R685                -4
    X686      R792                 5   R972                -8
    X687      COST                 1   R723                -8
    X687      R744                -5   R781                -1
    X687      R782                -6   R914                -9
    X688      COST               -19   R734                 9
    X688      R691                -6   R707                -8
    X688      R735                 7   R837                 1
    X689      COST               -80   R633                -2
    X689      R750                 7   R717                -7
    X689      R770                -5   R815                -4
    X690      COST                51   R683                -2
    X690      R603                -7   R739                -6
    X690      R783                -8   R949                 6
    X691      R646                 8   R658                -2
    X691      R682                 1   R725                -2
    X691      R892                 7
    X692      COST                -7   R618                 9
    X692      R626                -1   R778                -5
    X692      R792                -3   R891                 5
    X693      COST               -75   R680                -4
    X693      R686                -6   R753                 4
    X693      R684                 1   R804                -7
    X694      COST                 9   R631                -3
    X694      R713                -3   R662                -8
    X694      R707                 3   R988                 4
    X695      COST                89   R648                 9
    X695      R677                 4   R760                 6
    X695      R719                -1   R952                -8
    X696      COST               -13   R758                 1
    X696      R791                 4   R645                 8
    X696      R710                -6   R806                 5
    X697      COST                52   R616                 9
    X697      R737                 1   R781                -4
    X697      R615                -5   R969                -2
    X698      COST                29   R628                -9
    X698      R667                 8   R715                -4
    X698      R687                 1   R891                 5
    X699      COST                 2   R771                 5
    X699      R655                -6   R651                 2
    X699      R602                 6   R844                -3
    X700      COST              -112   R633                -9
    X700      R711                -9   R670                 1
    X700      R766                 9   R896                -2
    X701      COST               -62   R714                 4
    X701      R604                -9   R636                -9
    X701      R633                -8   R804                -2
    X702      COST               -26   R741                 3
    X702      R730                -7   R685                -2
    X702      R737                 7   R859                -7
    X703      R656                 1   R762                 6
    X703      R614                -6   R682                -1
    X703      R938                 9
    X704      COST                 5   R697                -7
    X704      R797                -8   R669                 4
    X704      R792                -3   R873                -1
    X705      COST               -45   R762                -8
    X705      R746                -2   R623                 6
    X705      R674                -3   R852                -8
    X706      COST                64   R744                 3
    X706      R682                -2   R776                 8
    X706      R681                 5   R932                 6
    X707      R605                -1   R658                -3
    X707      R725                 8   R766                -6
    X707      R957                 8
    X708      COST               -16   R760                 7
    X708      R684                -5   R613                 2
    X708      R675                 6   R869                 3
    X709      COST               -12   R633                -9
    X709      R693                 5   R657                 9
    X709      R696                 2   R843                -1
    X710      COST               -42   R679                -4
    X710      R723                -2   R634                -3
    X710      R636                 3   R910                -5
    X711      COST               -12   R642                 2
    X711      R638                -5   R778                 5
    X711      R610                -6   R995                 5
    X712      COST                28   R779                -6
    X712      R758                -7   R675                -4
    X712      R693                 7   R950                -8
    X713      COST                -6   R785                -7
    X713      R638                 6   R720                 3
    X713      R656                 9   R824                -3
    X714      COST               -15   R734                 3
    X714      R679                -5   R690                -5
    X714      R798                 6   R800                 1
    X715      COST               -55   R772                 8
    X715      R686                 3   R724                -8
    X715      R623                 8   R839                -8
    X716      COST                27   R798                -7
    X716      R653                -2   R696                 6
    X716      R774                 1   R972                 5
    X717      COST               114   R616                 7
    X717      R746                -8   R654                -2
    X717      R692                 9   R985                 4
    X718      COST               -66   R718                 7
    X718      R731                 4   R693                -3
    X718      R725                -1   R917                -6
    X719      COST               -62   R773                -2
    X719      R649                -1   R694                 1
    X719      R726                 4   R949                -7
    X720      COST               -25   R699                -7
    X720      R714                -6   R786                 4
    X720      R662                -1   R892                 2
    X721      COST                63   R743                 3
    X721      R730                 7   R764                 4
    X721      R742                 2   R876                -9
    X722      COST               -67   R763                 6
    X722      R768                -5   R647                -9
    X722      R600                 5   R993                 6
    X723      COST                37   R648                 1
    X723      R791                 2   R764                 7
    X723      R696                 9   R850                -7
    X724      COST                24   R707                 4
    X724      R757                -3   R746                -3
    X724      R704                -3   R890                -4
    X725      COST               -23   R664                 6
    X725      R627                -3   R609                -2
    X725      R677                -6   R868                -9
    X726      COST                -2   R611                -2
    X726      R708                -1   R748                -6
    X726      R727                 3   R985                -3
    X727      COST                46   R782                 8
    X727      R614                 9   R622                 8
    X727      R690                 5   R808                 9
    X728      COST                -5   R688                -2
    X728      R686                 4   R710                -4
    X728      R702                -4   R853                 8
    X729      COST                72   R661                -8
    X729      R765                 5   R762                -5
    X729      R773                 8   R856                 8
    X730      COST                62   R725                 4
    X730      R623                 5   R799                -1
    X730      R700                -9   R935                 8
    X731      COST                 8   R667                 1
    X731      R726                -4   R664                 6
    X731      R672                 9   R953                -2
    X732      COST                -8   R625                 7
    X732      R775                 2   R720                -6
    X732      R792                -2   R916                 2
    X733      COST               -26   R664                -1
    X733      R714                -4   R729                -3
    X733      R613                 2   R939                 2
    X734      COST                 5   R759                 6
    X734      R783                -7   R751                -1
    X734      R614                 3   R819                -6
    X735      COST                 5   R718                -5
    X735      R729                -1   R603                 7
    X735      R735                 8   R993                 2
    X736      COST                18   R682                 8
    X736      R759                 3   R618                 9
    X736      R621                 6   R835                -7
    X737      COST                74   R725                -2
    X737      R633                 4   R697                -3
    X737      R612                 6   R865                 4
    X738      COST              -105   R711                -5
    X738      R732                -3   R626                -9
    X738      R790                 1   R893                -5
    X739      COST               -28   R634                -7
    X739      R752                 6   R613                 2
    X739      R672                 7   R893                 2
    X740      COST                44   R767                -3
    X740      R605                -2   R776                 5
    X740      R701                -2   R995                -7
    X741      COST               -15   R797                 7
    X741      R787                 9   R709                -6
    X741      R605                 5   R846                 3
    X742      COST                 1   R671                -2
    X742      R632                -2   R735                -5
    X742      R779                -9   R970                -1
    X743      R785                 9   R722                 1
    X743      R745                 1   R676                -2
    X743      R851                -6
    X744      COST               -25   R603                 9
    X744      R702                 2   R791                 1
    X744      R619                -6   R914                 8
    X745      COST                29   R642                -5
    X745      R635                 9   R770                 2
    X745      R768                 7   R984                -6
    X746      COST                28   R768                -9
    X746      R716                -1   R636                -2
    X746      R740                 9   R921                 4
    X747      COST                83   R732                 3
    X747      R740                 7   R700                 4
    X747      R757                 7   R994                 1
    X748      COST                34   R734                 8
    X748      R731                -7   R710                -1
    X748      R600                 7   R827                 4
    X749      COST               130   R636                 9
    X749      R619                 9   R666                 6
    X749      R681                 1   R888                -8
    X750      COST                 7   R793                -5
    X750      R613                 9   R756                -5
    X750      R614                -6   R994                 7
    X751      COST                16   R685                -5
    X751      R777                 6   R624                -1
    X751      R646                -8   R918                 2
    X752      COST                19   R709                -8
    X752      R681                 3   R707                 3
    X752      R793                -1   R948                 3
    X753      COST               -28   R668                 2
    X753      R788                -6   R796                 6
    X753      R680                -7   R972                -3
    X754      COST                -8   R733                -1
    X754      R637                -8   R643                 9
    X754      R645                -2   R874                 1
    X755      COST               -27   R741                -3
    X755      R691                 8   R634                 2
    X755      R627                -4   R952                 8
    X756      COST                63   R671                -5
    X756      R797                 2   R684                 7
    X756      R734                 7   R937                -8
    X757      COST                10   R782                -5
    X757      R747                -2   R622                 4
    X757      R604                -4   R886                -1
    X758      COST                -5   R747                -5
    X758      R673                -3   R654                -3
    X758      R792                -6   R998                 4
    X759      COST               -43   R667                -1
    X759      R791                -1   R781                -7
    X759      R729                -1   R846                 3
    X760      COST               -50   R639                 9
    X760      R616                -4   R668                 4
    X760      R659                 6   R824                -6
    X761      COST                26   R753                -8
    X761      R768                 4   R793                -3
    X761      R689                 8   R899                -8
    X762      COST                32   R763                -2
    X762      R788                -3   R684                 9
    X762      R721                 8   R977                 7
    X763      COST               -40   R687                -8
    X763      R645                 8   R665                -4
    X763      R771                -7   R983                 9
    X764      COST                32   R743                -9
    X764      R600                 1   R678                -3
    X764      R702                 5   R945                 8
    X765      COST               -32   R712                -2
    X765      R643                -7   R770                -4
    X765      R760                -1   R995                 8
    X766      COST                 6   R688                 5
    X766      R625                -2   R626                -2
    X766      R746                -2   R823                 4
    X767      COST               -45   R711                -2
    X767      R792                 3   R700                -2
    X767      R787                -6   R963                -9
    X768      COST               -58   R773                -6
    X768      R741                -8   R704                 8
    X768      R700                 9   R894                 6
    X769      COST               -14   R768                 5
    X769      R645                 6   R709                 3
    X769      R738                -6   R914                 2
    X770      COST               -15   R777                -3
    X770      R657                -1   R745                 4
    X770      R701                -6   R958                 9
    X771      COST               -44   R773                -7
    X771      R631                 1   R798                 7
    X771      R778                -5   R812                 4
    X772      COST               -14   R752                -1
    X772      R761                -5   R719                -6
    X772      R708                -7   R834                -2
    X773      COST                 7   R713                -5
    X773      R722                 2   R719                 8
    X773      R760                -1   R913                -8
    X774      COST                19   R732                 4
    X774      R656                 2   R790                -2
    X774      R765                -4   R876                 1
    X775      COST                16   R671                 1
    X775      R670                 1   R790                -9
    X775      R720                 2   R842                -6
    X776      COST              -130   R797                 2
    X776      R720                -1   R752                -7
    X776      R647                -8   R972                -9
    X777      COST                32   R736                -3
    X777      R709                 1   R684                 2
    X777      R638                 1   R804                 3
    X778      COST               -46   R739                -4
    X778      R696                -8   R642                 2
    X778      R779                 3   R824                -6
    X779      COST               -31   R656                -8
    X779      R637                -8   R667                -2
    X779      R631                -1   R951                -2
    X780      COST               -78   R668                -9
    X780      R740                -1   R709                -9
    X780      R615                 6   R898                -7
    X781      R794                -9   R783                -8
    X781      R677                 7   R739                -5
    X781      R911                -4
    X782      COST                19   R707                 5
    X782      R760                -6   R659                -4
    X782      R678                 6   R985                -3
    X783      COST               -21   R770                 9
    X783      R712                 5   R734                -4
    X783      R789                -7   R940                -6
    X784      COST               -42   R647                -7
    X784      R737                 3   R719                 7
    X784      R765                -3   R828                 8
    X785      COST               -94   R627                -6
    X785      R678                -6   R733                -9
    X785      R738                -7   R808                -6
    X786      COST               -53   R683                 8
    X786      R781                -8   R603                -1
    X786      R717                 3   R996                -9
    X787      COST              -120   R714                -7
    X787      R730                -9   R709                -4
    X787      R681                 9   R848                 6
    X788      COST               -50   R789                -7
    X788      R737                 9   R726                 4
    X788      R748                -4   R859                -5
    X789      COST                -9   R735                 4
    X789      R798                -4   R793                -9
    X789      R608                -9   R805                -2
    X790      COST                 8   R762                 5
    X790      R689                 6   R703                -3
    X790      R622                 4   R995                 4
    X791      COST               -33   R661                 3
    X791      R635                -8   R603                 4
    X791      R741                -7   R940                 9
    X792      COST               -16   R655                 4
    X792      R783                -6   R682                -9
    X792      R711                -8   R827                -5
    X793      COST               -18   R787                -4
    X793      R779                -7   R604                -8
    X793      R710                -3   R956                -6
    X794      COST                51   R675                -4
    X794      R709                 7   R694                 5
    X794      R702                -4   R938                -4
    X795      COST               -18   R766                 4
    X795      R790                 4   R739                -8
    X795      R735                 3   R894                -3
    X796      COST               -46   R643                -1
    X796      R794                -3   R739                -8
    X796      R711                -1   R916                -5
    X797      COST              -107   R630                -3
    X797      R795                -3   R706                -4
    X797      R710                -9   R965                -3
    X798      COST               -12   R783                -7
    X798      R779                -3   R740                -4
    X798      R711                 1   R907                 3
    X799      R645                -9   R794                 9
    X799      R679                -2   R668                 5
    X799      R862                -5
    X800      COST               -85   R920                 5
    X800      R885                 2   R907                -9
    X800      R833                -8   R1125                7
    X801      COST                -9   R890                 8
    X801      R956                -1   R949                 2
    X801      R967                 1   R1056               -7
    X802      COST               -29   R837                 5
    X802      R983                -7   R939                 7
    X802      R926                -9   R1151                3
    X803      COST                 5   R828                -6
    X803      R982                 1   R907                -9
    X803      R949                 4   R1132                7
    X804      COST                -9   R848                -3
    X804      R974                 9   R846                 4
    X804      R944                -7   R1083               -3
    X805      COST                 4   R992                 4
    X805      R973                 6   R897                 6
    X805      R954                 7   R1045               -6
    X806      COST                24   R977                -8
    X806      R950                -5   R945                 8
    X806      R892                -1   R1072               -2
    X807      COST                48   R935                -1
    X807      R886                 6   R987                -9
    X807      R940                 4   R1013                8
    X808      COST               108   R879                 8
    X808      R919                -6   R823                -2
    X808      R801                 4   R1014                8
    X809      COST               -40   R946                -3
    X809      R887                -5   R910                 2
    X809      R914                -5   R1069               -9
    X810      COST                11   R915                 8
    X810      R873                 5   R805                -5
    X810      R871                -2   R1148               -2
    X811      COST               -44   R849                 6
    X811      R946                 1   R902                -1
    X811      R880                -7   R1055               -8
    X812      COST               -54   R803                 8
    X812      R938                 1   R920                -8
    X812      R855                -9   R1125               -2
    X813      COST                64   R857                -6
    X813      R881                 7   R915                 2
    X813      R939                 4   R1048               -5
    X814      COST               -30   R955                 6
    X814      R896                 6   R837                 7
    X814      R944                -7   R1106               -7
    X815      COST                22   R859                -1
    X815      R932                -5   R825                -2
    X815      R818                 7   R1141                8
    X816      COST                65   R940                 8
    X816      R944                 9   R902                -6
    X816      R802                -4   R1140               -2
    X817      COST                27   R810                -2
    X817      R939                -9   R906                -1
    X817      R822                 5   R1146                2
    X818      COST               -36   R998                 6
    X818      R867                -6   R835                -8
    X818      R991                 5   R1099               -7
    X819      COST               -10   R905                 4
    X819      R877                 6   R910                -4
    X819      R881                 1   R1174                3
    X820      COST               -34   R825                -7
    X820      R863                -2   R868                 4
    X820      R888                 1   R1150               -1
    X821      COST                11   R806                -8
    X821      R905                -6   R950                -5
    X821      R956                 9   R1087                8
    X822      COST                 8   R923                -5
    X822      R926                 4   R969                -5
    X822      R953                 7   R1060               -3
    X823      COST                16   R865                 2
    X823      R923                 4   R943                -1
    X823      R946                -8   R1022               -9
    X824      COST               -56   R950                 1
    X824      R818                 6   R954                 8
    X824      R811                -6   R1035               -7
    X825      COST               -58   R884                -1
    X825      R870                -5   R857                -1
    X825      R981                 7   R1107               -4
    X826      COST                63   R873                 1
    X826      R901                -9   R923                -3
    X826      R887                 9   R1006               -1
    X827      COST                 7   R860                -4
    X827      R948                 3   R980                -5
    X827      R906                -3   R1158               -2
    X828      COST                75   R997                -4
    X828      R828                 6   R879                 7
    X828      R898                 9   R1129                8
    X829      COST               -55   R928                -9
    X829      R910                -3   R831                -4
    X829      R871                 5   R1072                6
    X830      COST               -88   R990                 9
    X830      R963                -6   R975                -6
    X830      R912                -5   R1126               -4
    X831      R949                -4   R818                 2
    X831      R846                 4   R999                 1
    X831      R1132                7
    X832      COST               -24   R970                 3
    X832      R939                -6   R914                 1
    X832      R870                -5   R1146                3
    X833      COST                21   R977                 8
    X833      R881                 2   R858                 2
    X833      R810                -6   R1051               -7
    X834      COST                27   R989                 7
    X834      R974                 3   R964                 9
    X834      R891                 5   R1076                8
    X835      COST               -28   R918                -3
    X835      R913                 9   R951                 5
    X835      R945                -9   R1073                4
    X836      COST               -87   R991                 1
    X836      R871                -6   R898                -7
    X836      R961                -9   R1071               -1
    X837      COST                -9   R990                -3
    X837      R880                 9   R994                -9
    X837      R969                 4   R1096               -2
    X838      COST               107   R966                 8
    X838      R906                 4   R839                 4
    X838      R826                 7   R1048                7
    X839      COST               -70   R949                -3
    X839      R854                 2   R918                -8
    X839      R853                -7   R1073                7
    X840      COST                -2   R911                -4
    X840      R984                -3   R886                 4
    X840      R917                 2   R1101               -2
    X841      COST                12   R954                 2
    X841      R928                -7   R888                -2
    X841      R866                 6   R1170                3
    X842      COST              -100   R904                -9
    X842      R912                 6   R893                -8
    X842      R908                -7   R1138               -8
    X843      COST               -87   R920                 2
    X843      R901                 9   R875                -8
    X843      R945                 7   R1042               -4
    X844      COST               -66   R984                -6
    X844      R945                -6   R978                 2
    X844      R937                -1   R1097               -7
    X845      COST                28   R833                 5
    X845      R937                 7   R987                -5
    X845      R960                 6   R1136                2
    X846      COST               -38   R941                 1
    X846      R844                 2   R900                -9
    X846      R980                -4   R1076               -2
    X847      COST                 8   R918                -6
    X847      R933                 5   R880                 5
    X847      R995                 7   R1058                1
    X848      COST                18   R973                -8
    X848      R956                 3   R840                -1
    X848      R933                 3   R1158                1
    X849      COST                63   R889                -3
    X849      R887                 8   R886                 2
    X849      R951                 8   R1000               -4
    X850      COST              -182   R947                -5
    X850      R997                -5   R935                -5
    X850      R903                -8   R1004               -9
    X851      COST                18   R816                 3
    X851      R895                 9   R986                -3
    X851      R962                -3   R1106                2
    X852      COST                -6   R945                 5
    X852      R948                -6   R869                -7
    X852      R968                 1   R1074               -4
    X853      R866                 5   R848                 4
    X853      R932                -2   R913                -9
    X853      R1001               -9
    X854      COST                 8   R930                -7
    X854      R905                -8   R814                -2
    X854      R932                -5   R1191                1
    X855      COST                32   R822                -1
    X855      R860                -4   R821                 7
    X855      R901                 7   R1171                2
    X856      COST                20   R991                -3
    X856      R881                 4   R980                -1
    X856      R988                -2   R1150               -2
    X857      COST                 4   R841                 5
    X857      R972                 2   R831                -2
    X857      R958                -9   R1187                4
    X858      COST               -74   R841                -6
    X858      R946                -3   R984                -4
    X858      R909                -6   R1193                3
    X859      COST               -49   R806                -5
    X859      R837                 7   R840                -4
    X859      R887                -7   R1167                7
    X860      COST               -24   R983                 3
    X860      R958                -6   R862                 9
    X860      R855                -4   R1109               -5
    X861      COST               -41   R847                -1
    X861      R985                 4   R996                 8
    X861      R802                 3   R1030               -6
    X862      COST                 7   R976                 3
    X862      R964                 9   R819                -3
    X862      R820                 9   R1070                9
    X863      COST                23   R924                 4
    X863      R936                -2   R878                -8
    X863      R921                 5   R1034                9
    X864      COST                 4   R966                 2
    X864      R860                -7   R925                -7
    X864      R964                -3   R1003                4
    X865      COST               -15   R972                 1
    X865      R841                -3   R979                -8
    X865      R908                -8   R1064               -4
    X866      COST               -23   R844                -3
    X866      R929                -9   R825                -6
    X866      R962                -9   R1134                1
    X867      COST               -12   R896                -8
    X867      R951                 3   R976                 5
    X867      R833                -3   R1154                2
    X868      COST                21   R849                -8
    X868      R837                -2   R855                 6
    X868      R972                -2   R1041                3
    X869      COST                35   R882                -6
    X869      R846                -1   R991                 5
    X869      R923                 7   R1133                4
    X870      COST                55   R989                 5
    X870      R926                 9   R987                 6
    X870      R836                 1   R1050                2
    X871      COST                12   R929                 3
    X871      R870                 1   R994                 1
    X871      R902                 5   R1196                1
    X872      COST                -3   R962                 9
    X872      R828                -7   R810                -8
    X872      R806                 6   R1023               -3
    X873      COST                 8   R964                 5
    X873      R853                -2   R913                 4
    X873      R990                -7   R1115                1
    X874      COST                84   R829                -5
    X874      R896                 4   R915                 3
    X874      R809                 9   R1056                1
    X875      COST               -34   R953                -8
    X875      R846                -5   R985                 9
    X875      R852                -4   R1193                7
    X876      COST                 9   R836                 6
    X876      R876                 1   R846                 9
    X876      R969                -9   R1163                5
    X877      COST               -75   R810                -3
    X877      R893                -7   R877                 6
    X877      R815                -6   R1061               -5
    X878      COST                41   R910                 6
    X878      R817                -1   R859                 5
    X878      R973                 1   R1065               -8
    X879      COST               -18   R851                -3
    X879      R807                -7   R969                -4
    X879      R801                -3   R1089               -9
    X880      COST                 1   R864                 3
    X880      R871                -6   R890                 9
    X880      R969                 9   R1188               -5
    X881      COST                78   R865                 5
    X881      R989                 1   R810                -6
    X881      R881                -1   R1143                7
    X882      COST              -138   R995                -1
    X882      R910                -9   R853                -1
    X882      R925                -4   R1025               -8
    X883      COST                -5   R849                 3
    X883      R967                -8   R817                 9
    X883      R833                 4   R1149                8
    X884      COST                 7   R885                -3
    X884      R818                -3   R886                 7
    X884      R991                 2   R1160                3
    X885      COST                 6   R854                -2
    X885      R947                 8   R996                 6
    X885      R952                 5   R1172               -6
    X886      COST                49   R913                 7
    X886      R877                -2   R975                 2
    X886      R801                 2   R1056                5
    X887      COST                 2   R952                 2
    X887      R936                -9   R841                 5
    X887      R883                 7   R1060                5
    X888      COST                36   R962                -4
    X888      R871                -5   R849                 4
    X888      R950                -8   R1002                6
    X889      COST                14   R961                -4
    X889      R818                -6   R815                 4
    X889      R806                -6   R1009               -5
    X890      COST               -25   R982                -9
    X890      R862                -1   R809                -9
    X890      R845                 2   R1057                3
    X891      COST               107   R835                -6
    X891      R940                 5   R937                -5
    X891      R936                 8   R1146                9
    X892      COST               -11   R958                -9
    X892      R953                -3   R940                 4
    X892      R931                 7   R1057               -7
    X893      COST                42   R933                 7
    X893      R844                 3   R857                -1
    X893      R970                 7   R1031               -9
    X894      COST                 9   R851                -5
    X894      R877                -6   R922                -5
    X894      R815                 3   R1078                1
    X895      COST                38   R844                -3
    X895      R862                 3   R928                -1
    X895      R803                -3   R1084                5
    X896      COST               -11   R805                -2
    X896      R869                -2   R883                -3
    X896      R863                -1   R1158               -5
    X897      COST               -63   R997                -3
    X897      R852                -5   R983                 5
    X897      R869                -4   R1069                3
    X898      COST               120   R902                 2
    X898      R914                 1   R894                 9
    X898      R842                -4   R1140                9
    X899      COST               -68   R910                -7
    X899      R866                -1   R842                -1
    X899      R896                -4   R1142               -1
    X900      COST               -66   R964                 1
    X900      R899                 7   R904                -9
    X900      R823                -5   R1039               -9
    X901      COST                -4   R902                 6
    X901      R862                 8   R989                -2
    X901      R969                 7   R1009               -4
    X902      COST               -52   R863                 7
    X902      R844                 8   R865                -6
    X902      R877                -2   R1105                8
    X903      COST                60   R912                 1
    X903      R967                 6   R922                -6
    X903      R926                 8   R1153               -9
    X904      COST               -32   R832                 1
    X904      R955                -2   R941                 6
    X904      R841                 6   R1146               -5
    X905      COST               -42   R818                -3
    X905      R997                 1   R921                -2
    X905      R822                 1   R1037               -9
    X906      COST                21   R967                 7
    X906      R938                -2   R806                 9
    X906      R887                -5   R1176                7
    X907      COST                -7   R999                 3
    X907      R863                 9   R936                 4
    X907      R854                -9   R1053               -4
    X908      COST               -71   R906                -3
    X908      R809                -5   R860                -4
    X908      R913                -1   R1169               -8
    X909      COST               109   R972                 4
    X909      R865                 5   R812                -9
    X909      R879                 6   R1122               -6
    X910      COST               -62   R836                -7
    X910      R933                -3   R853                -9
    X910      R905                 8   R1084               -5
    X911      COST                 9   R854                -6
    X911      R869                -5   R810                -4
    X911      R840                -5   R1177                1
    X912      COST              -101   R863                 1
    X912      R845                -8   R857                 2
    X912      R843                -5   R1060               -1
    X913      COST                56   R853                 4
    X913      R937                -7   R938                 3
    X913      R956                 4   R1035                6
    X914      COST               124   R912                 4
    X914      R847                 9   R923                 8
    X914      R939                 4   R1092                4
    X915      COST                94   R946                 7
    X915      R891                 8   R895                 7
    X915      R877                 6   R1113                9
    X916      COST                15   R976                -5
    X916      R861                 5   R899                -1
    X916      R919                 3   R1096                5
    X917      COST               -21   R888                 7
    X917      R856                -7   R820                -6
    X917      R896                -7   R1149                9
    X918      COST                59   R858                 8
    X918      R875                 3   R871                -5
    X918      R971                -4   R1002                8
    X919      COST                15   R837                 9
    X919      R896                 5   R836                -7
    X919      R871                -5   R1009               -6
    X920      R967                 1   R875                -1
    X920      R962                 7   R856                -5
    X920      R1012                7
    X921      COST               -14   R919                 9
    X921      R990                 3   R901                -5
    X921      R944                -2   R1175                2
    X922      COST                36   R855                 3
    X922      R878                -6   R875                 2
    X922      R806                -5   R1079               -6
    X923      COST                -3   R914                -3
    X923      R949                -1   R924                 1
    X923      R952                -9   R1095               -8
    X924      COST                33   R839                 9
    X924      R844                 9   R816                -1
    X924      R852                -4   R1021                2
    X925      COST                -4   R837                -8
    X925      R922                 7   R817                -6
    X925      R941                -8   R1047                5
    X926      COST               -18   R800                -9
    X926      R876                -6   R890                -9
    X926      R818                 6   R1117                2
    X927      COST                60   R824                 6
    X927      R888                 3   R980                 2
    X927      R851                -4   R1009                1
    X928      COST               -20   R806                -5
    X928      R947                -8   R909                 4
    X928      R851                -6   R1051                9
    X929      COST               -68   R954                 2
    X929      R986                -2   R837                -6
    X929      R929                 8   R1025               -7
    X930      COST                27   R864                -1
    X930      R905                 5   R898                -2
    X930      R867                 7   R1063                4
    X931      COST                 2   R950                -3
    X931      R973                 5   R903                -1
    X931      R897                -7   R1136               -8
    X932      COST               -30   R955                 1
    X932      R834                 8   R927                -4
    X932      R923                 8   R1144               -5
    X933      COST               -76   R882                -3
    X933      R823                -9   R889                -2
    X933      R826                -8   R1032                7
    X934      COST                -7   R861                -5
    X934      R969                 1   R857                -4
    X934      R958                 9   R1119               -9
    X935      COST                 2   R926                 2
    X935      R812                -4   R803                 2
    X935      R962                 9   R1009               -5
    X936      COST                71   R918                 7
    X936      R831                 5   R863                 1
    X936      R950                 4   R1181                1
    X937      COST               -71   R863                 4
    X937      R882                 8   R949                 6
    X937      R916                -7   R1146               -8
    X938      COST                15   R963                 9
    X938      R965                -2   R876                -1
    X938      R970                -6   R1099               -2
    X939      COST               -17   R832                 7
    X939      R939                 5   R996                -7
    X939      R866                -1   R1146               -4
    X940      COST                -6   R899                 4
    X940      R994                -6   R885                -6
    X940      R836                 6   R1020                7
    X941      COST                61   R861                -4
    X941      R887                 7   R971                 6
    X941      R990                -1   R1072                4
    X942      COST                56   R919                 4
    X942      R999                 3   R982                -3
    X942      R962                 9   R1102                7
    X943      COST                90   R980                 9
    X943      R875                -1   R997                 3
    X943      R816                -5   R1066                9
    X944      COST                59   R930                -8
    X944      R867                 7   R993                -1
    X944      R843                 9   R1039               -3
    X945      COST                60   R934                 6
    X945      R851                 9   R849                -2
    X945      R923                 8   R1143                6
    X946      COST                24   R953                -9
    X946      R961                 6   R816                 4
    X946      R966                 3   R1012               -7
    X947      COST                10   R905                -8
    X947      R858                 1   R933                 4
    X947      R961                -5   R1126               -5
    X948      COST                23   R818                 2
    X948      R907                 3   R914                -7
    X948      R882                 4   R1098               -6
    X949      COST               -72   R910                -9
    X949      R813                -1   R961                 3
    X949      R866                 9   R1072                4
    X950      COST               -68   R976                -7
    X950      R879                -4   R986                -6
    X950      R827                -6   R1142               -2
    X951      COST               -59   R827                -9
    X951      R828                 2   R934                -8
    X951      R926                -5   R1033                1
    X952      COST               -88   R810                 4
    X952      R807                -2   R923                -7
    X952      R829                -9   R1137               -6
    X953      COST               -18   R871                 7
    X953      R918                -9   R840                 8
    X953      R954                 2   R1019                6
    X954      COST               -43   R838                 2
    X954      R961                -4   R933                -4
    X954      R928                -6   R1034               -1
    X955      R835                 8   R902                -6
    X955      R827                -3   R962                 9
    X955      R1089               -9
    X956      COST                13   R968                -3
    X956      R964                 4   R963                 8
    X956      R958                 1   R1107               -5
    X957      COST                21   R823                 2
    X957      R982                -9   R813                 7
    X957      R803                -9   R1193                5
    X958      COST               -30   R857                 7
    X958      R934                -6   R866                 7
    X958      R803                -1   R1186                8
    X959      R849                 1   R882                -5
    X959      R862                 5   R923                 5
    X959      R1149               -2
    X960      COST                -4   R924                -9
    X960      R988                -5   R813                 7
    X960      R884                -4   R1076                7
    X961      COST                46   R957                 2
    X961      R933                -6   R907                 7
    X961      R991                 3   R1116                8
    X962      COST               -65   R896                -4
    X962      R871                 6   R874                -9
    X962      R960                 1   R1055               -9
    X963      COST               -43   R851                 1
    X963      R968                 3   R856                -5
    X963      R967                -8   R1089                5
    X964      COST                 4   R830                -6
    X964      R992                 4   R816                 8
    X964      R905                -5   R1152               -4
    X965      COST               -95   R989                -6
    X965      R834                 9   R911                -5
    X965      R843                -9   R1188               -5
    X966      COST               -11   R911                 4
    X966      R918                -4   R802                -6
    X966      R999                -3   R1147                5
    X967      COST                23   R974                 6
    X967      R826                -1   R806                 9
    X967      R876                 6   R1011               -4
    X968      COST                68   R814                -2
    X968      R843                 4   R851                 6
    X968      R879                 6   R1162                9
    X969      COST                -5   R818                -6
    X969      R920                -9   R822                 8
    X969      R829                -7   R1187               -7
    X970      COST                35   R852                 5
    X970      R950                -1   R880                -7
    X970      R879                -2   R1086                4
    X971      COST                28   R882                -1
    X971      R846                -2   R840                -2
    X971      R803                 5   R1116                6
    X972      COST               -23   R991                 2
    X972      R809                -2   R942                -2
    X972      R980                -5   R1083                6
    X973      COST                 2   R985                 6
    X973      R886                 2   R930                 7
    X973      R937                 5   R1165               -5
    X974      COST               -17   R893                 2
    X974      R857                -7   R996                -1
    X974      R927                -2   R1160                7
    X975      COST                23   R937                -9
    X975      R943                 5   R998                 1
    X975      R986                 3   R1159                9
    X976      COST                -9   R854                -3
    X976      R832                 3   R990                 4
    X976      R948                -6   R1186               -6
    X977      COST                -3   R868                 8
    X977      R814                -7   R867                 6
    X977      R927                -2   R1180                1
    X978      R929                -3   R851                -8
    X978      R977                 3   R985                -6
    X978      R1162                6
    X979      R938                 2   R902                -4
    X979      R931                -6   R844                -7
    X979      R1036               -7
    X980      COST                -4   R935                -1
    X980      R929                -3   R982                 9
    X980      R911                -1   R1038                1
    X981      COST                 7   R833                 2
    X981      R921                -9   R907                -1
    X981      R863                 3   R1161               -3
    X982      COST                25   R918                 6
    X982      R837                 9   R803                -4
    X982      R926                 5   R1013               -5
    X983      COST                66   R903                -4
    X983      R984                 8   R986                 6
    X983      R920                 2   R1182               -3
    X984      COST                30   R854                -2
    X984      R982                -4   R825                 6
    X984      R938                -6   R1017               -3
    X985      COST               -63   R845                 3
    X985      R912                -9   R998                -6
    X985      R866                 9   R1155               -3
    X986      COST               -10   R883                 7
    X986      R999                 9   R823                 7
    X986      R859                -6   R1191               -5
    X987      COST               -12   R853                -6
    X987      R882                -9   R837                 5
    X987      R982                 8   R1095                1
    X988      COST                -6   R939                 8
    X988      R850                -7   R919                -4
    X988      R993                -5   R1075                1
    X989      COST                 8   R854                -1
    X989      R982                 9   R828                 3
    X989      R819                -9   R1087                8
    X990      COST               -71   R911                 7
    X990      R868                 4   R851                -2
    X990      R820                -5   R1137               -9
    X991      COST               -19   R983                -3
    X991      R972                -8   R869                 6
    X991      R919                -7   R1049                7
    X992      COST               -63   R982                -9
    X992      R835                 1   R809                -9
    X992      R966                -5   R1078                8
    X993      COST                22   R891                 5
    X993      R920                 9   R996                 8
    X993      R896                 2   R1149               -8
    X994      COST               -34   R875                -9
    X994      R869                -2   R909                 4
    X994      R923                -2   R1150                8
    X995      COST                 4   R842                 2
    X995      R863                 2   R960                 9
    X995      R950                 1   R1125                5
    X996      COST                28   R995                -1
    X996      R934                 9   R882                -9
    X996      R942                -7   R1081                9
    X997      COST               -17   R841                -4
    X997      R986                -4   R873                -2
    X997      R808                -2   R1193                9
    X998      COST                15   R817                 1
    X998      R986                 1   R991                -1
    X998      R827                -3   R1036               -7
    X999      COST              -149   R849                -6
    X999      R844                -1   R955                 4
    X999      R826                -9   R1010               -8
    X1000     COST                 7   R1005                7
    X1000     R1195               -7   R1140               -2
    X1000     R1175               -9   R1229               -4
    X1001     COST                16   R1148                2
    X1001     R1152               -8   R1126                3
    X1001     R1097                1   R1242               -1
    X1002     COST                22   R1144               -5
    X1002     R1017                1   R1072                4
    X1002     R1196               -3   R1351                4
    X1003     COST                94   R1151               -2
    X1003     R1068                2   R1185                8
    X1003     R1061                4   R1238                1
    X1004     COST                11   R1103                6
    X1004     R1127               -1   R1146               -1
    X1004     R1129               -8   R1319               -7
    X1005     COST                74   R1047                6
    X1005     R1076                6   R1157                8
    X1005     R1077                7   R1218               -1
    X1006     COST               -39   R1035               -1
    X1006     R1149                4   R1057               -8
    X1006     R1106               -7   R1364               -3
    X1007     COST               -12   R1105               -6
    X1007     R1085               -4   R1097                7
    X1007     R1147                5   R1310                4
    X1008     COST                73   R1042                9
    X1008     R1076               -8   R1184               -3
    X1008     R1090               -4   R1292               -8
    X1009     COST                -6   R1118               -2
    X1009     R1173                7   R1098                1
    X1009     R1051               -2   R1278               -1
    X1010     COST                32   R1109                4
    X1010     R1068                9   R1164                2
    X1010     R1137                4   R1248               -1
    X1011     COST                52   R1125               -4
    X1011     R1078                4   R1177                5
    X1011     R1120                4   R1233                5
    X1012     COST                -5   R1141               -5
    X1012     R1040                1   R1152               -5
    X1012     R1086                1   R1298                9
    X1013     COST               -22   R1051                9
    X1013     R1100               -1   R1006                4
    X1013     R1065               -7   R1316               -8
    X1014     COST               -20   R1013               -8
    X1014     R1039                9   R1124                4
    X1014     R1026                6   R1211               -3
    X1015     COST               -52   R1107               -5
    X1015     R1040               -4   R1008                8
    X1015     R1138               -3   R1200               -4
    X1016     COST                -8   R1082                3
    X1016     R1006                4   R1171                2
    X1016     R1061               -3   R1277                7
    X1017     COST                14   R1076                4
    X1017     R1179                2   R1012                7
    X1017     R1065                7   R1362               -9
    X1018     COST                20   R1177                1
    X1018     R1035                1   R1113               -5
    X1018     R1153                7   R1315                1
    X1019     COST                19   R1037                4
    X1019     R1003               -7   R1065               -6
    X1019     R1014                6   R1348               -7
    X1020     COST                98   R1148                8
    X1020     R1138                6   R1028               -3
    X1020     R1049               -1   R1202               -6
    X1021     COST                33   R1108                8
    X1021     R1170                6   R1155                9
    X1021     R1112               -8   R1369               -3
    X1022     COST                11   R1184               -5
    X1022     R1023               -9   R1134                4
    X1022     R1101                3   R1293                4
    X1023     COST               107   R1083               -7
    X1023     R1146                9   R1060                7
    X1023     R1059               -1   R1240                6
    X1024     COST                16   R1068               -5
    X1024     R1168                6   R1001                7
    X1024     R1160                2   R1234                8
    X1025     COST               -34   R1102               -8
    X1025     R1060                6   R1035                5
    X1025     R1013               -7   R1229               -9
    X1026     COST                 8   R1168               -9
    X1026     R1003                8   R1152               -2
    X1026     R1186                8   R1381               -4
    X1027     COST                28   R1081               -1
    X1027     R1180               -5   R1182                4
    X1027     R1164                2   R1246                9
    X1028     COST                -9   R1042               -1
    X1028     R1121               -1   R1190                7
    X1028     R1166                2   R1241               -1
    X1029     COST                32   R1064               -7
    X1029     R1060                9   R1149                7
    X1029     R1014                2   R1206               -2
    X1030     COST               -23   R1082               -4
    X1030     R1140                2   R1136                8
    X1030     R1177               -3   R1255               -5
    X1031     COST                55   R1189                9
    X1031     R1023               -6   R1152               -2
    X1031     R1157                7   R1271                3
    X1032     COST               -13   R1105                4
    X1032     R1135               -8   R1190               -3
    X1032     R1128                8   R1240                9
    X1033     COST                 5   R1090                1
    X1033     R1184               -8   R1132                4
    X1033     R1023               -9   R1301                2
    X1034     COST                 6   R1079               -5
    X1034     R1087                5   R1117                8
    X1034     R1003               -5   R1309               -2
    X1035     COST                32   R1135                9
    X1035     R1081               -1   R1083               -5
    X1035     R1003                5   R1227                8
    X1036     COST               -48   R1066               -2
    X1036     R1060               -4   R1097               -4
    X1036     R1081               -8   R1215                8
    X1037     COST                 4   R1020                4
    X1037     R1062               -6   R1137               -5
    X1037     R1061                4   R1371                8
    X1038     COST                18   R1151                7
    X1038     R1079               -8   R1134               -5
    X1038     R1114               -3   R1325                3
    X1039     COST                74   R1004                9
    X1039     R1175                6   R1047                2
    X1039     R1017                3   R1349                3
    X1040     COST                17   R1097                5
    X1040     R1039                6   R1161                6
    X1040     R1148                7   R1375               -8
    X1041     COST                15   R1039               -6
    X1041     R1081                4   R1166               -9
    X1041     R1008               -4   R1360                2
    X1042     COST                63   R1151               -3
    X1042     R1147                4   R1152               -1
    X1042     R1183                8   R1326                4
    X1043     COST                -5   R1109                1
    X1043     R1068                6   R1098                1
    X1043     R1094               -6   R1232               -2
    X1044     COST                25   R1119               -9
    X1044     R1023               -5   R1079                2
    X1044     R1157                5   R1379                8
    X1045     COST                42   R1098               -1
    X1045     R1187                3   R1178                6
    X1045     R1149                8   R1311               -4
    X1046     COST               -19   R1146               -1
    X1046     R1124               -4   R1057                5
    X1046     R1042               -1   R1294               -1
    X1047     COST                45   R1109               -3
    X1047     R1003                8   R1132                3
    X1047     R1085                7   R1398                3
    X1048     COST               -21   R1128               -2
    X1048     R1056               -3   R1152                1
    X1048     R1197                3   R1202               -1
    X1049     COST                70   R1117                3
    X1049     R1073               -8   R1078               -6
    X1049     R1089                9   R1368                7
    X1050     COST               -66   R1034               -2
    X1050     R1095               -4   R1082               -3
    X1050     R1137               -6   R1310                5
    X1051     COST               -36   R1011               -4
    X1051     R1019                2   R1037               -6
    X1051     R1070               -6   R1370                4
    X1052     COST               -12   R1176               -6
    X1052     R1165               -6   R1194                8
    X1052     R1157               -2   R1250               -7
    X1053     COST                15   R1086                8
    X1053     R1151                9   R1074               -6
    X1053     R1126                3   R1338               -3
    X1054     COST                -3   R1037               -1
    X1054     R1021               -6   R1081               -2
    X1054     R1023                8   R1379               -5
    X1055     COST                26   R1049                4
    X1055     R1189               -7   R1138                9
    X1055     R1078                8   R1260               -7
    X1056     COST               -33   R1028               -8
    X1056     R1089                9   R1015               -5
    X1056     R1002               -7   R1244                5
    X1057     COST                -3   R1102               -3
    X1057     R1131               -1   R1027                1
    X1057     R1150                6   R1247               -4
    X1058     COST               -24   R1083               -1
    X1058     R1163                7   R1057               -4
    X1058     R1099               -2   R1342                2
    X1059     COST               -47   R1079               -7
    X1059     R1059               -6   R1180                1
    X1059     R1111                5   R1351               -5
    X1060     COST              -126   R1187               -1
    X1060     R1178               -5   R1064               -7
    X1060     R1066               -7   R1307               -5
    X1061     COST                -3   R1133               -4
    X1061     R1000               -7   R1187               -6
    X1061     R1138                9   R1214               -8
    X1062     COST               -61   R1152               -4
    X1062     R1066               -5   R1153               -7
    X1062     R1121               -5   R1254               -5
    X1063     COST               -89   R1084               -7
    X1063     R1044                6   R1016               -5
    X1063     R1075                2   R1283               -8
    X1064     COST                12   R1110                8
    X1064     R1171               -4   R1065                4
    X1064     R1077                9   R1233               -8
    X1065     COST                25   R1012               -8
    X1065     R1115                7   R1081                9
    X1065     R1004               -7   R1202                7
    X1066     COST                -2   R1005               -1
    X1066     R1013               -7   R1020               -3
    X1066     R1182               -1   R1282                6
    X1067     COST               -15   R1035               -2
    X1067     R1072                6   R1098               -6
    X1067     R1139                9   R1277               -4
    X1068     COST               -19   R1131               -5
    X1068     R1031               -4   R1005               -9
    X1068     R1035                1   R1339                4
    X1069     COST                18   R1065               -3
    X1069     R1095                2   R1013                3
    X1069     R1083               -2   R1379               -3
    X1070     COST               -15   R1113               -3
    X1070     R1123                2   R1105               -3
    X1070     R1171               -6   R1380               -3
    X1071     COST               141   R1182                9
    X1071     R1185                8   R1021                2
    X1071     R1010                3   R1257               -4
    X1072     COST                89   R1102               -5
    X1072     R1107               -2   R1037                9
    X1072     R1156                7   R1329                7
    X1073     COST               -83   R1178               -9
    X1073     R1197               -8   R1181               -4
    X1073     R1053                2   R1306               -8
    X1074     COST                -8   R1131               -2
    X1074     R1147               -5   R1047               -2
    X1074     R1175                1   R1288                9
    X1075     COST              -153   R1051               -1
    X1075     R1102               -7   R1020               -7
    X1075     R1025               -6   R1349               -7
    X1076     R1079                9   R1166                6
    X1076     R1030               -1   R1098               -9
    X1076     R1388                7
    X1077     COST                -9   R1009               -4
    X1077     R1155               -1   R1005               -3
    X1077     R1018                1   R1379               -9
    X1078     COST                -8   R1058               -8
    X1078     R1192               -4   R1050                1
    X1078     R1175                5   R1298               -6
    X1079     COST               -39   R1101                3
    X1079     R1030               -2   R1167                7
    X1079     R1016               -4   R1398               -5
    X1080     COST               -20   R1096                5
    X1080     R1020               -3   R1198                1
    X1080     R1103               -3   R1363               -5
    X1081     COST                16   R1002                2
    X1081     R1047               -8   R1151                9
    X1081     R1199                6   R1314                7
    X1082     COST              -105   R1172               -8
    X1082     R1099               -5   R1024               -4
    X1082     R1077                9   R1246               -4
    X1083     COST               157   R1040                6
    X1083     R1014                1   R1016                9
    X1083     R1079                3   R1282                9
    X1084     COST              -131   R1056               -5
    X1084     R1059               -4   R1088               -6
    X1084     R1156               -8   R1357                4
    X1085     COST                44   R1198               -1
    X1085     R1015                1   R1004                9
    X1085     R1070                2   R1391                3
    X1086     COST                71   R1003                7
    X1086     R1057                9   R1145                6
    X1086     R1112               -5   R1329               -4
    X1087     COST               -25   R1107               -6
    X1087     R1051               -9   R1022                6
    X1087     R1079                5   R1318               -8
    X1088     COST                 5   R1194               -2
    X1088     R1189                2   R1169                4
    X1088     R1159                2   R1302               -6
    X1089     COST              -102   R1054               -3
    X1089     R1124               -4   R1141               -4
    X1089     R1137               -6   R1366               -2
    X1090     COST                -2   R1082               -1
    X1090     R1116                3   R1196                5
    X1090     R1127               -4   R1324                7
    X1091     COST                21   R1082                7
    X1091     R1072               -3   R1116                4
    X1091     R1039               -9   R1206               -6
    X1092     COST                19   R1135                9
    X1092     R1046               -2   R1059               -9
    X1092     R1167                5   R1323                3
    X1093     COST                30   R1185                4
    X1093     R1177               -4   R1183               -3
    X1093     R1113                7   R1343                4
    X1094     COST               -74   R1158               -5
    X1094     R1167                4   R1088               -4
    X1094     R1154               -5   R1224               -5
    X1095     COST               -15   R1127               -4
    X1095     R1074                8   R1193               -2
    X1095     R1065                8   R1223               -1
    X1096     COST                 1   R1181               -4
    X1096     R1043                8   R1107               -9
    X1096     R1064               -8   R1245                6
    X1097     COST               -28   R1005               -8
    X1097     R1019               -3   R1091               -5
    X1097     R1198               -3   R1269                1
    X1098     COST                63   R1012               -1
    X1098     R1037                9   R1091               -5
    X1098     R1073                5   R1289               -9
    X1099     COST              -104   R1031                9
    X1099     R1085               -8   R1126               -2
    X1099     R1185               -9   R1386               -1
    X1100     COST                64   R1045               -9
    X1100     R1164               -9   R1063                8
    X1100     R1029                1   R1314                5
    X1101     COST              -117   R1057               -6
    X1101     R1084               -5   R1093               -5
    X1101     R1037               -9   R1286                5
    X1102     COST               -91   R1060               -7
    X1102     R1197                9   R1056               -9
    X1102     R1009                3   R1240                8
    X1103     COST                56   R1065                7
    X1103     R1036               -7   R1151                6
    X1103     R1070                3   R1203                6
    X1104     COST                 5   R1198               -1
    X1104     R1106                7   R1119                7
    X1104     R1023                6   R1292                8
    X1105     COST                12   R1186                1
    X1105     R1023                3   R1189               -6
    X1105     R1190               -5   R1214               -7
    X1106     COST                21   R1117               -8
    X1106     R1025                5   R1003                2
    X1106     R1114               -7   R1306                7
    X1107     COST               -60   R1186               -7
    X1107     R1098                2   R1195               -1
    X1107     R1103               -6   R1206               -3
    X1108     COST                 9   R1194                9
    X1108     R1112                1   R1162               -7
    X1108     R1166               -9   R1332                1
    X1109     COST                 1   R1178                7
    X1109     R1054               -8   R1142               -9
    X1109     R1125                3   R1316                9
    X1110     COST               -28   R1171               -2
    X1110     R1153               -9   R1136                3
    X1110     R1066                1   R1309               -1
    X1111     COST                47   R1136               -3
    X1111     R1172               -2   R1146                7
    X1111     R1083                9   R1302                1
    X1112     COST                16   R1179               -3
    X1112     R1010                2   R1164               -9
    X1112     R1062                6   R1277               -2
    X1113     COST                 7   R1007                5
    X1113     R1051                5   R1139                5
    X1113     R1120                7   R1303               -6
    X1114     COST                -4   R1124               -1
    X1114     R1129                7   R1044               -7
    X1114     R1089               -3   R1341               -4
    X1115     COST               -80   R1063               -9
    X1115     R1065               -5   R1101                3
    X1115     R1108               -9   R1364               -7
    X1116     COST               -40   R1197               -3
    X1116     R1066               -5   R1134               -5
    X1116     R1195                2   R1250               -6
    X1117     COST                67   R1174                1
    X1117     R1146                4   R1103                4
    X1117     R1050                1   R1286               -1
    X1118     COST                18   R1090                8
    X1118     R1138                2   R1114                5
    X1118     R1001               -8   R1329               -5
    X1119     COST                18   R1043                5
    X1119     R1050                4   R1113                2
    X1119     R1054               -3   R1235               -6
    X1120     COST                58   R1162                6
    X1120     R1110               -5   R1191                1
    X1120     R1159                7   R1209                7
    X1121     COST               -37   R1024               -3
    X1121     R1150                5   R1099               -7
    X1121     R1030                3   R1260               -3
    X1122     COST              -132   R1046               -1
    X1122     R1177               -7   R1000               -5
    X1122     R1009                3   R1231               -8
    X1123     COST                 6   R1098               -1
    X1123     R1171                9   R1142               -6
    X1123     R1128                2   R1313                5
    X1124     COST                31   R1153                4
    X1124     R1037                2   R1164                3
    X1124     R1039                6   R1241                3
    X1125     COST                10   R1023                4
    X1125     R1187               -2   R1118               -9
    X1125     R1060                6   R1341               -9
    X1126     COST                 9   R1151                6
    X1126     R1071               -5   R1046               -6
    X1126     R1057                9   R1241               -5
    X1127     COST                 1   R1146               -6
    X1127     R1165                1   R1080                6
    X1127     R1134                7   R1253                1
    X1128     COST                41   R1004                7
    X1128     R1021                7   R1197               -2
    X1128     R1029               -2   R1320               -3
    X1129     COST                70   R1077               -2
    X1129     R1171               -1   R1013                5
    X1129     R1138                6   R1304                4
    X1130     COST              -169   R1122                2
    X1130     R1066               -8   R1082               -4
    X1130     R1054               -5   R1275               -9
    X1131     COST                90   R1042                9
    X1131     R1142                9   R1198                9
    X1131     R1008               -7   R1237                4
    X1132     COST               -97   R1195               -1
    X1132     R1054               -9   R1049                3
    X1132     R1126               -8   R1385               -8
    X1133     COST               -45   R1036               -1
    X1133     R1121               -6   R1149                1
    X1133     R1132               -7   R1287               -4
    X1134     R1192               -1   R1199                6
    X1134     R1190               -3   R1052               -4
    X1134     R1245               -7
    X1135     COST                26   R1183               -4
    X1135     R1064                5   R1031               -7
    X1135     R1154                6   R1299               -2
    X1136     COST                -8   R1039                4
    X1136     R1123               -4   R1055               -6
    X1136     R1178                4   R1292               -9
    X1137     COST                15   R1162               -6
    X1137     R1171               -2   R1114                2
    X1137     R1165                8   R1219                1
    X1138     COST               -13   R1065                1
    X1138     R1156               -3   R1051                5
    X1138     R1036               -4   R1346                9
    X1139     COST                28   R1095                9
    X1139     R1139               -6   R1186               -3
    X1139     R1193                6   R1321                4
    X1140     COST                -6   R1029                5
    X1140     R1113                6   R1047                7
    X1140     R1035               -8   R1229                3
    X1141     COST               -86   R1048               -5
    X1141     R1106               -4   R1138               -1
    X1141     R1080               -3   R1269               -7
    X1142     COST               -59   R1095               -8
    X1142     R1132                3   R1183               -3
    X1142     R1134               -2   R1264               -7
    X1143     COST                -4   R1018               -7
    X1143     R1087                6   R1146               -2
    X1143     R1034                1   R1239                1
    X1144     COST                27   R1173               -9
    X1144     R1095                4   R1019                7
    X1144     R1112               -8   R1206                1
    X1145     R1184               -1   R1058                9
    X1145     R1106               -4   R1129                4
    X1145     R1257               -9
    X1146     COST               -37   R1127               -7
    X1146     R1130                8   R1000               -7
    X1146     R1170               -8   R1367               -5
    X1147     COST                39   R1015                9
    X1147     R1192               -7   R1079                6
    X1147     R1063                4   R1237               -7
    X1148     COST               -11   R1163               -5
    X1148     R1150                1   R1144               -1
    X1148     R1151               -3   R1284               -4
    X1149     COST                15   R1014               -1
    X1149     R1090                9   R1037                4
    X1149     R1024               -9   R1299               -3
    X1150     COST               -35   R1098               -3
    X1150     R1058               -3   R1082               -8
    X1150     R1008                3   R1366               -1
    X1151     COST                 5   R1034               -3
    X1151     R1007               -1   R1033                1
    X1151     R1024                1   R1379               -8
    X1152     COST                30   R1116                7
    X1152     R1017                2   R1090               -5
    X1152     R1165                5   R1350               -4
    X1153     COST               -85   R1199               -9
    X1153     R1106                3   R1127               -9
    X1153     R1063               -7   R1283                8
    X1154     COST                15   R1043               -1
    X1154     R1030                3   R1047               -7
    X1154     R1124                5   R1241                5
    X1155     COST                48   R1130                5
    X1155     R1067                5   R1000                1
    X1155     R1091               -7   R1312                2
    X1156     COST                66   R1111                4
    X1156     R1183                9   R1139               -2
    X1156     R1176               -8   R1394                1
    X1157     COST                17   R1034               -7
    X1157     R1183                6   R1148               -1
    X1157     R1154                1   R1335               -1
    X1158     COST                -8   R1092               -7
    X1158     R1159                5   R1066                3
    X1158     R1153               -2   R1267               -8
    X1159     COST                16   R1035                2
    X1159     R1073               -6   R1193               -7
    X1159     R1026                1   R1255               -3
    X1160     COST               -38   R1160               -1
    X1160     R1197                9   R1041                4
    X1160     R1089                6   R1232               -9
    X1161     COST                62   R1190               -6
    X1161     R1047                6   R1107                4
    X1161     R1113                6   R1246                6
    X1162     COST                62   R1064               -3
    X1162     R1082                9   R1191               -8
    X1162     R1023                2   R1375                8
    X1163     COST                -2   R1109               -5
    X1163     R1077               -4   R1167                8
    X1163     R1009               -6   R1256               -3
    X1164     COST               -10   R1102                5
    X1164     R1100               -7   R1189                6
    X1164     R1093                3   R1386               -4
    X1165     COST                27   R1141                8
    X1165     R1181               -6   R1143                6
    X1165     R1105                4   R1336                2
    X1166     COST                93   R1195               -9
    X1166     R1135                6   R1157                6
    X1166     R1176                8   R1335                9
    X1167     COST               -28   R1149               -2
    X1167     R1140                8   R1081               -9
    X1167     R1130               -8   R1355               -7
    X1168     COST                -9   R1137               -7
    X1168     R1085                9   R1122               -5
    X1168     R1148                1   R1332               -1
    X1169     COST               -48   R1155                6
    X1169     R1071               -3   R1049                6
    X1169     R1189                8   R1225               -9
    X1170     COST                23   R1178                3
    X1170     R1170               -5   R1156                2
    X1170     R1090               -6   R1239                6
    X1171     COST                 8   R1195                5
    X1171     R1077                9   R1091               -6
    X1171     R1092                4   R1268                5
    X1172     COST               112   R1185                6
    X1172     R1015               -3   R1044                3
    X1172     R1047                6   R1260                5
    X1173     COST               -16   R1127                7
    X1173     R1036               -9   R1100               -4
    X1173     R1113               -8   R1277               -4
    X1174     COST                92   R1118               -5
    X1174     R1153                8   R1149                2
    X1174     R1002                5   R1297                5
    X1175     COST                 2   R1032                4
    X1175     R1029               -9   R1187                3
    X1175     R1004                5   R1232               -5
    X1176     COST                39   R1024               -7
    X1176     R1172                6   R1114                2
    X1176     R1179                1   R1378               -6
    X1177     COST                 3   R1018                9
    X1177     R1053                2   R1134               -2
    X1177     R1138               -1   R1282               -1
    X1178     COST               -64   R1106               -6
    X1178     R1181               -7   R1056                3
    X1178     R1059               -9   R1266               -2
    X1179     COST                27   R1162               -6
    X1179     R1132                9   R1070                7
    X1179     R1106                2   R1353               -1
    X1180     COST                -2   R1069               -2
    X1180     R1021               -2   R1128                4
    X1180     R1123               -1   R1292                1
    X1181     COST               -44   R1174                8
    X1181     R1159               -5   R1128               -6
    X1181     R1001                5   R1329               -9
    X1182     COST                53   R1183                9
    X1182     R1087               -8   R1003               -2
    X1182     R1123                5   R1258               -1
    X1183     COST               -40   R1163               -1
    X1183     R1107               -3   R1172               -4
    X1183     R1106               -7   R1343               -1
    X1184     COST                68   R1008               -5
    X1184     R1075                6   R1007               -3
    X1184     R1118                8   R1243               -9
    X1185     COST                -3   R1034               -1
    X1185     R1093                2   R1167                5
    X1185     R1096               -4   R1366               -3
    X1186     COST                10   R1150               -5
    X1186     R1130                2   R1038               -7
    X1186     R1168                4   R1286                2
    X1187     COST                37   R1001               -7
    X1187     R1023                4   R1161               -9
    X1187     R1060                8   R1395               -6
    X1188     COST               -27   R1046                6
    X1188     R1173               -3   R1114               -8
    X1188     R1057               -6   R1351                3
    X1189     COST               -15   R1116               -4
    X1189     R1021               -6   R1140                3
    X1189     R1030               -2   R1342               -9
    X1190     COST                10   R1008               -6
    X1190     R1041               -5   R1192               -4
    X1190     R1114                3   R1312                8
    X1191     COST               -24   R1106                5
    X1191     R1110               -1   R1189               -7
    X1191     R1025               -3   R1272               -6
    X1192     COST               -26   R1162               -8
    X1192     R1064               -7   R1058                8
    X1192     R1106                3   R1399               -6
    X1193     COST                 6   R1007                5
    X1193     R1189                6   R1082               -3
    X1193     R1054                3   R1309               -3
    X1194     COST                16   R1134                2
    X1194     R1000                3   R1128                5
    X1194     R1083                9   R1363               -7
    X1195     COST                14   R1090                7
    X1195     R1011               -5   R1073                6
    X1195     R1142               -4   R1229                9
    X1196     COST               -33   R1081               -9
    X1196     R1087               -8   R1093               -3
    X1196     R1103               -1   R1241                3
    X1197     COST               106   R1011               -2
    X1197     R1130                4   R1030                8
    X1197     R1050               -6   R1298                7
    X1198     COST               -10   R1146               -8
    X1198     R1105               -1   R1009               -8
    X1198     R1033                9   R1278               -9
    X1199     COST               -45   R1126                5
    X1199     R1068               -7   R1179               -3
    X1199     R1116               -9   R1290                9
    X1200     COST                54   R1332                9
    X1200     R1289                7   R1391                5
    X1200     R1379               -3   R1499                1
    X1201     COST               -32   R1378               -7
    X1201     R1390               -4   R1286               -4
    X1201     R1252               -8   R1470                3
    X1202     COST                60   R1396                4
    X1202     R1213                6   R1205                8
    X1202     R1303               -1   R1416                2
    X1203     COST               -19   R1202                3
    X1203     R1360                7   R1344               -5
    X1203     R1299               -7   R1549                8
    X1204     COST               -68   R1262                6
    X1204     R1380               -7   R1303                8
    X1204     R1317               -9   R1478               -9
    X1205     COST                13   R1327                9
    X1205     R1201               -4   R1324               -3
    X1205     R1368                3   R1448               -8
    X1206     COST                79   R1233               -3
    X1206     R1381                1   R1397                4
    X1206     R1217                3   R1546                7
    X1207     COST               -23   R1363                3
    X1207     R1396               -8   R1238                7
    X1207     R1282               -4   R1469                5
    X1208     COST                 8   R1230               -5
    X1208     R1385                1   R1373               -6
    X1208     R1262               -2   R1406                6
    X1209     COST               -58   R1230                9
    X1209     R1232               -8   R1220                3
    X1209     R1228               -3   R1528               -2
    X1210     COST                -7   R1299               -9
    X1210     R1397               -6   R1396                8
    X1210     R1280               -1   R1542                6
    X1211     COST                10   R1299                3
    X1211     R1221               -5   R1372                5
    X1211     R1222                1   R1527               -3
    X1212     COST               118   R1395               -3
    X1212     R1297                5   R1293                7
    X1212     R1254                4   R1405                8
    X1213     COST                 2   R1239               -5
    X1213     R1326                1   R1342               -8
    X1213     R1206                1   R1594                3
    X1214     COST                39   R1324                9
    X1214     R1229                7   R1232                6
    X1214     R1258                6   R1524               -2
    X1215     COST                -9   R1217               -2
    X1215     R1226               -9   R1301               -3
    X1215     R1286               -8   R1562                7
    X1216     COST               -88   R1260               -8
    X1216     R1234               -4   R1353                1
    X1216     R1284                8   R1531               -3
    X1217     COST                25   R1249               -6
    X1217     R1241               -7   R1281                9
    X1217     R1260               -2   R1408                2
    X1218     COST                27   R1386                7
    X1218     R1382                8   R1295               -8
    X1218     R1298               -6   R1425               -9
    X1219     COST                28   R1379               -1
    X1219     R1243               -9   R1350                3
    X1219     R1380                7   R1448                8
    X1220     COST                25   R1282               -6
    X1220     R1365                2   R1332                7
    X1220     R1292               -1   R1401                5
    X1221     COST                10   R1209               -9
    X1221     R1244                7   R1335                8
    X1221     R1341                3   R1439                6
    X1222     COST               -16   R1392               -2
    X1222     R1267                1   R1395               -7
    X1222     R1382               -7   R1578                5
    X1223     COST                59   R1330                6
    X1223     R1307                5   R1335                8
    X1223     R1264               -2   R1428                3
    X1224     COST                33   R1394                9
    X1224     R1265                6   R1261               -4
    X1224     R1239                1   R1454                3
    X1225     COST                 4   R1326               -4
    X1225     R1208               -9   R1324                8
    X1225     R1250               -3   R1595                4
    X1226     COST               -21   R1380               -8
    X1226     R1213               -5   R1226                4
    X1226     R1253                3   R1544               -4
    X1227     COST               -97   R1387                8
    X1227     R1340                2   R1356               -6
    X1227     R1206               -8   R1590               -7
    X1228     COST               -27   R1274                9
    X1228     R1327               -1   R1390               -3
    X1228     R1356                5   R1439               -3
    X1229     COST                16   R1337                3
    X1229     R1230               -7   R1256                7
    X1229     R1273                5   R1448                1
    X1230     COST               -12   R1321               -1
    X1230     R1274               -5   R1208               -5
    X1230     R1336               -4   R1403               -8
    X1231     COST                13   R1255               -2
    X1231     R1213               -6   R1394               -3
    X1231     R1369               -8   R1408                2
    X1232     COST                 4   R1396                9
    X1232     R1207               -6   R1251                8
    X1232     R1398                4   R1400               -2
    X1233     COST               -27   R1393                8
    X1233     R1346               -7   R1227                3
    X1233     R1309                9   R1402               -6
    X1234     COST               -18   R1297               -2
    X1234     R1311                1   R1279                9
    X1234     R1288                1   R1494                7
    X1235     COST               -61   R1282               -7
    X1235     R1278                3   R1228               -3
    X1235     R1214               -5   R1582                9
    X1236     COST                17   R1218                7
    X1236     R1304               -9   R1261                3
    X1236     R1346               -7   R1524               -6
    X1237     COST               -16   R1289                4
    X1237     R1271                8   R1324                2
    X1237     R1382               -9   R1497               -5
    X1238     COST                 5   R1367                6
    X1238     R1223               -4   R1340                5
    X1238     R1370                5   R1502                1
    X1239     R1354               -9   R1345               -4
    X1239     R1355               -7   R1310                4
    X1239     R1559               -6
    X1240     COST               -47   R1252               -8
    X1240     R1206               -9   R1234                6
    X1240     R1343               -1   R1431               -6
    X1241     COST                16   R1289                7
    X1241     R1253                2   R1389                4
    X1241     R1392                6   R1540                5
    X1242     COST                24   R1373                5
    X1242     R1366               -1   R1212                9
    X1242     R1399                4   R1417               -6
    X1243     COST                70   R1226               -2
    X1243     R1285               -3   R1312               -1
    X1243     R1282                1   R1408                9
    X1244     R1215                1   R1263                2
    X1244     R1311                9   R1306               -2
    X1244     R1471                3
    X1245     COST               -38   R1303               -7
    X1245     R1238               -9   R1304                4
    X1245     R1395                4   R1457               -8
    X1246     COST               -29   R1351               -9
    X1246     R1255                1   R1299               -3
    X1246     R1380               -4   R1504                7
    X1247     COST               -27   R1259                6
    X1247     R1271               -1   R1281               -7
    X1247     R1235               -2   R1455                9
    X1248     COST               -13   R1339               -4
    X1248     R1266                4   R1396               -2
    X1248     R1244               -4   R1401               -9
    X1249     COST               -35   R1344               -9
    X1249     R1322               -3   R1328                5
    X1249     R1352                6   R1466                6
    X1250     COST                40   R1219               -8
    X1250     R1329                8   R1365               -1
    X1250     R1346               -4   R1413               -3
    X1251     COST               -16   R1399               -8
    X1251     R1304               -8   R1380               -9
    X1251     R1282                6   R1484               -8
    X1252     COST               -23   R1243               -3
    X1252     R1378               -4   R1295               -7
    X1252     R1347               -1   R1475                8
    X1253     COST               -13   R1242                9
    X1253     R1272               -6   R1346               -4
    X1253     R1266               -2   R1472               -5
    X1254     COST                78   R1273               -4
    X1254     R1321                1   R1384                6
    X1254     R1343                5   R1435                7
    X1255     COST                12   R1287                1
    X1255     R1245               -4   R1397                2
    X1255     R1337               -1   R1595               -4
    X1256     COST               -16   R1305               -8
    X1256     R1321               -4   R1308               -1
    X1256     R1277               -9   R1459                8
    X1257     COST                -9   R1202                3
    X1257     R1334                2   R1277                8
    X1257     R1324                3   R1592               -6
    X1258     COST                60   R1237               -8
    X1258     R1283               -1   R1288                5
    X1258     R1205                5   R1408                5
    X1259     COST                54   R1349                2
    X1259     R1380                2   R1348               -4
    X1259     R1322                8   R1576               -4
    X1260     COST               -26   R1244                9
    X1260     R1221                1   R1377               -8
    X1260     R1317                8   R1533               -5
    X1261     R1323               -5   R1396               -5
    X1261     R1379               -2   R1255                3
    X1261     R1576                5
    X1262     COST                96   R1386               -6
    X1262     R1267                1   R1336                7
    X1262     R1320               -5   R1569                9
    X1263     COST               -17   R1285               -1
    X1263     R1298               -6   R1385               -6
    X1263     R1217                3   R1435                9
    X1264     COST                21   R1249               -5
    X1264     R1335               -7   R1282                5
    X1264     R1245                6   R1407                7
    X1265     COST                14   R1282                2
    X1265     R1367                8   R1301                5
    X1265     R1313               -4   R1493                7
    X1266     COST                16   R1363               -5
    X1266     R1294                4   R1355               -1
    X1266     R1362                2   R1520                3
    X1267     COST               -71   R1270               -6
    X1267     R1321               -8   R1266                2
    X1267     R1222               -9   R1536                3
    X1268     COST                12   R1353               -5
    X1268     R1386                7   R1218                8
    X1268     R1208               -8   R1458               -2
    X1269     COST                30   R1251                6
    X1269     R1259                6   R1360               -9
    X1269     R1341                8   R1416               -9
    X1270     COST                15   R1293               -5
    X1270     R1224                4   R1211               -7
    X1270     R1397                9   R1496               -5
    X1271     COST               -42   R1279               -5
    X1271     R1254                9   R1316                4
    X1271     R1273               -6   R1567               -6
    X1272     R1240               -8   R1249                5
    X1272     R1369               -4   R1216                4
    X1272     R1532                7
    X1273     COST                48   R1278                5
    X1273     R1398               -6   R1286               -6
    X1273     R1237               -3   R1569                6
    X1274     COST               -33   R1302               -4
    X1274     R1351               -7   R1310               -2
    X1274     R1389                6   R1526               -8
    X1275     COST                19   R1340                1
    X1275     R1237                1   R1302                6
    X1275     R1255                6   R1596                1
    X1276     COST               -57   R1206               -4
    X1276     R1251               -5   R1319                2
    X1276     R1354                9   R1588               -6
    X1277     COST               122   R1348                5
    X1277     R1347                7   R1280                9
    X1277     R1255               -5   R1460                5
    X1278     COST                 4   R1216               -8
    X1278     R1348                5   R1285               -7
    X1278     R1376               -1   R1530               -3
    X1279     R1286               -6   R1365               -3
    X1279     R1327                9   R1391               -5
    X1279     R1482                1
    X1280     COST                25   R1390               -5
    X1280     R1372                7   R1358                9
    X1280     R1210                4   R1587               -3
    X1281     COST               -12   R1369               -4
    X1281     R1286               -2   R1216                2
    X1281     R1320                6   R1517               -7
    X1282     COST                -6   R1357                3
    X1282     R1272                2   R1257                1
    X1282     R1333               -8   R1496               -1
    X1283     COST                36   R1292               -9
    X1283     R1294               -9   R1240                2
    X1283     R1209                9   R1450               -8
    X1284     COST                21   R1263               -7
    X1284     R1308                7   R1211               -2
    X1284     R1341               -4   R1477               -3
    X1285     COST               -31   R1344                1
    X1285     R1386                5   R1329               -3
    X1285     R1225               -3   R1587               -9
    X1286     COST               -20   R1376               -6
    X1286     R1210               -5   R1273                3
    X1286     R1327                7   R1536               -5
    X1287     COST               123   R1296                7
    X1287     R1293                9   R1395               -1
    X1287     R1397                7   R1488                3
    X1288     COST                96   R1339                7
    X1288     R1327                1   R1341                3
    X1288     R1356                5   R1496                9
    X1289     COST                21   R1377               -9
    X1289     R1296               -4   R1258                2
    X1289     R1256               -9   R1474                4
    X1290     COST               -41   R1200               -6
    X1290     R1287               -7   R1388               -8
    X1290     R1248               -1   R1563                8
    X1291     COST                37   R1386                1
    X1291     R1213               -5   R1288               -5
    X1291     R1277               -7   R1422                8
    X1292     COST                25   R1338               -8
    X1292     R1282                7   R1206                8
    X1292     R1394                9   R1569               -5
    X1293     COST               -84   R1266               -9
    X1293     R1290               -2   R1205               -3
    X1293     R1392                9   R1461               -3
    X1294     COST               -36   R1316               -8
    X1294     R1220               -6   R1346               -2
    X1294     R1332               -7   R1578                9
    X1295     COST               -39   R1332                7
    X1295     R1371                2   R1322               -8
    X1295     R1303               -1   R1595               -8
    X1296     COST               -41   R1224               -3
    X1296     R1239               -7   R1251               -2
    X1296     R1340                1   R1543               -2
    X1297     COST                -9   R1247               -4
    X1297     R1257                6   R1243               -8
    X1297     R1251               -3   R1449                4
    X1298     COST                25   R1246               -3
    X1298     R1341               -2   R1301                9
    X1298     R1243               -3   R1422                4
    X1299     COST                78   R1256               -1
    X1299     R1390                8   R1274               -4
    X1299     R1251                9   R1577               -7
    X1300     COST               -52   R1332               -4
    X1300     R1246               -2   R1253                2
    X1300     R1374               -5   R1402               -6
    X1301     COST               -41   R1289                2
    X1301     R1221               -4   R1267               -5
    X1301     R1215                4   R1463               -3
    X1302     COST                 1   R1366               -9
    X1302     R1279                2   R1261               -9
    X1302     R1307               -2   R1542                3
    X1303     COST                10   R1307                7
    X1303     R1359                4   R1340               -9
    X1303     R1362                5   R1480               -6
    X1304     COST                29   R1317               -5
    X1304     R1280                8   R1235                5
    X1304     R1271                4   R1558               -1
    X1305     COST                11   R1356               -2
    X1305     R1271               -8   R1201               -7
    X1305     R1300                6   R1518               -5
    X1306     COST               -24   R1398               -4
    X1306     R1393               -3   R1228               -6
    X1306     R1373                3   R1476                1
    X1307     COST               -18   R1335               -1
    X1307     R1356               -7   R1309               -6
    X1307     R1213                6   R1455                2
    X1308     COST                65   R1205                9
    X1308     R1225               -3   R1298               -8
    X1308     R1381               -2   R1574                7
    X1309     COST                31   R1355               -9
    X1309     R1309               -3   R1243                6
    X1309     R1338                9   R1488               -1
    X1310     COST               -28   R1303                1
    X1310     R1221                3   R1370               -4
    X1310     R1326               -4   R1565               -9
    X1311     COST                -5   R1374               -6
    X1311     R1287               -2   R1315               -3
    X1311     R1280                7   R1518                5
    X1312     COST               -56   R1247                4
    X1312     R1271                2   R1349               -4
    X1312     R1203               -9   R1587               -9
    X1313     COST                53   R1351                2
    X1313     R1276                8   R1365                6
    X1313     R1245                8   R1513               -8
    X1314     COST                30   R1395               -9
    X1314     R1288               -7   R1205                5
    X1314     R1362               -4   R1417                9
    X1315     COST                67   R1268                2
    X1315     R1212                7   R1375               -1
    X1315     R1370                1   R1569                9
    X1316     COST                13   R1391                8
    X1316     R1280                5   R1302                4
    X1316     R1376               -3   R1431                9
    X1317     COST               -78   R1317                2
    X1317     R1343               -6   R1287               -8
    X1317     R1288               -4   R1502               -2
    X1318     R1309               -4   R1378                5
    X1318     R1354               -7   R1262                9
    X1318     R1442                9
    X1319     COST               -44   R1202                8
    X1319     R1399               -2   R1294               -6
    X1319     R1324               -8   R1525               -6
    X1320     COST               -24   R1339               -5
    X1320     R1238               -6   R1210               -4
    X1320     R1389               -2   R1481               -6
    X1321     COST                 9   R1275                5
    X1321     R1281               -2   R1385               -4
    X1321     R1302               -3   R1567                2
    X1322     COST               -53   R1286               -8
    X1322     R1282               -9   R1272               -8
    X1322     R1204                2   R1538               -2
    X1323     COST                 2   R1376                2
    X1323     R1342                9   R1240               -4
    X1323     R1288                9   R1470               -6
    X1324     COST                -3   R1235               -8
    X1324     R1364                4   R1247               -4
    X1324     R1257                5   R1579               -5
    X1325     COST               -59   R1256                2
    X1325     R1334               -9   R1314               -6
    X1325     R1384               -5   R1508               -3
    X1326     COST               -50   R1297               -6
    X1326     R1340               -9   R1212                4
    X1326     R1365                3   R1554                2
    X1327     COST                28   R1230               -5
    X1327     R1241               -5   R1360               -6
    X1327     R1243               -5   R1509                7
    X1328     COST               -45   R1300               -8
    X1328     R1250                5   R1323                5
    X1328     R1289                7   R1517               -2
    X1329     COST                45   R1398               -7
    X1329     R1229               -1   R1344                6
    X1329     R1300                3   R1546               -3
    X1330     COST               -92   R1339               -4
    X1330     R1248               -7   R1209               -9
    X1330     R1323               -9   R1452                4
    X1331     COST                 8   R1259                8
    X1331     R1243               -6   R1264                1
    X1331     R1366               -9   R1406                5
    X1332     COST                38   R1333               -7
    X1332     R1356                8   R1342               -8
    X1332     R1205                3   R1588               -2
    X1333     COST               -10   R1246                5
    X1333     R1242                2   R1221               -5
    X1333     R1373               -5   R1449               -8
    X1334     COST                17   R1353                7
    X1334     R1316                5   R1208                8
    X1334     R1271               -5   R1410                6
    X1335     COST                20   R1302               -3
    X1335     R1305                5   R1365               -9
    X1335     R1292                5   R1476               -4
    X1336     R1247                4   R1339                2
    X1336     R1311                3   R1272                4
    X1336     R1532                1
    X1337     COST               -48   R1209               -6
    X1337     R1382                5   R1334               -5
    X1337     R1352                7   R1426                9
    X1338     COST               -34   R1211                6
    X1338     R1262                1   R1362                5
    X1338     R1323                4   R1410               -9
    X1339     COST               -38   R1263                9
    X1339     R1317               -5   R1361               -6
    X1339     R1218               -7   R1541                6
    X1340     COST               -62   R1216               -5
    X1340     R1335               -1   R1322               -8
    X1340     R1362                2   R1502               -6
    X1341     COST               -23   R1226               -1
    X1341     R1267               -9   R1396               -6
    X1341     R1277                4   R1525                9
    X1342     COST                 4   R1263               -4
    X1342     R1358               -3   R1213                4
    X1342     R1335               -5   R1577                5
    X1343     COST                16   R1335                8
    X1343     R1318                5   R1396               -4
    X1343     R1280               -9   R1488               -5
    X1344     COST                 8   R1244                8
    X1344     R1243                3   R1378               -7
    X1344     R1288               -8   R1405                2
    X1345     COST                 2   R1367               -5
    X1345     R1373               -5   R1212                5
    X1345     R1286               -7   R1562               -1
    X1346     COST                13   R1332               -2
    X1346     R1281                6   R1381                2
    X1346     R1249                7   R1485               -9
    X1347     COST                75   R1299                3
    X1347     R1380                6   R1343                9
    X1347     R1266                2   R1556               -1
    X1348     COST                56   R1211                1
    X1348     R1342               -4   R1205                8
    X1348     R1212               -3   R1503               -6
    X1349     COST                 1   R1382                2
    X1349     R1212               -6   R1277               -3
    X1349     R1243                5   R1489               -1
    X1350     COST               -36   R1334                9
    X1350     R1287               -8   R1284               -9
    X1350     R1389               -6   R1549               -7
    X1351     COST                25   R1315               -1
    X1351     R1390                3   R1244                8
    X1351     R1298                6   R1552               -9
    X1352     COST               -40   R1226               -8
    X1352     R1261               -8   R1368               -4
    X1352     R1309                5   R1466               -9
    X1353     COST               -54   R1206               -8
    X1353     R1309               -8   R1226                8
    X1353     R1201               -6   R1477                3
    X1354     COST                -3   R1234               -4
    X1354     R1278                3   R1262                8
    X1354     R1358                9   R1568                1
    X1355     COST               -28   R1331               -7
    X1355     R1309               -8   R1365               -9
    X1355     R1240                3   R1568               -8
    X1356     COST               -19   R1348               -5
    X1356     R1340                6   R1200               -1
    X1356     R1332                3   R1407               -9
    X1357     COST                28   R1231                4
    X1357     R1367               -4   R1313                1
    X1357     R1350                2   R1423                5
    X1358     COST               -30   R1230                7
    X1358     R1226               -5   R1365                9
    X1358     R1384               -6   R1471               -8
    X1359     COST                69   R1209                4
    X1359     R1267               -1   R1383               -2
    X1359     R1219               -8   R1537                5
    X1360     COST                60   R1363                1
    X1360     R1264                9   R1228               -3
    X1360     R1360                5   R1526                5
    X1361     COST               -81   R1243                3
    X1361     R1384               -9   R1252               -9
    X1361     R1265               -9   R1411               -2
    X1362     COST                40   R1356               -9
    X1362     R1316               -9   R1319                2
    X1362     R1231                6   R1585                3
    X1363     COST               147   R1205                9
    X1363     R1221                7   R1330                8
    X1363     R1323                2   R1460                8
    X1364     COST                68   R1397                2
    X1364     R1369                1   R1249                6
    X1364     R1206                9   R1501               -3
    X1365     COST                16   R1252                9
    X1365     R1285                3   R1245                3
    X1365     R1305                2   R1557               -6
    X1366     COST                15   R1378                9
    X1366     R1296               -5   R1370                8
    X1366     R1223               -7   R1572                6
    X1367     COST               -36   R1223                6
    X1367     R1338               -1   R1237               -2
    X1367     R1302                9   R1528               -9
    X1368     COST                49   R1292               -3
    X1368     R1216               -9   R1342                2
    X1368     R1283                8   R1511                1
    X1369     COST               -56   R1225               -3
    X1369     R1299               -6   R1335               -7
    X1369     R1237               -5   R1451                7
    X1370     COST                22   R1292                7
    X1370     R1360                7   R1285                6
    X1370     R1201                4   R1491                9
    X1371     COST                97   R1378                5
    X1371     R1281                7   R1278               -7
    X1371     R1368                9   R1450                8
    X1372     COST               -38   R1336               -8
    X1372     R1241                4   R1214               -4
    X1372     R1353               -8   R1580               -7
    X1373     COST                82   R1395               -8
    X1373     R1285                5   R1228                7
    X1373     R1382                9   R1536               -7
    X1374     COST                42   R1352                6
    X1374     R1217                6   R1350               -3
    X1374     R1374                1   R1490               -4
    X1375     COST                24   R1359               -7
    X1375     R1240               -9   R1337                6
    X1375     R1270                4   R1477                2
    X1376     COST                59   R1206                5
    X1376     R1266                9   R1327                9
    X1376     R1389               -9   R1421               -2
    X1377     COST                17   R1266               -4
    X1377     R1373                8   R1206                4
    X1377     R1344                5   R1428               -6
    X1378     COST               -48   R1366               -8
    X1378     R1373                8   R1264               -9
    X1378     R1225                6   R1500               -9
    X1379     COST                56   R1307                9
    X1379     R1222               -3   R1350               -9
    X1379     R1267               -1   R1465               -1
    X1380     COST                 2   R1327               -2
    X1380     R1396               -2   R1223                7
    X1380     R1307                8   R1440               -6
    X1381     COST               -45   R1217               -9
    X1381     R1304                9   R1328                5
    X1381     R1256               -6   R1529               -2
    X1382     COST                72   R1357                7
    X1382     R1237               -1   R1317               -3
    X1382     R1279                1   R1440                8
    X1383     COST                45   R1210                7
    X1383     R1278               -3   R1259                1
    X1383     R1317               -3   R1578                4
    X1384     COST               -43   R1231               -2
    X1384     R1370                9   R1397               -6
    X1384     R1343               -3   R1548                8
    X1385     COST                58   R1350                5
    X1385     R1221                5   R1213                8
    X1385     R1338               -6   R1459                8
    X1386     COST               -42   R1360               -2
    X1386     R1216                2   R1389               -5
    X1386     R1307               -6   R1561                4
    X1387     COST                20   R1317               -5
    X1387     R1278               -4   R1331                8
    X1387     R1210               -5   R1417                7
    X1388     COST               -48   R1316               -2
    X1388     R1354               -6   R1247               -9
    X1388     R1207               -8   R1477                8
    X1389     COST                 1   R1252                4
    X1389     R1208                2   R1316                1
    X1389     R1310               -9   R1557               -1
    X1390     COST               -64   R1226                5
    X1390     R1307               -4   R1326               -8
    X1390     R1221                5   R1588               -8
    X1391     COST               -95   R1246                3
    X1391     R1343               -7   R1319                3
    X1391     R1300               -9   R1454                2
    X1392     COST               -56   R1392                3
    X1392     R1314               -2   R1266               -7
    X1392     R1264               -5   R1443                8
    X1393     COST               -20   R1230                3
    X1393     R1232               -3   R1383               -5
    X1393     R1379                5   R1561               -1
    X1394     COST                14   R1388                5
    X1394     R1204                1   R1365                6
    X1394     R1233               -7   R1579                6
    X1395     COST               -91   R1356                6
    X1395     R1328               -8   R1201               -7
    X1395     R1264               -7   R1581               -8
    X1396     COST               -41   R1332                3
    X1396     R1321               -7   R1253               -7
    X1396     R1221               -7   R1428                5
    X1397     COST                29   R1277                7
    X1397     R1236               -7   R1260                3
    X1397     R1367                8   R1473               -5
    X1398     COST                54   R1395                2
    X1398     R1202               -3   R1266                5
    X1398     R1256                7   R1532               -6
    X1399     COST                46   R1347                7
    X1399     R1216               -5   R1353               -7
    X1399     R1295                9   R1412               -5
    X1400     COST                -3   R1522               -5
    X1400     R1497               -7   R1442                3
    X1400     R1519                5   R1635               -4
    X1401     COST                60   R1517               -3
    X1401     R1574                2   R1518               -5
    X1401     R1585                7   R1696                2
    X1402     COST                51   R1429                3
    X1402     R1452                6   R1428                2
    X1402     R1462               -7   R1652               -3
    X1403     COST                 9   R1421                2
    X1403     R1423               -7   R1491               -5
    X1403     R1472               -7   R1741                7
    X1404     COST               -11   R1581               -2
    X1404     R1598               -6   R1477               -1
    X1404     R1525                5   R1643                6
    X1405     COST                54   R1563               -6
    X1405     R1548               -2   R1457                9
    X1405     R1598                5   R1677                8
    X1406     COST                45   R1522                2
    X1406     R1539                6   R1437                9
    X1406     R1549                3   R1752                5
    X1407     COST                -8   R1515               -6
    X1407     R1435               -8   R1442               -4
    X1407     R1541                9   R1698                6
    X1408     COST                44   R1521               -9
    X1408     R1489                6   R1541               -5
    X1408     R1495                4   R1629                1
    X1409     COST                84   R1454               -1
    X1409     R1571                9   R1497               -9
    X1409     R1410                1   R1620               -6
    X1410     COST               -18   R1434                1
    X1410     R1522                4   R1404                7
    X1410     R1441               -2   R1770               -2
    X1411     COST                24   R1594                1
    X1411     R1595                3   R1580               -3
    X1411     R1550                7   R1731                2
    X1412     COST               -56   R1492               -5
    X1412     R1542               -7   R1582                8
    X1412     R1418                8   R1717               -4
    X1413     COST               -85   R1494               -3
    X1413     R1410               -1   R1490                9
    X1413     R1520               -8   R1718               -9
    X1414     COST               -16   R1599                1
    X1414     R1554               -5   R1445                6
    X1414     R1478               -1   R1708               -2
    X1415     COST                31   R1518               -3
    X1415     R1585                5   R1491               -2
    X1415     R1400                9   R1728                4
    X1416     COST               -69   R1533               -9
    X1416     R1442               -3   R1596                7
    X1416     R1560               -3   R1665                5
    X1417     COST               -16   R1548               -4
    X1417     R1437               -3   R1582                7
    X1417     R1423               -8   R1654                4
    X1418     COST               -51   R1515               -8
    X1418     R1484                7   R1513               -2
    X1418     R1598               -9   R1628               -1
    X1419     COST               -74   R1404                4
    X1419     R1480               -9   R1579               -3
    X1419     R1449               -9   R1776               -1
    X1420     COST               -13   R1516                3
    X1420     R1574                2   R1575               -4
    X1420     R1576               -5   R1762               -2
    X1421     COST                24   R1474                9
    X1421     R1416               -9   R1490                1
    X1421     R1439               -9   R1768               -2
    X1422     COST                45   R1557                1
    X1422     R1431               -1   R1562               -3
    X1422     R1486                6   R1660                1
    X1423     COST                14   R1502                2
    X1423     R1584                2   R1510                2
    X1423     R1467               -6   R1758               -7
    X1424     COST                48   R1484                2
    X1424     R1562               -6   R1542                9
    X1424     R1559               -4   R1756               -5
    X1425     COST               -18   R1416                9
    X1425     R1447               -2   R1425               -1
    X1425     R1540               -6   R1781                9
    X1426     COST                22   R1495                3
    X1426     R1419               -2   R1416                6
    X1426     R1509                7   R1668               -3
    X1427     COST               101   R1579                9
    X1427     R1517                1   R1585                8
    X1427     R1577                9   R1736               -1
    X1428     COST                 7   R1591               -3
    X1428     R1575                9   R1418                4
    X1428     R1537                2   R1683               -7
    X1429     COST                77   R1595                2
    X1429     R1552               -6   R1447                7
    X1429     R1497                4   R1610                1
    X1430     COST                -4   R1491                2
    X1430     R1588                3   R1427                5
    X1430     R1563               -3   R1718               -6
    X1431     COST                18   R1559                8
    X1431     R1428                9   R1403                2
    X1431     R1585                3   R1765               -4
    X1432     COST               -11   R1588               -6
    X1432     R1437                1   R1592               -4
    X1432     R1543                4   R1608                7
    X1433     COST               -20   R1494               -6
    X1433     R1467               -8   R1586               -9
    X1433     R1580                4   R1718               -4
    X1434     COST                 3   R1586               -7
    X1434     R1448                3   R1423                9
    X1434     R1599                9   R1681               -1
    X1435     COST               -25   R1432               -6
    X1435     R1472               -3   R1567               -1
    X1435     R1475                4   R1683               -8
    X1436     COST                19   R1575                4
    X1436     R1577               -7   R1474                7
    X1436     R1444               -5   R1726               -7
    X1437     COST                48   R1417                5
    X1437     R1522               -2   R1551                9
    X1437     R1418               -2   R1754                6
    X1438     COST               -72   R1465               -6
    X1438     R1424               -9   R1407               -1
    X1438     R1550               -5   R1709                8
    X1439     COST                30   R1527                6
    X1439     R1409               -6   R1550               -9
    X1439     R1526                2   R1745               -8
    X1440     COST                 3   R1528               -8
    X1440     R1480                5   R1558                9
    X1440     R1425                7   R1742                1
    X1441     COST               -17   R1568               -9
    X1441     R1409               -2   R1457               -4
    X1441     R1505                1   R1659               -1
    X1442     COST                 8   R1512                2
    X1442     R1484               -5   R1468               -4
    X1442     R1431                9   R1689               -4
    X1443     COST               109   R1433                9
    X1443     R1594                6   R1496                6
    X1443     R1432                9   R1675                2
    X1444     COST                69   R1556                5
    X1444     R1410                5   R1474                2
    X1444     R1555                6   R1679               -2
    X1445     COST               -18   R1474               -2
    X1445     R1525                3   R1493                1
    X1445     R1404               -8   R1683                5
    X1446     COST                 2   R1437                3
    X1446     R1492               -7   R1575               -7
    X1446     R1522                3   R1705                1
    X1447     COST                71   R1412                9
    X1447     R1487                6   R1551               -3
    X1447     R1586                4   R1784                2
    X1448     COST                 4   R1492                7
    X1448     R1460               -3   R1515               -1
    X1448     R1413                8   R1754                4
    X1449     COST                28   R1515               -5
    X1449     R1406               -4   R1432                9
    X1449     R1440                2   R1768               -6
    X1450     COST                71   R1440               -1
    X1450     R1487               -6   R1504                4
    X1450     R1531                7   R1688                5
    X1451     COST               -32   R1406                2
    X1451     R1598               -7   R1521               -3
    X1451     R1425               -1   R1702               -2
    X1452     COST                14   R1443                2
    X1452     R1497                4   R1516               -4
    X1452     R1596                6   R1788               -8
    X1453     COST                14   R1473                6
    X1453     R1513               -8   R1520               -7
    X1453     R1445                1   R1629                9
    X1454     COST                 2   R1438                1
    X1454     R1443               -1   R1504                2
    X1454     R1464               -7   R1602               -2
    X1455     COST               -18   R1561               -4
    X1455     R1473                2   R1522                1
    X1455     R1554               -1   R1700               -8
    X1456     COST                88   R1450                4
    X1456     R1491                5   R1584                2
    X1456     R1597                1   R1754                8
    X1457     COST                18   R1515               -2
    X1457     R1433                2   R1417                2
    X1457     R1491                9   R1792                9
    X1458     COST              -100   R1563               -2
    X1458     R1589                4   R1462               -9
    X1458     R1463               -6   R1779               -8
    X1459     COST                40   R1409                5
    X1459     R1533                8   R1456                5
    X1459     R1402               -5   R1699               -4
    X1460     COST               -57   R1499                8
    X1460     R1406                8   R1506                2
    X1460     R1472                9   R1773               -9
    X1461     COST                -7   R1543                5
    X1461     R1573                9   R1475               -5
    X1461     R1459               -7   R1633                1
    X1462     COST               -58   R1487                4
    X1462     R1549               -2   R1491               -5
    X1462     R1439               -8   R1628                8
    X1463     COST               -29   R1451               -9
    X1463     R1419                9   R1490                6
    X1463     R1415               -8   R1738                2
    X1464     COST                53   R1526                7
    X1464     R1572               -7   R1479               -3
    X1464     R1429                9   R1683               -6
    X1465     COST                -2   R1590                5
    X1465     R1541               -3   R1404               -8
    X1465     R1447               -3   R1790               -1
    X1466     COST                12   R1494               -7
    X1466     R1428               -3   R1487               -5
    X1466     R1413               -5   R1647                6
    X1467     COST                38   R1515                1
    X1467     R1481               -2   R1575               -6
    X1467     R1414                3   R1701                4
    X1468     COST               -50   R1546               -9
    X1468     R1406               -3   R1555                5
    X1468     R1490               -5   R1682               -5
    X1469     COST               -12   R1422                3
    X1469     R1482               -8   R1543                7
    X1469     R1594                3   R1756               -7
    X1470     COST                51   R1429                3
    X1470     R1570                2   R1518               -7
    X1470     R1409                2   R1619                5
    X1471     COST                -2   R1482               -5
    X1471     R1469               -1   R1453               -9
    X1471     R1431                1   R1783                8
    X1472     COST                -4   R1539               -8
    X1472     R1493               -3   R1435               -4
    X1472     R1581                9   R1746                8
    X1473     COST               -40   R1529                8
    X1473     R1400                5   R1456               -5
    X1473     R1476               -5   R1739               -5
    X1474     COST               -76   R1594               -1
    X1474     R1551               -6   R1441               -8
    X1474     R1549               -8   R1710               -8
    X1475     COST               107   R1498               -1
    X1475     R1452                9   R1419                4
    X1475     R1456                9   R1675               -9
    X1476     COST               -36   R1476                8
    X1476     R1443               -7   R1520                4
    X1476     R1413                9   R1796               -2
    X1477     COST               -20   R1523               -5
    X1477     R1539               -7   R1508                1
    X1477     R1402               -4   R1636               -3
    X1478     COST                30   R1437                4
    X1478     R1414                6   R1557               -5
    X1478     R1518               -5   R1763               -5
    X1479     COST               -21   R1490                7
    X1479     R1538                9   R1519               -1
    X1479     R1595               -8   R1687               -1
    X1480     COST               106   R1522               -3
    X1480     R1463               -1   R1447                8
    X1480     R1402                7   R1710               -2
    X1481     COST                -6   R1472               -2
    X1481     R1572               -3   R1479                7
    X1481     R1507                5   R1793               -7
    X1482     COST               -33   R1410                3
    X1482     R1499                4   R1543               -9
    X1482     R1407                1   R1616               -9
    X1483     COST                90   R1538               -6
    X1483     R1463                9   R1470               -2
    X1483     R1580                5   R1711                3
    X1484     COST               -12   R1546               -2
    X1484     R1486               -1   R1428               -6
    X1484     R1549                4   R1749               -4
    X1485     COST               -55   R1538                9
    X1485     R1591                4   R1531               -9
    X1485     R1539                3   R1643               -1
    X1486     COST                69   R1431                3
    X1486     R1527               -4   R1444               -1
    X1486     R1447                8   R1609                9
    X1487     COST              -107   R1576               -5
    X1487     R1415               -5   R1548               -7
    X1487     R1485               -6   R1640               -5
    X1488     COST                -5   R1572                8
    X1488     R1533               -9   R1592                6
    X1488     R1485                3   R1652                6
    X1489     COST                 9   R1589               -1
    X1489     R1424                2   R1506                2
    X1489     R1480               -1   R1634                1
    X1490     COST              -104   R1431               -2
    X1490     R1435               -1   R1550                4
    X1490     R1571               -7   R1632               -8
    X1491     COST                14   R1587               -9
    X1491     R1458                7   R1541                1
    X1491     R1529                9   R1782                1
    X1492     COST                34   R1515               -8
    X1492     R1468               -4   R1520                9
    X1492     R1441                8   R1645               -1
    X1493     COST                -2   R1422               -9
    X1493     R1439                9   R1451                1
    X1493     R1524               -4   R1645               -2
    X1494     COST                 2   R1532               -6
    X1494     R1507               -1   R1495               -7
    X1494     R1523                1   R1671                4
    X1495     COST                63   R1540                8
    X1495     R1571                7   R1404               -1
    X1495     R1581               -3   R1658               -3
    X1496     COST                28   R1451               -7
    X1496     R1550               -1   R1510               -7
    X1496     R1592                7   R1708               -3
    X1497     COST                45   R1558               -2
    X1497     R1467                8   R1424                8
    X1497     R1497                7   R1727               -1
    X1498     R1455               -7   R1420               -9
    X1498     R1540               -7   R1566               -9
    X1498     R1708                7
    X1499     COST                16   R1516                1
    X1499     R1580                7   R1446               -4
    X1499     R1562               -5   R1610               -2
    X1500     COST                58   R1597               -2
    X1500     R1406               -4   R1473               -2
    X1500     R1530                7   R1722                6
    X1501     COST               -64   R1522               -1
    X1501     R1535                2   R1544               -9
    X1501     R1415               -3   R1799               -5
    X1502     COST               -68   R1521                2
    X1502     R1478               -9   R1574                5
    X1502     R1438               -7   R1611                7
    X1503     COST                37   R1522                5
    X1503     R1592                8   R1452               -7
    X1503     R1582               -3   R1626                8
    X1504     COST               -13   R1537               -1
    X1504     R1595               -6   R1598                2
    X1504     R1475                4   R1637               -7
    X1505     R1400                4   R1485                7
    X1505     R1596                2   R1416               -4
    X1505     R1656                3
    X1506     COST              -103   R1503                9
    X1506     R1459               -7   R1488                3
    X1506     R1463               -8   R1688               -6
    X1507     COST                36   R1474                8
    X1507     R1540               -7   R1465               -9
    X1507     R1520               -7   R1658                3
    X1508     COST                15   R1534                8
    X1508     R1462                6   R1454               -3
    X1508     R1407               -5   R1756                5
    X1509     COST                 6   R1545               -4
    X1509     R1404                7   R1543                3
    X1509     R1485                2   R1653               -6
    X1510     COST                42   R1407                2
    X1510     R1471                4   R1524                7
    X1510     R1400               -2   R1718                4
    X1511     COST                64   R1513               -4
    X1511     R1413                4   R1461                3
    X1511     R1439                8   R1719               -8
    X1512     COST                53   R1498               -9
    X1512     R1433                2   R1483                4
    X1512     R1504               -1   R1772                2
    X1513     COST                62   R1564                2
    X1513     R1566               -1   R1572                9
    X1513     R1542                6   R1794               -3
    X1514     COST               -20   R1464                7
    X1514     R1591               -4   R1538               -7
    X1514     R1530               -4   R1713                6
    X1515     COST                81   R1488                6
    X1515     R1577                7   R1410                4
    X1515     R1440               -2   R1654                1
    X1516     COST               -24   R1438               -4
    X1516     R1480                1   R1516               -9
    X1516     R1522               -2   R1777               -2
    X1517     COST                47   R1519                9
    X1517     R1547               -1   R1596                8
    X1517     R1427                6   R1687                1
    X1518     COST               -17   R1443                5
    X1518     R1442                8   R1455                4
    X1518     R1575               -4   R1779               -6
    X1519     COST               -35   R1493               -4
    X1519     R1439               -1   R1541               -2
    X1519     R1509               -8   R1687               -8
    X1520     COST                91   R1445                9
    X1520     R1462                3   R1582               -3
    X1520     R1412                7   R1754                5
    X1521     COST                30   R1537                5
    X1521     R1435                5   R1494                3
    X1521     R1408               -1   R1796               -8
    X1522     COST                 4   R1458               -9
    X1522     R1543               -2   R1427                4
    X1522     R1564               -6   R1766                3
    X1523     COST                16   R1480                3
    X1523     R1541               -2   R1482                5
    X1523     R1537                2   R1739               -8
    X1524     COST               -74   R1510                8
    X1524     R1446                3   R1511               -9
    X1524     R1425                4   R1731               -2
    X1525     COST                58   R1598               -2
    X1525     R1451                2   R1579                5
    X1525     R1544               -4   R1779                8
    X1526     COST                22   R1565                5
    X1526     R1461               -1   R1444                4
    X1526     R1557                3   R1655                3
    X1527     COST                44   R1422                7
    X1527     R1424               -1   R1412                1
    X1527     R1461               -8   R1786                9
    X1528     COST                35   R1452                7
    X1528     R1475                8   R1470               -9
    X1528     R1522                7   R1759               -5
    X1529     COST                76   R1487                8
    X1529     R1516                9   R1408                7
    X1529     R1507               -5   R1725                3
    X1530     COST                 8   R1574                2
    X1530     R1416                5   R1512                7
    X1530     R1518                4   R1635                2
    X1531     COST               -28   R1402               -2
    X1531     R1588               -1   R1474               -1
    X1531     R1406               -2   R1739               -3
    X1532     COST                18   R1568                2
    X1532     R1514               -2   R1592               -2
    X1532     R1527                6   R1654                5
    X1533     COST               -39   R1568                9
    X1533     R1498                9   R1598               -7
    X1533     R1514               -8   R1604               -5
    X1534     COST               -12   R1421               -2
    X1534     R1521                9   R1472                9
    X1534     R1485                3   R1769               -9
    X1535     COST                48   R1531                9
    X1535     R1528               -4   R1470               -2
    X1535     R1586               -7   R1671               -3
    X1536     COST               -30   R1461               -6
    X1536     R1447               -2   R1526               -4
    X1536     R1405               -3   R1604                6
    X1537     COST               -18   R1403               -6
    X1537     R1454               -6   R1596                4
    X1537     R1582                6   R1733                2
    X1538     COST                92   R1474               -4
    X1538     R1494               -4   R1511                9
    X1538     R1496                8   R1630               -8
    X1539     COST                53   R1459                6
    X1539     R1498                6   R1513               -8
    X1539     R1485               -1   R1678                8
    X1540     R1406               -1   R1425                4
    X1540     R1484               -6   R1555                6
    X1540     R1706               -1
    X1541     COST                18   R1476                9
    X1541     R1534               -7   R1480               -3
    X1541     R1483                7   R1690               -2
    X1542     COST               -75   R1525                7
    X1542     R1585               -5   R1447               -5
    X1542     R1450                6   R1652                7
    X1543     R1581                6   R1445               -5
    X1543     R1534                8   R1431               -2
    X1543     R1644                9
    X1544     COST               -42   R1514               -7
    X1544     R1425                2   R1493                8
    X1544     R1409               -7   R1630               -7
    X1545     COST                51   R1401                1
    X1545     R1555               -9   R1451                4
    X1545     R1414                9   R1711               -7
    X1546     COST                12   R1595                1
    X1546     R1420                4   R1453                2
    X1546     R1518               -7   R1688                1
    X1547     COST                64   R1511                2
    X1547     R1524               -5   R1459                6
    X1547     R1482                8   R1604                7
    X1548     COST               -43   R1479                2
    X1548     R1532               -2   R1586                1
    X1548     R1422               -7   R1762               -1
    X1549     COST               -87   R1579               -3
    X1549     R1569               -9   R1551               -3
    X1549     R1457               -3   R1620                1
    X1550     COST                71   R1566               -2
    X1550     R1477                7   R1553                8
    X1550     R1401                3   R1666                3
    X1551     COST                30   R1573                1
    X1551     R1596                2   R1527               -6
    X1551     R1549               -2   R1750                8
    X1552     COST                30   R1563               -1
    X1552     R1593               -8   R1524               -8
    X1552     R1528                5   R1683               -6
    X1553     COST                39   R1571                1
    X1553     R1414               -5   R1473                5
    X1553     R1474                5   R1795                4
    X1554     COST               -55   R1549                5
    X1554     R1553               -9   R1587               -8
    X1554     R1514                2   R1607                3
    X1555     COST                25   R1565               -9
    X1555     R1502                9   R1412               -4
    X1555     R1553                8   R1682                3
    X1556     R1557               -4   R1562                1
    X1556     R1476                1   R1455               -8
    X1556     R1749               -1
    X1557     R1437               -7   R1541               -7
    X1557     R1579                2   R1558                1
    X1557     R1763                2
    X1558     COST               -44   R1459               -7
    X1558     R1419                4   R1504               -1
    X1558     R1513               -1   R1735                2
    X1559     COST               -54   R1459               -7
    X1559     R1555               -4   R1507                9
    X1559     R1498               -4   R1749               -3
    X1560     COST                 7   R1465                9
    X1560     R1463               -3   R1551               -9
    X1560     R1481               -7   R1772               -1
    X1561     COST               -61   R1438               -9
    X1561     R1446               -9   R1546               -5
    X1561     R1427               -4   R1670                3
    X1562     COST                 9   R1573               -1
    X1562     R1443                6   R1517               -5
    X1562     R1577               -2   R1758               -4
    X1563     COST               -94   R1599               -6
    X1563     R1456               -1   R1446               -4
    X1563     R1514               -8   R1601               -9
    X1564     COST               -25   R1443               -5
    X1564     R1507                8   R1596                3
    X1564     R1559               -7   R1603                5
    X1565     COST               -23   R1507                1
    X1565     R1414               -3   R1491               -4
    X1565     R1403                2   R1743               -1
    X1566     COST                -6   R1584                4
    X1566     R1540                1   R1568                6
    X1566     R1561               -6   R1765                7
    X1567     COST               -11   R1574               -2
    X1567     R1591               -9   R1511                1
    X1567     R1554                7   R1655                3
    X1568     COST               -10   R1522               -2
    X1568     R1596               -1   R1494                5
    X1568     R1598               -5   R1677               -1
    X1569     COST                54   R1466                7
    X1569     R1599                4   R1585                9
    X1569     R1520                2   R1736                4
    X1570     COST                89   R1404               -9
    X1570     R1447                9   R1481               -9
    X1570     R1586                6   R1675                5
    X1571     COST                17   R1426               -1
    X1571     R1408                7   R1515                4
    X1571     R1543               -6   R1619               -9
    X1572     COST              -114   R1443               -6
    X1572     R1474               -4   R1465                2
    X1572     R1526               -8   R1612               -8
    X1573     COST              -143   R1430                8
    X1573     R1557                5   R1553               -8
    X1573     R1588               -3   R1623               -9
    X1574     COST               -66   R1433                7
    X1574     R1491               -3   R1525               -7
    X1574     R1585               -2   R1704               -6
    X1575     COST               -99   R1427               -9
    X1575     R1431               -2   R1402               -2
    X1575     R1506               -4   R1775               -3
    X1576     COST                32   R1511                4
    X1576     R1481                2   R1494               -4
    X1576     R1566                1   R1713                6
    X1577     R1525                4   R1495                1
    X1577     R1557                5   R1579                8
    X1577     R1671               -3
    X1578     COST               -63   R1524                4
    X1578     R1490                8   R1586                1
    X1578     R1509               -7   R1744               -5
    X1579     COST               -75   R1402               -8
    X1579     R1414               -5   R1535                3
    X1579     R1428               -5   R1649               -8
    X1580     COST                 2   R1446               -4
    X1580     R1530                1   R1426                2
    X1580     R1484                3   R1769               -3
    X1581     COST               -51   R1416                1
    X1581     R1595                2   R1567               -3
    X1581     R1494                6   R1718               -4
    X1582     COST                48   R1495               -3
    X1582     R1422               -9   R1421                8
    X1582     R1471                4   R1616                8
    X1583     COST                -1   R1435               -5
    X1583     R1445                3   R1529               -6
    X1583     R1573                1   R1758                8
    X1584     COST                35   R1550               -2
    X1584     R1566                9   R1488                9
    X1584     R1424               -2   R1770                8
    X1585     COST                41   R1480               -6
    X1585     R1559                9   R1520                7
    X1585     R1584                8   R1750                5
    X1586     COST                 8   R1420                1
    X1586     R1493                1   R1477                2
    X1586     R1455               -5   R1663               -8
    X1587     COST               -14   R1438                6
    X1587     R1407               -9   R1485               -7
    X1587     R1514                1   R1750               -3
    X1588     COST               -15   R1507               -7
    X1588     R1478               -3   R1487                4
    X1588     R1578                1   R1743                8
    X1589     COST                -5   R1522                3
    X1589     R1411                1   R1497               -8
    X1589     R1403               -1   R1703                4
    X1590     COST                95   R1572                4
    X1590     R1538               -5   R1596               -4
    X1590     R1545                4   R1623                9
    X1591     COST               -56   R1479               -2
    X1591     R1410               -9   R1497               -7
    X1591     R1452                1   R1726                1
    X1592     COST                 5   R1485               -4
    X1592     R1495               -4   R1468                1
    X1592     R1540               -3   R1797               -6
    X1593     COST               -17   R1513               -3
    X1593     R1464                2   R1565               -8
    X1593     R1401               -2   R1765               -8
    X1594     COST               -99   R1573                2
    X1594     R1441               -8   R1561               -7
    X1594     R1545                9   R1611                5
    X1595     COST                41   R1587                8
    X1595     R1482               -8   R1585                2
    X1595     R1501                8   R1620               -7
    X1596     COST                72   R1590                9
    X1596     R1414                9   R1550               -7
    X1596     R1400               -8   R1639               -2
    X1597     R1544                9   R1404               -3
    X1597     R1492                5   R1498                5
    X1597     R1605               -7
    X1598     COST                 3   R1539                3
    X1598     R1574                8   R1542               -1
    X1598     R1486               -5   R1790                8
    X1599     COST               -37   R1592               -6
    X1599     R1558               -8   R1448               -7
    X1599     R1442               -7   R1689                3
    X1600     COST                 2   R1689               -4
    X1600     R1693               -5   R1750                2
    X1600     R1601                1   R1866                7
    X1601     COST                16   R1749               -3
    X1601     R1600               -5   R1615               -6
    X1601     R1739                3   R1934                1
    X1602     R1730                9   R1782               -8
    X1602     R1748                9   R1637               -3
    X1602     R1968               -8
    X1603     COST               -17   R1649               -8
    X1603     R1756                7   R1775               -2
    X1603     R1644               -7   R1891               -7
    X1604     COST                90   R1681                8
    X1604     R1638                2   R1651                9
    X1604     R1795                8   R1884                9
    X1605     R1797                7   R1767               -3
    X1605     R1657               -5   R1613               -1
    X1605     R1920                7
    X1606     COST                77   R1655               -6
    X1606     R1610               -2   R1736               -8
    X1606     R1646                9   R1844                1
    X1607     COST               -13   R1691               -2
    X1607     R1743               -8   R1606               -6
    X1607     R1625                7   R1893                2
    X1608     COST               -20   R1787                2
    X1608     R1733                4   R1714               -4
    X1608     R1614                2   R1841               -4
    X1609     COST                40   R1631                8
    X1609     R1747                8   R1749               -8
    X1609     R1741               -3   R1987                8
    X1610     COST                -2   R1796                1
    X1610     R1769               -9   R1645                7
    X1610     R1714               -6   R1814                6
    X1611     COST               -25   R1781                9
    X1611     R1682               -5   R1789                5
    X1611     R1749               -8   R1950                5
    X1612     COST                10   R1712               -5
    X1612     R1702                1   R1604               -8
    X1612     R1703               -3   R1857                1
    X1613     COST               -25   R1719               -8
    X1613     R1789                4   R1784               -2
    X1613     R1732               -8   R1933               -5
    X1614     COST               -88   R1631               -8
    X1614     R1601               -6   R1739               -2
    X1614     R1762               -9   R1808                9
    X1615     COST                30   R1640               -1
    X1615     R1648                9   R1793                3
    X1615     R1773                1   R1943               -9
    X1616     COST               -13   R1645                5
    X1616     R1733               -2   R1719               -2
    X1616     R1605               -9   R1898               -6
    X1617     COST                90   R1732                5
    X1617     R1762                2   R1673                4
    X1617     R1637               -5   R1811                7
    X1618     COST               -27   R1754               -9
    X1618     R1791                7   R1672               -6
    X1618     R1762               -4   R1946               -9
    X1619     COST                76   R1781                8
    X1619     R1788                7   R1654                4
    X1619     R1711               -3   R1981                8
    X1620     COST                44   R1615                9
    X1620     R1668               -6   R1642               -4
    X1620     R1629                9   R1973                8
    X1621     R1749                1   R1746               -5
    X1621     R1784               -8   R1672               -5
    X1621     R1947               -9
    X1622     COST                -7   R1728               -7
    X1622     R1674                9   R1666                1
    X1622     R1788               -2   R1902                4
    X1623     COST                32   R1712               -9
    X1623     R1754                4   R1688               -7
    X1623     R1700               -4   R1832                9
    X1624     COST                52   R1747                1
    X1624     R1648               -1   R1678               -9
    X1624     R1619                9   R1868                3
    X1625     COST                21   R1659               -1
    X1625     R1728               -2   R1662                2
    X1625     R1604               -4   R1938                3
    X1626     COST               -40   R1704               -9
    X1626     R1747                7   R1796                1
    X1626     R1601                1   R1963                6
    X1627     COST                88   R1631                8
    X1627     R1725               -6   R1720               -7
    X1627     R1778                6   R1878                6
    X1628     COST                70   R1673                9
    X1628     R1678                5   R1728               -2
    X1628     R1748                5   R1992               -1
    X1629     COST               -42   R1691                9
    X1629     R1743                7   R1645               -3
    X1629     R1747                2   R1994               -7
    X1630     COST               -98   R1685               -7
    X1630     R1677               -3   R1780               -7
    X1630     R1662               -6   R1873               -2
    X1631     COST                47   R1753                1
    X1631     R1790               -6   R1752                6
    X1631     R1755                7   R1868               -7
    X1632     COST                14   R1676               -4
    X1632     R1750                2   R1752                4
    X1632     R1652                7   R1982               -6
    X1633     COST                64   R1787                4
    X1633     R1675               -9   R1698                8
    X1633     R1694               -5   R1882                2
    X1634     COST               -20   R1725               -9
    X1634     R1799                6   R1790                4
    X1634     R1649               -1   R1886               -6
    X1635     COST                28   R1754               -9
    X1635     R1707                7   R1673                8
    X1635     R1641                5   R1986               -6
    X1636     COST                55   R1690                7
    X1636     R1777               -2   R1710                6
    X1636     R1655                7   R1959                1
    X1637     COST               -10   R1657                3
    X1637     R1684               -2   R1699                4
    X1637     R1611                5   R1863               -4
    X1638     R1712               -6   R1647                7
    X1638     R1695                2   R1757               -2
    X1638     R1911                5
    X1639     COST               -20   R1798               -1
    X1639     R1623               -4   R1604               -3
    X1639     R1794               -6   R1864                8
    X1640     COST               -81   R1681                1
    X1640     R1708               -2   R1736               -7
    X1640     R1623               -7   R1982               -3
    X1641     COST                15   R1688                2
    X1641     R1785               -8   R1607                7
    X1641     R1772                3   R1983               -2
    X1642     COST                63   R1716                7
    X1642     R1666                2   R1680               -9
    X1642     R1750                9   R1956               -1
    X1643     COST               -68   R1714               -5
    X1643     R1616               -8   R1767               -3
    X1643     R1693                5   R1945                5
    X1644     COST                19   R1712               -1
    X1644     R1613                1   R1779                2
    X1644     R1653               -9   R1839                3
    X1645     COST                32   R1602                6
    X1645     R1795               -1   R1613                3
    X1645     R1666               -5   R1895               -7
    X1646     COST                49   R1671                9
    X1646     R1773                7   R1708                8
    X1646     R1753               -5   R1882               -3
    X1647     COST                34   R1616                2
    X1647     R1796                8   R1789               -2
    X1647     R1699                7   R1920               -6
    X1648     COST                -9   R1743               -2
    X1648     R1734               -4   R1671               -5
    X1648     R1655                1   R1877               -2
    X1649     COST                29   R1657               -1
    X1649     R1732               -3   R1631               -7
    X1649     R1797                6   R1984                8
    X1650     COST                53   R1624                9
    X1650     R1777               -7   R1778               -3
    X1650     R1667                8   R1923               -3
    X1651     COST                 3   R1733               -8
    X1651     R1658               -8   R1688               -8
    X1651     R1660               -1   R1814                9
    X1652     COST                 9   R1656               -4
    X1652     R1609                2   R1617               -6
    X1652     R1679                2   R1949               -7
    X1653     R1723               -3   R1790               -8
    X1653     R1620               -9   R1687                2
    X1653     R1838               -9
    X1654     COST                33   R1731                1
    X1654     R1799               -7   R1623                9
    X1654     R1788               -6   R1979               -8
    X1655     COST                40   R1788                5
    X1655     R1662               -9   R1755               -9
    X1655     R1669               -8   R1887                5
    X1656     COST                51   R1796               -2
    X1656     R1703               -8   R1677               -9
    X1656     R1612                7   R1839                7
    X1657     COST               -21   R1606               -5
    X1657     R1667               -1   R1757                1
    X1657     R1656               -2   R1985                5
    X1658     COST               -12   R1718               -3
    X1658     R1784               -7   R1736               -5
    X1658     R1749                7   R1827                6
    X1659     R1686                4   R1753               -7
    X1659     R1751                7   R1641                3
    X1659     R1857                5
    X1660     COST               -26   R1631               -1
    X1660     R1680               -4   R1601               -3
    X1660     R1669                2   R1976               -9
    X1661     COST                60   R1732                7
    X1661     R1653               -8   R1725                9
    X1661     R1788                5   R1883                5
    X1662     COST                62   R1636                6
    X1662     R1714                5   R1622                5
    X1662     R1696               -8   R1864                7
    X1663     COST               -32   R1719               -7
    X1663     R1723                9   R1662                3
    X1663     R1716               -1   R1888               -4
    X1664     COST               -33   R1644                5
    X1664     R1783                4   R1793               -6
    X1664     R1730                9   R1973               -8
    X1665     COST                63   R1616               -3
    X1665     R1692                9   R1659                7
    X1665     R1647               -5   R1915                8
    X1666     COST                29   R1638                6
    X1666     R1621                5   R1704                7
    X1666     R1706                1   R1802               -8
    X1667     COST               -75   R1655                1
    X1667     R1778               -8   R1622               -5
    X1667     R1662               -7   R1902                1
    X1668     COST               -45   R1789               -8
    X1668     R1610                4   R1749               -4
    X1668     R1792               -7   R1878               -9
    X1669     COST                54   R1787                7
    X1669     R1685                8   R1667               -4
    X1669     R1618                6   R1859               -8
    X1670     COST               -60   R1729               -8
    X1670     R1722               -9   R1647               -8
    X1670     R1698                4   R1929                1
    X1671     COST               -48   R1675               -2
    X1671     R1688               -5   R1733                8
    X1671     R1744               -9   R1999                5
    X1672     R1660               -1   R1666               -6
    X1672     R1638                1   R1746                2
    X1672     R1910                2
    X1673     COST               -48   R1665               -4
    X1673     R1738                3   R1722               -9
    X1673     R1706                6   R1824                8
    X1674     COST                 4   R1735                2
    X1674     R1637                7   R1669               -5
    X1674     R1614                9   R1841               -7
    X1675     COST               -72   R1730                3
    X1675     R1684               -8   R1695                6
    X1675     R1783               -7   R1950               -9
    X1676     COST               -38   R1664               -2
    X1676     R1754               -4   R1771                5
    X1676     R1729                1   R1998                4
    X1677     COST                56   R1655                4
    X1677     R1685                5   R1766                7
    X1677     R1633                8   R1850               -7
    X1678     COST               -46   R1700               -7
    X1678     R1609                5   R1751               -6
    X1678     R1729               -2   R1934               -8
    X1679     COST               217   R1690                7
    X1679     R1787                6   R1685                9
    X1679     R1617               -4   R1893                6
    X1680     COST               -29   R1763               -1
    X1680     R1683                1   R1651               -5
    X1680     R1720                9   R1948               -9
    X1681     COST                -6   R1605               -6
    X1681     R1629                3   R1671                9
    X1681     R1709                7   R1906               -7
    X1682     COST               -11   R1631               -1
    X1682     R1721               -9   R1641                8
    X1682     R1704                6   R1863                4
    X1683     COST                45   R1775                9
    X1683     R1669               -4   R1641               -2
    X1683     R1732                2   R1968               -1
    X1684     COST               -72   R1611                3
    X1684     R1678               -5   R1652               -9
    X1684     R1740               -8   R1996               -8
    X1685     COST                -7   R1690               -6
    X1685     R1771               -6   R1627               -3
    X1685     R1787                4   R1856                5
    X1686     COST                85   R1750                6
    X1686     R1738                5   R1709               -8
    X1686     R1753               -2   R1924               -2
    X1687     COST                 9   R1746               -5
    X1687     R1642               -4   R1795                9
    X1687     R1741               -3   R1966                4
    X1688     COST               -22   R1771                4
    X1688     R1757               -3   R1661                3
    X1688     R1696                2   R1995               -5
    X1689     COST                15   R1633               -2
    X1689     R1604               -4   R1631                5
    X1689     R1606                1   R1979                9
    X1690     COST               -60   R1654                3
    X1690     R1797               -5   R1723               -1
    X1690     R1744               -2   R1934               -7
    X1691     COST               -56   R1633               -6
    X1691     R1785               -4   R1751                8
    X1691     R1715               -4   R1833               -3
    X1692     COST                24   R1618                8
    X1692     R1742                6   R1762               -3
    X1692     R1753               -8   R1946               -4
    X1693     COST               -49   R1704               -9
    X1693     R1647                1   R1715                9
    X1693     R1626                7   R1970                5
    X1694     COST                38   R1770               -8
    X1694     R1702                4   R1652               -3
    X1694     R1720                4   R1949                2
    X1695     COST               -63   R1715               -9
    X1695     R1609               -6   R1664               -6
    X1695     R1694                1   R1996               -7
    X1696     COST               -37   R1642                4
    X1696     R1646               -2   R1761                7
    X1696     R1651               -9   R1806                2
    X1697     COST               -87   R1624                1
    X1697     R1696               -7   R1677                8
    X1697     R1685               -7   R1836                5
    X1698     COST               -65   R1714               -5
    X1698     R1633               -3   R1716                2
    X1698     R1715               -1   R1955               -5
    X1699     COST                36   R1766                9
    X1699     R1644               -4   R1659                3
    X1699     R1767               -1   R1969                1
    X1700     COST               -16   R1671               -9
    X1700     R1665                4   R1748               -4
    X1700     R1654               -4   R1916               -4
    X1701     COST               -36   R1606                2
    X1701     R1652               -3   R1673               -4
    X1701     R1642                3   R1969               -2
    X1702     COST                 6   R1770                7
    X1702     R1694               -6   R1642               -2
    X1702     R1653                1   R1958                1
    X1703     COST                13   R1601               -2
    X1703     R1785                3   R1764                2
    X1703     R1655               -3   R1835                3
    X1704     COST               132   R1630               -3
    X1704     R1799                5   R1704                4
    X1704     R1780                6   R1951                5
    X1705     COST                 4   R1735                8
    X1705     R1758               -3   R1643                1
    X1705     R1681               -9   R1993                5
    X1706     COST                -4   R1736               -4
    X1706     R1693               -9   R1652                8
    X1706     R1780                6   R1923               -2
    X1707     R1603               -8   R1784               -8
    X1707     R1751               -2   R1680                8
    X1707     R1912                7
    X1708     COST               -63   R1611                6
    X1708     R1642                3   R1773               -6
    X1708     R1626               -7   R1998                5
    X1709     COST                -3   R1719               -9
    X1709     R1700               -7   R1648               -5
    X1709     R1716                8   R1939                9
    X1710     COST                56   R1685               -3
    X1710     R1797               -6   R1654                7
    X1710     R1783                2   R1842                7
    X1711     COST               -28   R1659               -9
    X1711     R1669                1   R1667                1
    X1711     R1660               -2   R1964               -3
    X1712     COST                -4   R1740                9
    X1712     R1690               -6   R1626                7
    X1712     R1646               -3   R1976                6
    X1713     COST                 6   R1761                4
    X1713     R1783                5   R1655                4
    X1713     R1716               -8   R1944               -6
    X1714     COST               -21   R1700               -8
    X1714     R1617                1   R1736               -7
    X1714     R1626               -7   R1964                2
    X1715     COST                 9   R1676               -9
    X1715     R1602                3   R1730               -5
    X1715     R1696               -1   R1890               -5
    X1716     COST                28   R1782                6
    X1716     R1765               -2   R1631                8
    X1716     R1785               -6   R1915               -2
    X1717     R1694               -2   R1657               -8
    X1717     R1634               -9   R1726               -8
    X1717     R1809               -1
    X1718     COST                44   R1651                5
    X1718     R1603               -6   R1774               -1
    X1718     R1686                2   R1893                3
    X1719     COST               -41   R1617                5
    X1719     R1622               -7   R1715                7
    X1719     R1666                7   R1899                1
    X1720     COST                25   R1661                3
    X1720     R1668                9   R1665               -9
    X1720     R1792                7   R1881               -5
    X1721     COST                51   R1696                1
    X1721     R1676                4   R1687                5
    X1721     R1795               -3   R1870                5
    X1722     COST                22   R1707                3
    X1722     R1750               -2   R1714               -1
    X1722     R1662               -9   R1917                5
    X1723     COST              -106   R1791               -9
    X1723     R1702               -8   R1765               -7
    X1723     R1628                5   R1850                3
    X1724     COST                 9   R1615               -1
    X1724     R1660               -2   R1669                9
    X1724     R1656               -7   R1809               -7
    X1725     COST              -182   R1661               -9
    X1725     R1639               -9   R1772               -6
    X1725     R1705               -6   R1835                1
    X1726     COST               -60   R1678               -3
    X1726     R1645               -5   R1723                3
    X1726     R1666                4   R1994               -4
    X1727     COST                20   R1798                3
    X1727     R1621                6   R1723                7
    X1727     R1640               -2   R1883                4
    X1728     COST                76   R1703               -3
    X1728     R1633                2   R1668               -6
    X1728     R1623                6   R1897               -6
    X1729     COST               -24   R1718               -4
    X1729     R1770               -4   R1608               -4
    X1729     R1693                4   R1881               -9
    X1730     COST                57   R1648                1
    X1730     R1613               -3   R1679                1
    X1730     R1746                1   R1848                6
    X1731     COST               -37   R1768               -9
    X1731     R1688               -6   R1741                6
    X1731     R1639               -4   R1884               -1
    X1732     COST                14   R1656                2
    X1732     R1665                6   R1680                9
    X1732     R1722                1   R1824                5
    X1733     COST                69   R1778                2
    X1733     R1664               -7   R1669                6
    X1733     R1696                4   R1842                6
    X1734     COST                30   R1773               -6
    X1734     R1799                1   R1685                8
    X1734     R1642                5   R1918               -9
    X1735     COST               -20   R1635                9
    X1735     R1780               -8   R1613               -4
    X1735     R1672               -3   R1805                4
    X1736     COST               -31   R1728                4
    X1736     R1752               -3   R1642               -7
    X1736     R1664               -3   R1826               -4
    X1737     COST               -19   R1671               -2
    X1737     R1713                8   R1750               -4
    X1737     R1623                1   R1950                8
    X1738     COST               -18   R1734               -7
    X1738     R1770                6   R1781                8
    X1738     R1618                3   R1853               -5
    X1739     COST               -21   R1785                2
    X1739     R1799                2   R1783                1
    X1739     R1778               -7   R1874                7
    X1740     COST                22   R1621                9
    X1740     R1778                5   R1604               -2
    X1740     R1776               -4   R1841               -2
    X1741     COST               -30   R1743                5
    X1741     R1606               -6   R1798               -1
    X1741     R1640               -3   R1851               -7
    X1742     COST                37   R1734                3
    X1742     R1600                8   R1740                5
    X1742     R1757                1   R1879               -6
    X1743     COST               -48   R1751               -8
    X1743     R1619               -8   R1749               -7
    X1743     R1674                6   R1900                6
    X1744     COST                89   R1685                6
    X1744     R1752                1   R1747               -3
    X1744     R1735               -6   R1963                6
    X1745     COST               -72   R1707               -1
    X1745     R1662                1   R1663                9
    X1745     R1772               -2   R1854               -7
    X1746     COST                34   R1625               -2
    X1746     R1739                2   R1627                4
    X1746     R1605                8   R1919                6
    X1747     COST                97   R1712                2
    X1747     R1616                9   R1656                3
    X1747     R1661                6   R1909                5
    X1748     COST                 7   R1766               -2
    X1748     R1737                9   R1686               -1
    X1748     R1628               -9   R1813               -7
    X1749     R1716                8   R1620               -2
    X1749     R1657                5   R1789               -7
    X1749     R1937                3
    X1750     COST                49   R1608                3
    X1750     R1637                1   R1616               -2
    X1750     R1648                8   R1946               -4
    X1751     COST                -2   R1732                3
    X1751     R1634                6   R1641                4
    X1751     R1647               -2   R1855                1
    X1752     COST               -64   R1705                6
    X1752     R1621                7   R1722               -8
    X1752     R1717                9   R1877               -5
    X1753     COST                -3   R1751                8
    X1753     R1785                1   R1602               -1
    X1753     R1615                9   R1896               -4
    X1754     COST               -18   R1767                3
    X1754     R1631               -1   R1672                7
    X1754     R1710                9   R1941               -7
    X1755     COST                22   R1760               -1
    X1755     R1751               -7   R1706                3
    X1755     R1635                2   R1843                3
    X1756     COST                85   R1698                7
    X1756     R1670                7   R1737               -5
    X1756     R1777                5   R1891                1
    X1757     COST                56   R1639                4
    X1757     R1784               -2   R1625                8
    X1757     R1634               -9   R1974                5
    X1758     COST                53   R1726                8
    X1758     R1663                8   R1604               -9
    X1758     R1770                7   R1888                6
    X1759     COST                73   R1767               -9
    X1759     R1786                1   R1639                8
    X1759     R1713               -3   R1881                8
    X1760     COST                33   R1608               -6
    X1760     R1643               -3   R1668                2
    X1760     R1646                6   R1926               -4
    X1761     COST               -35   R1646               -5
    X1761     R1792               -9   R1621                1
    X1761     R1615               -8   R1882               -7
    X1762     COST               -15   R1767               -6
    X1762     R1634               -3   R1617               -2
    X1762     R1735                1   R1823               -3
    X1763     COST               -55   R1767               -4
    X1763     R1768               -8   R1756               -8
    X1763     R1743               -5   R1865               -1
    X1764     COST                -1   R1796               -8
    X1764     R1618                7   R1755                8
    X1764     R1656               -6   R1944               -6
    X1765     COST               100   R1797               -7
    X1765     R1750                4   R1782                4
    X1765     R1671               -9   R1886                9
    X1766     COST                 5   R1767               -6
    X1766     R1654                9   R1721               -2
    X1766     R1769                4   R1834                2
    X1767     COST               138   R1689                5
    X1767     R1674                8   R1744                9
    X1767     R1734                9   R1811                6
    X1768     COST               -81   R1640                3
    X1768     R1686                2   R1701               -2
    X1768     R1714               -9   R1889               -6
    X1769     COST               -26   R1668               -6
    X1769     R1788               -2   R1777               -4
    X1769     R1742               -1   R1883               -4
    X1770     COST                34   R1657               -5
    X1770     R1647               -8   R1760                2
    X1770     R1740                1   R1883                7
    X1771     COST                14   R1647                4
    X1771     R1743               -7   R1669                2
    X1771     R1610               -1   R1883                1
    X1772     COST               -68   R1608                6
    X1772     R1766               -7   R1641               -9
    X1772     R1702               -8   R1999                1
    X1773     COST               -56   R1654                2
    X1773     R1629               -4   R1698               -1
    X1773     R1705                5   R1883               -9
    X1774     COST                23   R1680               -1
    X1774     R1779                3   R1747                4
    X1774     R1770               -5   R1860               -2
    X1775     COST               -10   R1777                7
    X1775     R1647               -8   R1728                4
    X1775     R1749               -9   R1902               -4
    X1776     COST               -51   R1754               -9
    X1776     R1740                4   R1609               -5
    X1776     R1704                1   R1847                5
    X1777     COST              -107   R1647               -4
    X1777     R1721               -6   R1645               -5
    X1777     R1615               -3   R1865               -4
    X1778     COST                58   R1692               -3
    X1778     R1763               -9   R1689               -3
    X1778     R1757                1   R1870                8
    X1779     COST               -22   R1637               -4
    X1779     R1651               -9   R1757                1
    X1779     R1749               -4   R1915               -7
    X1780     COST               -62   R1655                1
    X1780     R1664                2   R1785               -8
    X1780     R1602               -8   R1883               -2
    X1781     COST               -51   R1775               -9
    X1781     R1783                5   R1761               -9
    X1781     R1627               -4   R1826               -5
    X1782     COST               -33   R1659                1
    X1782     R1644                5   R1626               -3
    X1782     R1646               -4   R1809               -7
    X1783     COST                10   R1689               -3
    X1783     R1600                3   R1684                1
    X1783     R1712                7   R1864               -1
    X1784     COST               -42   R1780               -7
    X1784     R1747               -7   R1745                6
    X1784     R1709                7   R1866                1
    X1785     COST                61   R1642                4
    X1785     R1612                3   R1693                7
    X1785     R1751               -4   R1858               -4
    X1786     COST               -69   R1615                2
    X1786     R1614               -9   R1780               -2
    X1786     R1737               -9   R1952               -6
    X1787     COST                 2   R1626               -3
    X1787     R1667               -4   R1741               -5
    X1787     R1783                3   R1884                6
    X1788     COST                64   R1621               -9
    X1788     R1726               -1   R1767                2
    X1788     R1744                8   R1821                4
    X1789     COST               128   R1721                5
    X1789     R1618               -3   R1737                8
    X1789     R1692                2   R1846                9
    X1790     COST                17   R1637                7
    X1790     R1704               -5   R1713                1
    X1790     R1762               -4   R1980                7
    X1791     COST                75   R1781               -7
    X1791     R1754                6   R1797               -7
    X1791     R1702                3   R1840               -8
    X1792     COST                 6   R1669                5
    X1792     R1799               -4   R1675                2
    X1792     R1721                5   R1815               -3
    X1793     COST               108   R1655                1
    X1793     R1702                6   R1764                1
    X1793     R1648                9   R1834                3
    X1794     COST               -31   R1603               -6
    X1794     R1739               -6   R1781                8
    X1794     R1627               -4   R1995                1
    X1795     COST               -26   R1747                8
    X1795     R1645               -5   R1717                2
    X1795     R1676                3   R1908                3
    X1796     COST               -16   R1783               -4
    X1796     R1798                7   R1734               -4
    X1796     R1786                9   R1915                5
    X1797     COST               -37   R1625               -8
    X1797     R1735               -6   R1760               -8
    X1797     R1707               -3   R1916               -2
    X1798     COST               -54   R1696               -7
    X1798     R1673               -6   R1678                1
    X1798     R1643                9   R1916                9
    X1799     COST                 2   R1630                4
    X1799     R1769                8   R1706                3
    X1799     R1642                7   R1926               -6
    X1800     COST               155   R1862                7
    X1800     R1957                9   R1829                2
    X1800     R1871               -8   R2048                6
    X1801     COST              -111   R1906               -3
    X1801     R1954               -6   R1801               -6
    X1801     R1916               -2   R2159                6
    X1802     COST                57   R1949                5
    X1802     R1836                2   R1934                7
    X1802     R1837                4   R2089                1
    X1803     COST                16   R1975                2
    X1803     R1826               -9   R1931               -7
    X1803     R1886                4   R2012                6
    X1804     COST                 6   R1841               -6
    X1804     R1893                6   R1931               -7
    X1804     R1910               -1   R2020                5
    X1805     COST               -23   R1963               -8
    X1805     R1902                1   R1808                4
    X1805     R1930                3   R2118                3
    X1806     COST                36   R1816                9
    X1806     R1950                4   R1871               -9
    X1806     R1912                8   R2014                9
    X1807     COST                 4   R1950                3
    X1807     R1849                2   R1892                3
    X1807     R1841                3   R2091               -5
    X1808     R1920                4   R1895                9
    X1808     R1975                6   R1986                1
    X1808     R2182               -1
    X1809     COST               -16   R1967               -5
    X1809     R1837                4   R1943                8
    X1809     R1805               -6   R2149                1
    X1810     COST               -18   R1949                9
    X1810     R1928               -2   R1932                3
    X1810     R1822               -8   R2115               -9
    X1811     COST                -1   R1852                5
    X1811     R1808                6   R1931               -4
    X1811     R1981                2   R2198                1
    X1812     COST               -39   R1905               -7
    X1812     R1903               -1   R1824                6
    X1812     R1936               -8   R2141               -5
    X1813     COST               -96   R1816               -3
    X1813     R1920               -8   R1970               -4
    X1813     R1858               -7   R2087               -9
    X1814     COST              -115   R1870               -6
    X1814     R1987                9   R1890               -6
    X1814     R1844               -8   R2009               -5
    X1815     COST                 9   R1933                6
    X1815     R1964                8   R1913                1
    X1815     R1911               -5   R2124               -3
    X1816     COST                44   R1963               -7
    X1816     R1912               -4   R1862                8
    X1816     R1945                8   R2151               -9
    X1817     COST              -101   R1843                1
    X1817     R1925               -7   R1989                1
    X1817     R1884               -9   R2052               -2
    X1818     COST               -13   R1970               -9
    X1818     R1820               -4   R1910                6
    X1818     R1806                5   R2174               -3
    X1819     COST                29   R1959               -1
    X1819     R1968               -7   R1865                5
    X1819     R1918                7   R2017                2
    X1820     COST               131   R1811                9
    X1820     R1943               -1   R1882                5
    X1820     R1930                9   R2087                7
    X1821     COST               -26   R1973                1
    X1821     R1993               -5   R1872               -9
    X1821     R1985               -1   R2082               -8
    X1822     COST                 2   R1939               -2
    X1822     R1952                8   R1801               -4
    X1822     R1866                1   R2141                3
    X1823     COST               -13   R1910                1
    X1823     R1894                7   R1941               -5
    X1823     R1920                4   R2017               -8
    X1824     COST                22   R1833               -5
    X1824     R1801               -1   R1898                5
    X1824     R1955                9   R2122                2
    X1825     COST                56   R1886                4
    X1825     R1826                2   R1856               -4
    X1825     R1936                6   R2002                6
    X1826     COST                53   R1805                8
    X1826     R1823               -1   R1976                6
    X1826     R1926               -2   R2013                8
    X1827     COST               -48   R1915               -7
    X1827     R1850               -6   R1810               -2
    X1827     R1885               -4   R2122                1
    X1828     COST               -18   R1875                6
    X1828     R1911                2   R1948               -3
    X1828     R1952               -3   R2112                1
    X1829     COST               114   R1927               -8
    X1829     R1995                6   R1840               -7
    X1829     R1862                8   R2077                2
    X1830     COST                47   R1974               -8
    X1830     R1965                9   R1906                9
    X1830     R1917                4   R2060               -8
    X1831     COST               -64   R1992                9
    X1831     R1811               -5   R1874               -4
    X1831     R1806               -8   R2049                7
    X1832     COST               125   R1978                8
    X1832     R1835                2   R1965                8
    X1832     R1832               -3   R2031               -1
    X1833     COST                30   R1810               -9
    X1833     R1904                8   R1930               -2
    X1833     R1829               -4   R2193               -1
    X1834     COST               -10   R1882                2
    X1834     R1946               -7   R1871               -1
    X1834     R1907               -6   R2166               -7
    X1835     COST               -34   R1991               -8
    X1835     R1994               -9   R1847               -8
    X1835     R1968               -4   R2147                5
    X1836     COST                47   R1850                8
    X1836     R1841                1   R1830               -7
    X1836     R1890                5   R2064                2
    X1837     COST                74   R1914                3
    X1837     R1850                9   R1937               -9
    X1837     R1894               -7   R2070                4
    X1838     COST                79   R1981               -3
    X1838     R1990               -8   R1880                7
    X1838     R1951                7   R2063                8
    X1839     COST              -102   R1887                1
    X1839     R1955               -5   R1954               -6
    X1839     R1809               -6   R2177               -7
    X1840     COST               -21   R1975               -4
    X1840     R1922                2   R1824               -1
    X1840     R1839               -1   R2057               -4
    X1841     COST              -127   R1989               -6
    X1841     R1888               -5   R1845               -5
    X1841     R1829               -8   R2027                5
    X1842     COST                56   R1968                7
    X1842     R1907                8   R1895               -2
    X1842     R1978                7   R2069               -7
    X1843     COST               -18   R1977                6
    X1843     R1810                1   R1850               -7
    X1843     R1823                7   R2000                3
    X1844     COST                58   R1921                5
    X1844     R1919               -2   R1936                8
    X1844     R1993               -3   R2027               -9
    X1845     COST               -36   R1941               -6
    X1845     R1803               -4   R1807               -8
    X1845     R1999               -6   R2163                5
    X1846     COST                17   R1893                1
    X1846     R1909                4   R1913                8
    X1846     R1911               -2   R2000                9
    X1847     COST               -44   R1806                8
    X1847     R1989               -6   R1891               -4
    X1847     R1950               -6   R2167               -3
    X1848     COST               -37   R1958               -3
    X1848     R1995               -6   R1921               -8
    X1848     R1895                1   R2192                7
    X1849     COST              -136   R1962               -8
    X1849     R1916               -5   R1912                2
    X1849     R1877               -9   R2162               -7
    X1850     COST                72   R1869                2
    X1850     R1972                7   R1999                5
    X1850     R1804                6   R2078                8
    X1851     COST                77   R1930               -3
    X1851     R1905                2   R1971                1
    X1851     R1843                9   R2095               -4
    X1852     COST               -75   R1984               -6
    X1852     R1885               -6   R1845               -8
    X1852     R1925               -3   R2048                9
    X1853     COST                37   R1891                1
    X1853     R1932                8   R1943                5
    X1853     R1975               -2   R2119                4
    X1854     COST               -20   R1883               -5
    X1854     R1983               -2   R1880               -6
    X1854     R1821                5   R2067                4
    X1855     COST                 4   R1990               -4
    X1855     R1874                5   R1809               -9
    X1855     R1894               -4   R2069                8
    X1856     COST               -17   R1826                1
    X1856     R1944                7   R1856               -1
    X1856     R1875                4   R2024               -2
    X1857     COST               -30   R1854               -8
    X1857     R1899                2   R1958                8
    X1857     R1982                4   R2176                4
    X1858     COST               -39   R1972               -3
    X1858     R1875                8   R1894                7
    X1858     R1933               -6   R2159               -5
    X1859     COST                50   R1820                6
    X1859     R1817                6   R1836                2
    X1859     R1871               -8   R2155                3
    X1860     COST               -86   R1921               -6
    X1860     R1954               -9   R1977               -4
    X1860     R1906                7   R2023               -7
    X1861     COST               -54   R1865               -9
    X1861     R1957                2   R1982               -2
    X1861     R1821               -2   R2149               -1
    X1862     COST                93   R1894               -9
    X1862     R1919               -2   R1806                7
    X1862     R1925                8   R2033               -4
    X1863     COST                 7   R1862               -3
    X1863     R1982                2   R1805               -2
    X1863     R1962                4   R2017                1
    X1864     COST                -4   R1877               -2
    X1864     R1809                6   R1827               -4
    X1864     R1937               -1   R2052               -6
    X1865     COST               -37   R1813                5
    X1865     R1918               -2   R1838               -6
    X1865     R1853               -3   R2147               -7
    X1866     COST               -19   R1921               -9
    X1866     R1818               -6   R1922               -1
    X1866     R1981                1   R2147               -3
    X1867     COST               -31   R1988               -9
    X1867     R1947               -5   R1812                4
    X1867     R1809                9   R2049               -5
    X1868     COST               -94   R1984               -3
    X1868     R1851                3   R1934               -4
    X1868     R1814                9   R2177               -6
    X1869     COST                69   R1892                9
    X1869     R1966                3   R1839               -3
    X1869     R1863                5   R2024                9
    X1870     COST               -49   R1948                6
    X1870     R1913                7   R1904               -8
    X1870     R1895                3   R2122               -3
    X1871     COST               -38   R1819                3
    X1871     R1801                6   R1954               -8
    X1871     R1943               -4   R2049                4
    X1872     COST                65   R1851               -3
    X1872     R1983               -1   R1823                5
    X1872     R1900               -8   R2068                5
    X1873     COST               -84   R1998               -5
    X1873     R1898               -7   R1991                5
    X1873     R1846               -4   R2174                3
    X1874     COST                17   R1804                8
    X1874     R1939               -3   R1903                6
    X1874     R1910                5   R2053               -4
    X1875     COST                 4   R1868                4
    X1875     R1890                9   R1803               -6
    X1875     R1935                5   R2042                2
    X1876     COST                41   R1879                7
    X1876     R1955                2   R1850                7
    X1876     R1823               -3   R2145                7
    X1877     COST               -32   R1981                1
    X1877     R1835               -9   R1848                2
    X1877     R1878                1   R2047                6
    X1878     COST                10   R1927                2
    X1878     R1982                2   R1924                6
    X1878     R1908               -8   R2178                7
    X1879     COST               -25   R1864               -7
    X1879     R1960                7   R1855                8
    X1879     R1949                1   R2159               -6
    X1880     COST               -52   R1929               -5
    X1880     R1865               -4   R1908               -9
    X1880     R1894               -1   R2114               -5
    X1881     COST                68   R1952                8
    X1881     R1857                5   R1974                4
    X1881     R1801                2   R2196                2
    X1882     COST                18   R1979               -3
    X1882     R1814               -9   R1879               -4
    X1882     R1999                3   R2138               -6
    X1883     COST              -137   R1994               -8
    X1883     R1847                4   R1856               -9
    X1883     R1891                2   R2191               -8
    X1884     COST                12   R1826                2
    X1884     R1918                3   R1911                8
    X1884     R1924                6   R2062                1
    X1885     COST                 3   R1900               -2
    X1885     R1881               -6   R1824                7
    X1885     R1896                7   R2163                4
    X1886     COST              -103   R1995               -5
    X1886     R1959               -7   R1949                5
    X1886     R1888               -1   R2181               -9
    X1887     COST               166   R1978                3
    X1887     R1831                8   R1844                5
    X1887     R1962                6   R2028               -8
    X1888     COST               -53   R1964                6
    X1888     R1845               -2   R1950                4
    X1888     R1802                7   R2063               -9
    X1889     COST                45   R1867               -3
    X1889     R1803                6   R1912                5
    X1889     R1907               -9   R2168                6
    X1890     COST               -15   R1910                1
    X1890     R1948               -4   R1915                3
    X1890     R1962               -1   R2000               -2
    X1891     COST              -119   R1967                8
    X1891     R1954               -8   R1910                2
    X1891     R1993                4   R2191               -9
    X1892     COST                 8   R1853               -9
    X1892     R1968               -1   R1995               -7
    X1892     R1997                4   R2110                7
    X1893     COST                -5   R1934                9
    X1893     R1974               -8   R1857               -7
    X1893     R1831               -4   R2155               -7
    X1894     COST               -44   R1990               -4
    X1894     R1886               -1   R1850                1
    X1894     R1864               -9   R2099                1
    X1895     COST                59   R1948               -9
    X1895     R1852                8   R1837               -4
    X1895     R1980                7   R2115                8
    X1896     R1885                1   R1950               -8
    X1896     R1828               -7   R1910               -5
    X1896     R2130                4
    X1897     COST                56   R1970                3
    X1897     R1918               -8   R1978               -1
    X1897     R1994                5   R2037                8
    X1898     COST               -16   R1818                7
    X1898     R1808               -9   R1872               -1
    X1898     R1861               -2   R2002               -1
    X1899     COST               -86   R1830               -6
    X1899     R1991                9   R1811               -7
    X1899     R1879                4   R2178                5
    X1900     COST                85   R1897               -9
    X1900     R1832                3   R1934                7
    X1900     R1941               -2   R2133                6
    X1901     COST                -5   R1891               -1
    X1901     R1855                5   R1874                8
    X1901     R1853               -7   R2041                2
    X1902     COST               -33   R1831               -6
    X1902     R1803               -2   R1877               -3
    X1902     R1955               -1   R2010                2
    X1903     COST                -8   R1863               -6
    X1903     R1893               -3   R1837                5
    X1903     R1833                4   R2171               -2
    X1904     COST               -71   R1800               -8
    X1904     R1915                8   R1919               -4
    X1904     R1968                8   R2046               -5
    X1905     COST              -112   R1949                8
    X1905     R1989               -8   R1927               -8
    X1905     R1850               -6   R2028                5
    X1906     COST                -9   R1891                7
    X1906     R1966               -3   R1800                2
    X1906     R1995               -7   R2109               -8
    X1907     COST                 9   R1958               -5
    X1907     R1986               -1   R1935               -4
    X1907     R1894                2   R2161               -4
    X1908     COST               -14   R1883               -4
    X1908     R1823                2   R1991                6
    X1908     R1930               -3   R2113                5
    X1909     COST               -76   R1818                7
    X1909     R1872               -6   R1855                6
    X1909     R1988               -6   R2071               -6
    X1910     COST                18   R1873                3
    X1910     R1970                8   R1868                4
    X1910     R1881               -1   R2115                3
    X1911     COST                 5   R1958               -7
    X1911     R1868               -3   R1949                8
    X1911     R1914                5   R2066                9
    X1912     COST               -54   R1895               -3
    X1912     R1965               -6   R1837                9
    X1912     R1892                8   R2105               -9
    X1913     COST                12   R1935               -6
    X1913     R1913                9   R1973                4
    X1913     R1977               -3   R2134               -2
    X1914     COST               -19   R1860               -7
    X1914     R1820               -7   R1805                3
    X1914     R1975                9   R2056                6
    X1915     COST                -2   R1891               -2
    X1915     R1906                9   R1912                6
    X1915     R1811               -1   R2181                2
    X1916     COST                61   R1838                6
    X1916     R1839                1   R1871               -3
    X1916     R1936                8   R2175                2
    X1917     COST                60   R1866                6
    X1917     R1853                5   R1911                5
    X1917     R1820                9   R2073               -2
    X1918     COST               -10   R1991               -8
    X1918     R1934               -2   R1900               -8
    X1918     R1912               -5   R2048               -2
    X1919     COST               -39   R1962               -8
    X1919     R1863                1   R1915               -3
    X1919     R1898                3   R2014                5
    X1920     COST               142   R1988                3
    X1920     R1927                2   R1803                1
    X1920     R1842                9   R2062                8
    X1921     COST                 8   R1843               -4
    X1921     R1861                4   R1896               -2
    X1921     R1930               -8   R2175                2
    X1922     COST               -30   R1943               -7
    X1922     R1946               -1   R1880                8
    X1922     R1935                3   R2135               -2
    X1923     R1883               -4   R1867               -1
    X1923     R1852               -3   R1938                3
    X1923     R2014                4
    X1924     COST               -42   R1950                3
    X1924     R1883               -7   R1985               -2
    X1924     R1945               -1   R2028               -8
    X1925     COST                18   R1818                9
    X1925     R1957               -6   R1992                6
    X1925     R1814               -7   R2120                9
    X1926     COST                84   R1849                1
    X1926     R1955               -9   R1843               -2
    X1926     R1812                9   R2150                5
    X1927     COST                -7   R1852               -5
    X1927     R1865               -1   R1977               -6
    X1927     R1885               -3   R2075                5
    X1928     COST                13   R1916                7
    X1928     R1875                2   R1828               -1
    X1928     R1900                6   R2093               -1
    X1929     COST               -20   R1953                5
    X1929     R1905               -4   R1981               -3
    X1929     R1944                4   R2074                7
    X1930     COST                47   R1887                6
    X1930     R1973               -1   R1937                7
    X1930     R1813                7   R2135               -3
    X1931     COST                61   R1957                8
    X1931     R1950               -7   R1948               -5
    X1931     R1816               -4   R2134                3
    X1932     COST               -15   R1945                3
    X1932     R1983                3   R1803                2
    X1932     R1876               -3   R2107               -3
    X1933     COST                 6   R1932               -1
    X1933     R1968               -7   R1936                1
    X1933     R1918               -8   R2158               -5
    X1934     COST                47   R1953               -2
    X1934     R1833                7   R1814               -4
    X1934     R1823                5   R2025                5
    X1935     COST               -49   R1924                5
    X1935     R1804               -3   R1886               -5
    X1935     R1911                8   R2145                9
    X1936     COST               -65   R1827               -3
    X1936     R1991                2   R1861               -8
    X1936     R1859               -5   R2119                9
    X1937     COST                14   R1988                2
    X1937     R1890               -9   R1857                8
    X1937     R1824                9   R2086               -2
    X1938     COST               -76   R1809                1
    X1938     R1968               -5   R1823               -6
    X1938     R1982               -9   R2090                5
    X1939     R1826                4   R1896                8
    X1939     R1968                7   R1998                4
    X1939     R2005                7
    X1940     COST                -9   R1901               -5
    X1940     R1946               -3   R1878               -5
    X1940     R1985               -7   R2166                8
    X1941     COST               115   R1876                8
    X1941     R1929               -5   R1830               -9
    X1941     R1931                9   R2108                9
    X1942     COST               130   R1807               -4
    X1942     R1981                2   R1854                9
    X1942     R1934                7   R2053                3
    X1943     COST               -31   R1994                2
    X1943     R1818                6   R1824               -7
    X1943     R1962               -6   R2000                5
    X1944     COST                38   R1919               -2
    X1944     R1949               -3   R1910               -9
    X1944     R1980                4   R2101               -3
    X1945     COST               -13   R1833                4
    X1945     R1852                6   R1838               -6
    X1945     R1860               -8   R2191               -3
    X1946     COST               136   R1821                5
    X1946     R1995                9   R1925                7
    X1946     R1853               -7   R2048                4
    X1947     COST               -67   R1859               -9
    X1947     R1943               -4   R1922               -9
    X1947     R1942                7   R2008               -5
    X1948     COST                -5   R1966                5
    X1948     R1815               -7   R1816               -4
    X1948     R1956               -8   R2132                6
    X1949     COST                58   R1996                6
    X1949     R1903               -3   R1841               -3
    X1949     R1879               -1   R2191                4
    X1950     COST               -18   R1977                2
    X1950     R1806               -6   R1992                4
    X1950     R1858               -5   R2055                2
    X1951     COST                41   R1989                5
    X1951     R1895                1   R1882               -8
    X1951     R1998                8   R2165                1
    X1952     COST                -3   R1831               -8
    X1952     R1819               -4   R1855               -4
    X1952     R1981                5   R2090                1
    X1953     COST                40   R1833               -7
    X1953     R1883                8   R1866               -4
    X1953     R1928               -6   R2019               -8
    X1954     COST                10   R1810               -4
    X1954     R1903                2   R1929               -9
    X1954     R1974               -4   R2024                7
    X1955     COST                21   R1997                3
    X1955     R1869                7   R1944               -3
    X1955     R1846                2   R2047               -4
    X1956     COST               -36   R1857                6
    X1956     R1863                2   R1878               -9
    X1956     R1835               -1   R2187                9
    X1957     COST              -103   R1827                5
    X1957     R1865               -7   R1995               -7
    X1957     R1911               -7   R2015               -2
    X1958     COST                32   R1987                2
    X1958     R1963                8   R1968                7
    X1958     R1937               -7   R2137               -3
    X1959     COST               127   R1826               -8
    X1959     R1952                8   R1949                2
    X1959     R1951                4   R2063                7
    X1960     COST                72   R1811                3
    X1960     R1925                9   R1867               -9
    X1960     R1914               -1   R2156               -6
    X1961     COST                -7   R1807               -3
    X1961     R1827               -7   R1814               -6
    X1961     R1927                7   R2116               -8
    X1962     COST                37   R1931               -2
    X1962     R1918                2   R1805                2
    X1962     R1873                6   R2108                3
    X1963     COST                21   R1903                9
    X1963     R1979               -9   R1818               -8
    X1963     R1835                3   R2122                2
    X1964     COST               -44   R1911               -9
    X1964     R1989               -9   R1905                5
    X1964     R1848                4   R2176                3
    X1965     COST               -41   R1988               -1
    X1965     R1801               -5   R1803                5
    X1965     R1838               -4   R2033               -8
    X1966     COST               -21   R1825               -7
    X1966     R1997                4   R1991                8
    X1966     R1806                3   R2083                3
    X1967     COST                -7   R1941               -3
    X1967     R1928                5   R1837                2
    X1967     R1889                9   R2157                6
    X1968     COST               -58   R1920                5
    X1968     R1894                5   R1966               -3
    X1968     R1823               -3   R2150               -8
    X1969     COST                 8   R1819                3
    X1969     R1931                1   R1928               -1
    X1969     R1863               -3   R2151               -1
    X1970     COST                -9   R1866                8
    X1970     R1941               -3   R1920                2
    X1970     R1983                4   R2137                1
    X1971     COST              -117   R1844               -2
    X1971     R1836                7   R1994               -9
    X1971     R1859               -9   R2182                9
    X1972     COST               -85   R1994               -7
    X1972     R1829               -5   R1878               -1
    X1972     R1905               -6   R2027               -1
    X1973     COST                39   R1868               -7
    X1973     R1998               -1   R1938                3
    X1973     R1913               -9   R2166                8
    X1974     COST               -18   R1866               -9
    X1974     R1953               -3   R1877                8
    X1974     R1844               -3   R2091               -4
    X1975     COST               -36   R1879               -7
    X1975     R1995               -9   R1848                6
    X1975     R1830               -4   R2183               -3
    X1976     COST               -90   R1899               -2
    X1976     R1973               -3   R1843               -8
    X1976     R1856               -3   R2196                5
    X1977     COST                32   R1969               -5
    X1977     R1940               -9   R1933                4
    X1977     R1964               -3   R2123                7
    X1978     COST                 5   R1833               -2
    X1978     R1928                2   R1977               -9
    X1978     R1857                5   R2027                5
    X1979     COST                -6   R1847               -5
    X1979     R1924               -9   R1895                2
    X1979     R1836                7   R2121               -9
    X1980     COST                15   R1836               -1
    X1980     R1934                1   R1859                2
    X1980     R1998                7   R2167                8
    X1981     COST                 4   R1961               -8
    X1981     R1913               -5   R1809                3
    X1981     R1907               -3   R2081               -8
    X1982     COST                 6   R1929                5
    X1982     R1957               -9   R1893                9
    X1982     R1949               -2   R2190                5
    X1983     COST               -31   R1864               -1
    X1983     R1928                3   R1850               -1
    X1983     R1914               -7   R2021               -9
    X1984     COST                30   R1951               -5
    X1984     R1912               -4   R1949               -8
    X1984     R1803               -1   R2169                9
    X1985     COST                -3   R1814               -3
    X1985     R1894               -1   R1923               -9
    X1985     R1880               -1   R2197                8
    X1986     COST               -86   R1975               -8
    X1986     R1824               -9   R1959               -5
    X1986     R1922               -3   R2120               -7
    X1987     COST              -146   R1854               -7
    X1987     R1988               -7   R1994               -7
    X1987     R1993                4   R2069                9
    X1988     COST                 4   R1857                9
    X1988     R1928               -3   R1967                2
    X1988     R1945               -5   R2197               -1
    X1989     COST               -36   R1857                6
    X1989     R1989               -8   R1826                4
    X1989     R1992               -5   R2110                4
    X1990     COST                18   R1985                4
    X1990     R1972               -9   R1821                5
    X1990     R1965                3   R2156                7
    X1991     COST                12   R1819               -2
    X1991     R1980                7   R1969               -6
    X1991     R1939               -3   R2083                2
    X1992     COST                48   R1886               -9
    X1992     R1810                4   R1971                8
    X1992     R1865                6   R2179                6
    X1993     COST                 8   R1824                6
    X1993     R1819               -8   R1900                3
    X1993     R1958               -5   R2047               -7
    X1994     COST                39   R1908                9
    X1994     R1884                5   R1879                4
    X1994     R1902               -9   R2129                5
    X1995     COST                13   R1868               -3
    X1995     R1861               -3   R1828               -6
    X1995     R1837                5   R2044                5
    X1996     COST               -38   R1884                1
    X1996     R1860               -2   R1901                4
    X1996     R1939                1   R2034               -6
    X1997     COST                34   R1994                5
    X1997     R1946               -9   R1838                9
    X1997     R1858                5   R2024               -2
    X1998     COST                86   R1954                6
    X1998     R1920               -2   R1828               -4
    X1998     R1933                6   R2069                9
    X1999     COST                48   R1930                6
    X1999     R1912                4   R1959                8
    X1999     R1857               -2   R2033               -9
    X2000     COST                15   R2061                1
    X2000     R2042               -9   R2076                5
    X2000     R2107                9   R2253               -1
    X2001     COST                12   R2131                5
    X2001     R2017                2   R2013                1
    X2001     R2176                9   R2246                3
    X2002     COST                 7   R2167               -6
    X2002     R2020                5   R2035               -5
    X2002     R2106                2   R2339               -4
    X2003     COST               -43   R2150                6
    X2003     R2178                9   R2068               -9
    X2003     R2199               -4   R2265                2
    X2004     COST                 9   R2157               -8
    X2004     R2037               -7   R2184                5
    X2004     R2073                5   R2293               -8
    X2005     COST               -31   R2088               -9
    X2005     R2026                2   R2040                8
    X2005     R2074                2   R2319                3
    X2006     COST               -43   R2100                4
    X2006     R2057               -4   R2030               -3
    X2006     R2150               -7   R2251                2
    X2007     COST                 6   R2037                2
    X2007     R2041               -2   R2160               -1
    X2007     R2048                9   R2329                5
    X2008     COST               -39   R2100                4
    X2008     R2120               -8   R2033               -9
    X2008     R2076               -5   R2395                8
    X2009     COST                -3   R2061               -6
    X2009     R2080               -9   R2066               -6
    X2009     R2071                7   R2301                5
    X2010     COST                21   R2113                8
    X2010     R2166               -9   R2070               -2
    X2010     R2169               -7   R2201                8
    X2011     COST                57   R2060               -1
    X2011     R2061                7   R2127                4
    X2011     R2042                4   R2324                2
    X2012     COST                52   R2123                6
    X2012     R2067               -1   R2115                3
    X2012     R2031               -8   R2321               -9
    X2013     COST              -102   R2004               -7
    X2013     R2032               -3   R2072               -9
    X2013     R2155               -7   R2238               -4
    X2014     COST                20   R2196               -1
    X2014     R2030                5   R2003                2
    X2014     R2182               -5   R2363                3
    X2015     COST               104   R2032                1
    X2015     R2015               -5   R2045                6
    X2015     R2022                9   R2378                6
    X2016     COST                13   R2024                3
    X2016     R2139               -6   R2061               -8
    X2016     R2157               -1   R2267                8
    X2017     COST                63   R2141               -4
    X2017     R2198               -2   R2108                5
    X2017     R2040                5   R2256                5
    X2018     COST                39   R2196                7
    X2018     R2189                2   R2041               -9
    X2018     R2071                6   R2337               -1
    X2019     COST                54   R2079                2
    X2019     R2116               -5   R2130               -4
    X2019     R2150                8   R2324                6
    X2020     COST                16   R2045                2
    X2020     R2104               -4   R2134                4
    X2020     R2058                8   R2268               -2
    X2021     COST               -24   R2023                9
    X2021     R2182               -6   R2013               -4
    X2021     R2169               -4   R2261                3
    X2022     COST               -68   R2075               -8
    X2022     R2164                3   R2086               -2
    X2022     R2112                1   R2375               -8
    X2023     COST               -30   R2075                5
    X2023     R2130               -9   R2177               -3
    X2023     R2166               -2   R2245               -1
    X2024     COST                -2   R2166               -5
    X2024     R2046                8   R2151               -9
    X2024     R2143                4   R2353               -2
    X2025     COST                49   R2031                5
    X2025     R2193               -3   R2187                4
    X2025     R2179                9   R2266                9
    X2026     COST                 3   R2049                7
    X2026     R2067                2   R2081               -9
    X2026     R2009                1   R2368               -7
    X2027     COST                29   R2133                5
    X2027     R2174                7   R2166               -3
    X2027     R2194               -8   R2347                2
    X2028     COST                 1   R2132               -5
    X2028     R2171                9   R2079               -1
    X2028     R2179                5   R2206               -6
    X2029     COST                21   R2078                2
    X2029     R2098               -7   R2156                8
    X2029     R2129                7   R2329                1
    X2030     COST                36   R2007                2
    X2030     R2042               -4   R2070               -3
    X2030     R2057                6   R2391               -1
    X2031     COST               -38   R2108               -9
    X2031     R2184                5   R2039               -5
    X2031     R2106                9   R2310               -2
    X2032     COST                19   R2040                3
    X2032     R2161                7   R2198               -7
    X2032     R2166                5   R2367                6
    X2033     COST                69   R2155                3
    X2033     R2063                9   R2179               -8
    X2033     R2073               -4   R2378               -1
    X2034     COST                10   R2046                9
    X2034     R2175                5   R2161               -7
    X2034     R2127               -5   R2236                8
    X2035     COST               -30   R2059                2
    X2035     R2179               -9   R2087               -3
    X2035     R2046                5   R2211               -1
    X2036     COST                37   R2110                6
    X2036     R2061                1   R2177                1
    X2036     R2073               -9   R2320               -7
    X2037     COST                33   R2168                8
    X2037     R2127               -2   R2131                2
    X2037     R2162               -6   R2333                6
    X2038     COST              -124   R2022               -6
    X2038     R2109               -2   R2158                3
    X2038     R2179                4   R2270               -9
    X2039     COST                 8   R2089                7
    X2039     R2008                6   R2047                5
    X2039     R2090               -2   R2350               -6
    X2040     COST                69   R2111               -2
    X2040     R2056               -2   R2054               -5
    X2040     R2064                7   R2254                6
    X2041     COST                20   R2181                1
    X2041     R2158                4   R2133                2
    X2041     R2174               -9   R2219                5
    X2042     COST               -27   R2060               -6
    X2042     R2103               -3   R2075                2
    X2042     R2065                1   R2252                6
    X2043     COST                18   R2072               -1
    X2043     R2120                3   R2099               -3
    X2043     R2101                8   R2342               -8
    X2044     COST                -4   R2134               -1
    X2044     R2094               -6   R2027               -5
    X2044     R2194                5   R2374                6
    X2045     COST               -16   R2056               -2
    X2045     R2024               -2   R2148               -8
    X2045     R2180               -7   R2259                6
    X2046     COST                 1   R2059                1
    X2046     R2140               -1   R2028               -6
    X2046     R2035                5   R2332               -8
    X2047     COST               -37   R2011                6
    X2047     R2130                2   R2073                1
    X2047     R2071               -7   R2243               -6
    X2048     COST                16   R2080                7
    X2048     R2186                1   R2039                1
    X2048     R2113                4   R2272               -6
    X2049     COST               107   R2125                9
    X2049     R2122               -5   R2085                8
    X2049     R2168                8   R2327               -4
    X2050     COST               -24   R2077               -7
    X2050     R2014               -8   R2183                8
    X2050     R2058               -7   R2203               -4
    X2051     COST                -3   R2192                4
    X2051     R2182               -6   R2135                6
    X2051     R2189               -6   R2317                9
    X2052     COST               -42   R2188               -1
    X2052     R2015               -6   R2164               -6
    X2052     R2175               -3   R2315               -5
    X2053     COST                10   R2167               -9
    X2053     R2193                1   R2174               -4
    X2053     R2163               -4   R2340                1
    X2054     COST               -56   R2187               -1
    X2054     R2174                3   R2014                6
    X2054     R2047               -5   R2270               -7
    X2055     COST               -21   R2135               -1
    X2055     R2015                5   R2082               -9
    X2055     R2028                4   R2333                5
    X2056     COST               -79   R2110               -8
    X2056     R2113               -5   R2090                5
    X2056     R2199               -8   R2234                2
    X2057     COST               -65   R2091               -4
    X2057     R2097               -8   R2050               -7
    X2057     R2015               -2   R2277               -5
    X2058     COST                13   R2179               -9
    X2058     R2126                5   R2006               -1
    X2058     R2176               -7   R2258               -5
    X2059     COST               -59   R2007                1
    X2059     R2036               -6   R2016                2
    X2059     R2121                3   R2327               -6
    X2060     COST                 8   R2198               -9
    X2060     R2046               -5   R2184               -3
    X2060     R2112               -8   R2246                5
    X2061     COST               -36   R2111                1
    X2061     R2185                1   R2160               -2
    X2061     R2085                4   R2325               -9
    X2062     COST                -6   R2138                5
    X2062     R2195               -3   R2145               -6
    X2062     R2045                4   R2303               -4
    X2063     COST                13   R2199                1
    X2063     R2190                9   R2148               -6
    X2063     R2015                2   R2308                8
    X2064     COST                -1   R2179               -2
    X2064     R2014               -5   R2045                5
    X2064     R2114               -8   R2397               -4
    X2065     COST                -6   R2069                7
    X2065     R2091                3   R2035               -3
    X2065     R2075               -2   R2337               -2
    X2066     COST               -37   R2197               -4
    X2066     R2100               -9   R2056                7
    X2066     R2039                9   R2395               -7
    X2067     COST                36   R2055               -9
    X2067     R2008                5   R2004                3
    X2067     R2077                6   R2368                9
    X2068     COST               -18   R2017               -1
    X2068     R2060               -9   R2123                7
    X2068     R2142                9   R2373               -9
    X2069     COST               -31   R2191               -1
    X2069     R2148               -8   R2184               -6
    X2069     R2069               -2   R2221                3
    X2070     COST               -40   R2189               -4
    X2070     R2099                7   R2087               -4
    X2070     R2115               -2   R2315               -8
    X2071     COST                36   R2083                5
    X2071     R2103                9   R2137                3
    X2071     R2149               -2   R2356               -2
    X2072     COST                 4   R2060               -2
    X2072     R2092                7   R2118               -2
    X2072     R2151               -6   R2296                7
    X2073     COST                 4   R2003                6
    X2073     R2197                6   R2062               -6
    X2073     R2124                4   R2240               -5
    X2074     COST               -28   R2168               -5
    X2074     R2117               -7   R2029                2
    X2074     R2098                4   R2271                4
    X2075     COST               -63   R2058                3
    X2075     R2177               -2   R2153               -7
    X2075     R2195                3   R2320               -5
    X2076     COST               -61   R2068               -8
    X2076     R2117               -8   R2133                6
    X2076     R2177               -6   R2367                4
    X2077     R2190                7   R2028               -7
    X2077     R2131               -2   R2104                5
    X2077     R2232               -8
    X2078     COST                23   R2095               -1
    X2078     R2169                4   R2089               -2
    X2078     R2158               -1   R2314                8
    X2079     COST               -24   R2049                4
    X2079     R2076                7   R2014               -7
    X2079     R2177                2   R2220               -5
    X2080     COST                 4   R2045                9
    X2080     R2100               -7   R2084                5
    X2080     R2110                3   R2352               -1
    X2081     COST                 1   R2118               -4
    X2081     R2113                3   R2183                5
    X2081     R2047                6   R2272                2
    X2082     COST                49   R2154               -2
    X2082     R2132               -8   R2010                8
    X2082     R2145                6   R2220                7
    X2083     COST                -8   R2060               -4
    X2083     R2196                3   R2097                5
    X2083     R2148               -5   R2346               -4
    X2084     COST                 7   R2164               -1
    X2084     R2052                4   R2199               -2
    X2084     R2106                3   R2318                1
    X2085     COST                18   R2161               -5
    X2085     R2117               -9   R2193                3
    X2085     R2197               -4   R2272                3
    X2086     COST                68   R2045                8
    X2086     R2026                7   R2084                7
    X2086     R2183                1   R2351               -8
    X2087     COST               -41   R2036                1
    X2087     R2102                4   R2101                2
    X2087     R2069                7   R2282               -9
    X2088     COST                 3   R2141               -5
    X2088     R2112                2   R2177                8
    X2088     R2060                1   R2241               -8
    X2089     COST               -55   R2120                5
    X2089     R2163               -9   R2030               -8
    X2089     R2087               -7   R2261                1
    X2090     COST               -33   R2068               -4
    X2090     R2139               -4   R2197               -7
    X2090     R2051               -4   R2231                2
    X2091     COST                40   R2003                3
    X2091     R2033               -9   R2062                7
    X2091     R2084                6   R2226               -8
    X2092     COST               -47   R2123               -5
    X2092     R2049               -4   R2082               -2
    X2092     R2126               -1   R2244                6
    X2093     COST               -60   R2144                2
    X2093     R2064               -3   R2175               -9
    X2093     R2196               -6   R2258               -3
    X2094     COST                50   R2097               -2
    X2094     R2168                5   R2152                6
    X2094     R2069               -3   R2259               -7
    X2095     COST               -13   R2101                8
    X2095     R2055                9   R2175               -4
    X2095     R2102               -9   R2278                1
    X2096     COST                -8   R2041               -2
    X2096     R2072               -5   R2022               -1
    X2096     R2151                2   R2359               -9
    X2097     COST               -85   R2168               -4
    X2097     R2182                2   R2092               -5
    X2097     R2133                4   R2249               -8
    X2098     COST                40   R2168                4
    X2098     R2149                3   R2161               -1
    X2098     R2119                8   R2267               -4
    X2099     COST                27   R2119                9
    X2099     R2159                3   R2018               -4
    X2099     R2048               -8   R2262                4
    X2100     COST               -93   R2184               -7
    X2100     R2192               -3   R2089                6
    X2100     R2074               -6   R2378               -7
    X2101     COST                10   R2116               -9
    X2101     R2103                3   R2028               -4
    X2101     R2080               -5   R2286               -5
    X2102     COST                59   R2066                2
    X2102     R2104               -6   R2046               -2
    X2102     R2124                7   R2229                3
    X2103     COST               -45   R2130               -1
    X2103     R2160               -4   R2035                6
    X2103     R2108               -6   R2258               -9
    X2104     COST               -33   R2136               -6
    X2104     R2135                2   R2109                5
    X2104     R2095               -3   R2342               -3
    X2105     COST                 3   R2103               -8
    X2105     R2125                8   R2081               -1
    X2105     R2192               -5   R2243               -5
    X2106     COST               -72   R2160                4
    X2106     R2086                2   R2129                3
    X2106     R2056               -8   R2220               -9
    X2107     COST                 9   R2056               -1
    X2107     R2019               -4   R2046               -6
    X2107     R2038               -4   R2278                3
    X2108     COST               -13   R2128               -3
    X2108     R2129                4   R2041                5
    X2108     R2010               -1   R2369                2
    X2109     COST                -8   R2079               -5
    X2109     R2133                1   R2077                3
    X2109     R2072                6   R2205               -5
    X2110     COST               -11   R2169               -2
    X2110     R2089                4   R2010               -6
    X2110     R2016                5   R2246               -6
    X2111     COST                -7   R2001               -1
    X2111     R2184               -2   R2029                1
    X2111     R2119                2   R2304               -3
    X2112     COST                -6   R2115               -6
    X2112     R2167               -3   R2047                2
    X2112     R2161                3   R2308                6
    X2113     COST               -36   R2002               -6
    X2113     R2138                7   R2087               -7
    X2113     R2131                7   R2303                8
    X2114     COST                58   R2080                6
    X2114     R2099               -1   R2144                9
    X2114     R2088               -2   R2213                6
    X2115     COST               -65   R2058                4
    X2115     R2001               -9   R2140               -5
    X2115     R2046               -9   R2367                8
    X2116     COST                15   R2182                2
    X2116     R2179               -6   R2196               -2
    X2116     R2156                9   R2286               -9
    X2117     COST                -6   R2081               -7
    X2117     R2178                8   R2078               -6
    X2117     R2163                8   R2333               -9
    X2118     COST                23   R2135                1
    X2118     R2005                3   R2044               -2
    X2118     R2062                9   R2374               -5
    X2119     R2102               -7   R2042                6
    X2119     R2067               -3   R2014                8
    X2119     R2240                3
    X2120     COST               -42   R2196                3
    X2120     R2160               -4   R2006               -2
    X2120     R2012               -9   R2398               -3
    X2121     COST               -35   R2139                1
    X2121     R2196                7   R2059               -7
    X2121     R2013                1   R2354                5
    X2122     COST                70   R2026                8
    X2122     R2120                4   R2115               -9
    X2122     R2151               -1   R2397               -7
    X2123     COST               -12   R2111                7
    X2123     R2158                4   R2166                4
    X2123     R2103               -4   R2202               -7
    X2124     COST                99   R2141               -5
    X2124     R2154                7   R2081                1
    X2124     R2015                7   R2353               -9
    X2125     COST                19   R2056               -2
    X2125     R2051                5   R2130                2
    X2125     R2046                7   R2231               -2
    X2126     COST                17   R2088               -8
    X2126     R2197                6   R2188                7
    X2126     R2034                9   R2314               -2
    X2127     COST               -80   R2153               -8
    X2127     R2136               -7   R2020                7
    X2127     R2006                3   R2226                3
    X2128     COST               -35   R2152               -9
    X2128     R2121               -4   R2054                4
    X2128     R2065                3   R2376                7
    X2129     COST                29   R2027               -8
    X2129     R2174                5   R2044                3
    X2129     R2041               -3   R2300               -7
    X2130     COST                19   R2086                8
    X2130     R2195                7   R2180                9
    X2130     R2095               -4   R2273               -3
    X2131     COST                61   R2070                1
    X2131     R2066                4   R2163                3
    X2131     R2172               -7   R2299                7
    X2132     COST                -4   R2175               -1
    X2132     R2073               -4   R2028                8
    X2132     R2096                2   R2222               -1
    X2133     R2101                2   R2190                6
    X2133     R2149               -4   R2197                2
    X2133     R2288                6
    X2134     R2065               -6   R2049                2
    X2134     R2089                2   R2039                8
    X2134     R2352               -4
    X2135     COST               -14   R2132               -3
    X2135     R2185                9   R2116               -3
    X2135     R2188                2   R2277               -5
    X2136     COST                 3   R2114               -6
    X2136     R2122               -6   R2181               -2
    X2136     R2185                5   R2212               -4
    X2137     COST               -85   R2183                8
    X2137     R2118               -7   R2087               -1
    X2137     R2134               -1   R2249               -8
    X2138     COST              -126   R2064               -6
    X2138     R2047                2   R2143               -9
    X2138     R2128               -6   R2223               -8
    X2139     COST               -15   R2174                9
    X2139     R2100                7   R2063               -5
    X2139     R2102               -3   R2278               -2
    X2140     COST                24   R2029               -8
    X2140     R2093                3   R2013                9
    X2140     R2027                8   R2236               -6
    X2141     COST               -51   R2107                8
    X2141     R2156               -2   R2000               -7
    X2141     R2016               -9   R2291               -4
    X2142     COST                30   R2131                7
    X2142     R2057                5   R2075                9
    X2142     R2142               -2   R2212               -2
    X2143     COST               -28   R2184               -3
    X2143     R2019                2   R2022               -7
    X2143     R2118               -5   R2266                8
    X2144     COST                 6   R2007               -6
    X2144     R2029               -4   R2171               -6
    X2144     R2019               -8   R2273                8
    X2145     COST                10   R2029               -8
    X2145     R2046               -3   R2082                5
    X2145     R2163                5   R2336               -5
    X2146     COST                15   R2053                1
    X2146     R2183               -8   R2100                1
    X2146     R2071               -4   R2249                3
    X2147     COST                 8   R2076               -3
    X2147     R2156                2   R2129                7
    X2147     R2119               -7   R2259                9
    X2148     COST                17   R2142                5
    X2148     R2119                5   R2051                1
    X2148     R2023               -2   R2286                1
    X2149     COST                12   R2091               -2
    X2149     R2110                4   R2068               -2
    X2149     R2159               -3   R2251                1
    X2150     COST               -55   R2050               -9
    X2150     R2021               -5   R2081                2
    X2150     R2176               -8   R2397               -1
    X2151     COST                22   R2028                8
    X2151     R2111                2   R2115                7
    X2151     R2191                1   R2223                2
    X2152     COST               -46   R2149                4
    X2152     R2038               -1   R2060               -6
    X2152     R2173               -7   R2334               -2
    X2153     COST               -14   R2043                5
    X2153     R2079               -1   R2095               -8
    X2153     R2026               -1   R2266                1
    X2154     COST              -100   R2168               -5
    X2154     R2169               -6   R2118               -8
    X2154     R2121               -7   R2239                6
    X2155     COST                21   R2152                8
    X2155     R2047                3   R2195               -6
    X2155     R2045                6   R2396               -3
    X2156     COST                -3   R2011               -7
    X2156     R2008               -2   R2141                8
    X2156     R2187               -3   R2261                2
    X2157     COST                44   R2169                1
    X2157     R2086               -8   R2198               -8
    X2157     R2140                9   R2313               -2
    X2158     COST                27   R2178               -5
    X2158     R2149               -6   R2010                3
    X2158     R2104                4   R2245                3
    X2159     COST                64   R2080                9
    X2159     R2104                6   R2031                6
    X2159     R2061                7   R2339                2
    X2160     COST                11   R2119               -9
    X2160     R2116               -2   R2011               -9
    X2160     R2001                9   R2327               -1
    X2161     COST                17   R2079               -7
    X2161     R2074               -6   R2122               -3
    X2161     R2134                8   R2348                4
    X2162     COST                 4   R2078                5
    X2162     R2121               -6   R2155               -9
    X2162     R2057                8   R2272                7
    X2163     COST               -11   R2018                6
    X2163     R2093               -8   R2173                2
    X2163     R2064                5   R2248               -3
    X2164     COST                47   R2174               -6
    X2164     R2003                3   R2124                5
    X2164     R2192                4   R2262               -7
    X2165     COST               -60   R2023                5
    X2165     R2131               -7   R2129                2
    X2165     R2177               -3   R2227               -4
    X2166     COST                -9   R2067               -5
    X2166     R2006                5   R2158                6
    X2166     R2004               -6   R2251                1
    X2167     COST               -12   R2110               -3
    X2167     R2195                7   R2081                6
    X2167     R2119                3   R2368               -4
    X2168     COST                33   R2042                2
    X2168     R2035               -6   R2175                2
    X2168     R2072                5   R2260                3
    X2169     COST               -63   R2180               -6
    X2169     R2189               -2   R2092               -8
    X2169     R2126               -7   R2392               -7
    X2170     COST               -12   R2080               -4
    X2170     R2197                7   R2044               -4
    X2170     R2063                2   R2396                2
    X2171     COST                50   R2023               -4
    X2171     R2125                6   R2050                1
    X2171     R2188               -8   R2315               -1
    X2172     COST               113   R2102                8
    X2172     R2126                9   R2196               -6
    X2172     R2125                7   R2255                4
    X2173     COST                82   R2064                6
    X2173     R2100               -9   R2001                3
    X2173     R2136                8   R2217                1
    X2174     COST               105   R2064                5
    X2174     R2166                2   R2123                6
    X2174     R2056                6   R2222                6
    X2175     COST                11   R2118               -2
    X2175     R2176               -3   R2092                3
    X2175     R2096                2   R2228               -1
    X2176     COST                 1   R2133                6
    X2176     R2031                3   R2179               -4
    X2176     R2162                2   R2210               -6
    X2177     COST                77   R2090                4
    X2177     R2138                5   R2063                9
    X2177     R2154               -2   R2348                1
    X2178     COST               -16   R2199                6
    X2178     R2191               -8   R2048                9
    X2178     R2031                4   R2276                3
    X2179     COST               -68   R2154               -4
    X2179     R2184               -6   R2156                1
    X2179     R2082               -4   R2256               -7
    X2180     COST                42   R2130               -5
    X2180     R2173                8   R2074                4
    X2180     R2197                5   R2230                5
    X2181     COST               -21   R2040               -5
    X2181     R2181                1   R2025                2
    X2181     R2192               -5   R2257                3
    X2182     R2137                9   R2122                3
    X2182     R2023                9   R2148                6
    X2182     R2389               -3
    X2183     COST              -113   R2154               -4
    X2183     R2022               -9   R2014                5
    X2183     R2076                8   R2278               -3
    X2184     COST               -21   R2061               -3
    X2184     R2054               -4   R2190               -3
    X2184     R2002                8   R2352               -3
    X2185     COST               -15   R2185                8
    X2185     R2082               -3   R2117               -3
    X2185     R2066               -2   R2305                5
    X2186     COST                 7   R2117               -1
    X2186     R2072               -3   R2118                6
    X2186     R2015                5   R2230               -9
    X2187     COST                46   R2022               -2
    X2187     R2153                9   R2072                8
    X2187     R2007                4   R2268                8
    X2188     COST                69   R2070                1
    X2188     R2087                8   R2062               -3
    X2188     R2112                9   R2275               -1
    X2189     COST               108   R2128                6
    X2189     R2065                9   R2032                9
    X2189     R2113                9   R2374                8
    X2190     COST                49   R2068                2
    X2190     R2119                1   R2099                6
    X2190     R2127               -1   R2337                4
    X2191     COST                 5   R2113               -5
    X2191     R2176                9   R2065               -8
    X2191     R2074               -3   R2362               -2
    X2192     COST               -41   R2100                8
    X2192     R2124               -9   R2160               -3
    X2192     R2008               -9   R2329                7
    X2193     R2115                6   R2140                3
    X2193     R2152               -9   R2187               -4
    X2193     R2207                6
    X2194     COST               -67   R2061               -5
    X2194     R2163               -3   R2013                2
    X2194     R2140               -5   R2211               -2
    X2195     COST               -54   R2168               -6
    X2195     R2020               -9   R2141                2
    X2195     R2049               -9   R2296                7
    X2196     COST                12   R2097               -7
    X2196     R2167               -3   R2181                4
    X2196     R2074               -8   R2363               -6
    X2197     COST               -79   R2121               -9
    X2197     R2072               -2   R2147               -6
    X2197     R2093               -2   R2237                6
    X2198     COST               -54   R2162               -5
    X2198     R2041                9   R2105               -3
    X2198     R2181               -8   R2284                2
    X2199     COST                 1   R2135                1
    X2199     R2104                3   R2033               -9
    X2199     R2047               -8   R2343                1
    X2200     COST               -41   R2355               -6
    X2200     R2344               -5   R2385               -3
    X2200     R2319               -8   R2599               -9
    X2201     COST               -63   R2376                9
    X2201     R2218               -5   R2348               -2
    X2201     R2378               -8   R2544                7
    X2202     COST                45   R2202               -4
    X2202     R2394                5   R2256               -5
    X2202     R2222                7   R2453                4
    X2203     COST               -63   R2286               -4
    X2203     R2399               -6   R2231               -5
    X2203     R2327               -9   R2584                5
    X2204     COST                77   R2313               -7
    X2204     R2334               -7   R2226               -7
    X2204     R2356                6   R2559                8
    X2205     COST               -62   R2340               -4
    X2205     R2299               -8   R2383               -4
    X2205     R2344                4   R2494               -1
    X2206     COST                79   R2284                9
    X2206     R2216                6   R2351               -3
    X2206     R2285                7   R2587                2
    X2207     COST                 4   R2374               -4
    X2207     R2225                1   R2379               -7
    X2207     R2260               -1   R2410                9
    X2208     COST               -10   R2383               -6
    X2208     R2250               -3   R2271                7
    X2208     R2316                8   R2528                1
    X2209     COST                34   R2391                9
    X2209     R2395                1   R2394                2
    X2209     R2319               -7   R2510                8
    X2210     COST               -25   R2365               -6
    X2210     R2237               -7   R2387                2
    X2210     R2250               -1   R2420               -7
    X2211     COST               -31   R2254               -3
    X2211     R2242               -4   R2277                3
    X2211     R2369                2   R2406               -2
    X2212     COST                19   R2346                2
    X2212     R2341                9   R2349               -9
    X2212     R2289               -1   R2496                6
    X2213     COST                35   R2351                5
    X2213     R2308               -4   R2247                2
    X2213     R2233                7   R2517                7
    X2214     COST               -31   R2380                1
    X2214     R2336               -9   R2335               -3
    X2214     R2371               -3   R2411                4
    X2215     COST                23   R2314               -5
    X2215     R2252               -1   R2361               -1
    X2215     R2318                7   R2515                1
    X2216     COST                 5   R2250               -6
    X2216     R2216               -6   R2322                9
    X2216     R2352                1   R2586                1
    X2217     COST               -73   R2290                1
    X2217     R2215               -2   R2234               -1
    X2217     R2307               -9   R2517                5
    X2218     COST               -34   R2205                6
    X2218     R2342                6   R2373               -4
    X2218     R2222                9   R2547               -3
    X2219     COST               -59   R2364               -5
    X2219     R2207               -2   R2295               -7
    X2219     R2277               -7   R2514                9
    X2220     COST               -51   R2324                3
    X2220     R2335               -1   R2314               -8
    X2220     R2389               -4   R2452               -9
    X2221     COST               102   R2334                1
    X2221     R2228               -4   R2239                3
    X2221     R2327                5   R2505                8
    X2222     COST               -54   R2364               -6
    X2222     R2278                2   R2269                7
    X2222     R2255               -6   R2493               -6
    X2223     COST                36   R2201                4
    X2223     R2396               -2   R2379               -8
    X2223     R2319                2   R2517               -4
    X2224     COST                10   R2384               -2
    X2224     R2361                6   R2235                3
    X2224     R2244                1   R2591               -1
    X2225     COST               -30   R2338                4
    X2225     R2295                9   R2224                4
    X2225     R2203               -6   R2480                6
    X2226     COST                46   R2223                6
    X2226     R2347               -5   R2207               -3
    X2226     R2356                5   R2508                6
    X2227     COST               112   R2232               -5
    X2227     R2240                1   R2241                4
    X2227     R2238                8   R2413                2
    X2228     COST                26   R2244               -2
    X2228     R2233                6   R2329               -8
    X2228     R2291               -9   R2551               -8
    X2229     COST                 6   R2363               -1
    X2229     R2317                9   R2282               -3
    X2229     R2203                4   R2561                5
    X2230     R2312               -9   R2323                9
    X2230     R2338                2   R2300                5
    X2230     R2578               -5
    X2231     COST               -66   R2225               -5
    X2231     R2292               -2   R2243                8
    X2231     R2324                6   R2457               -7
    X2232     COST                16   R2288                5
    X2232     R2395               -6   R2246                4
    X2232     R2224               -6   R2560                2
    X2233     COST                28   R2363               -3
    X2233     R2271                6   R2255                8
    X2233     R2328               -9   R2428               -1
    X2234     COST                36   R2345                5
    X2234     R2223               -9   R2258                6
    X2234     R2323               -2   R2580               -6
    X2235     COST                48   R2342               -7
    X2235     R2283               -8   R2205               -6
    X2235     R2384                8   R2522                9
    X2236     COST                18   R2262                5
    X2236     R2353                2   R2222                1
    X2236     R2238                2   R2574               -2
    X2237     COST                24   R2307                4
    X2237     R2342                2   R2218                3
    X2237     R2352               -5   R2472               -8
    X2238     COST                 5   R2306                5
    X2238     R2337                6   R2358               -3
    X2238     R2263               -5   R2592                5
    X2239     COST               -57   R2375               -6
    X2239     R2200               -2   R2218                7
    X2239     R2334                3   R2487                4
    X2240     COST               -40   R2250               -6
    X2240     R2365                8   R2248               -6
    X2240     R2371               -5   R2575               -3
    X2241     COST                10   R2286               -4
    X2241     R2340                8   R2349                1
    X2241     R2355                8   R2525               -2
    X2242     COST                49   R2331                9
    X2242     R2282               -6   R2237               -5
    X2242     R2348                1   R2591               -8
    X2243     COST               -60   R2364               -6
    X2243     R2215               -6   R2275                8
    X2243     R2224                3   R2509               -4
    X2244     COST                 2   R2384               -6
    X2244     R2267                6   R2343                3
    X2244     R2277               -1   R2544                5
    X2245     R2276               -2   R2215                4
    X2245     R2395               -8   R2391                3
    X2245     R2508               -4
    X2246     COST               -85   R2321                3
    X2246     R2274               -4   R2289                9
    X2246     R2371               -7   R2413               -8
    X2247     COST               -20   R2362               -8
    X2247     R2215               -4   R2258               -4
    X2247     R2254               -8   R2487                9
    X2248     COST                59   R2254               -4
    X2248     R2220                9   R2303               -3
    X2248     R2268                4   R2561                6
    X2249     COST               -52   R2203                2
    X2249     R2280               -3   R2221                6
    X2249     R2327               -8   R2419               -7
    X2250     COST                66   R2221               -1
    X2250     R2304               -7   R2382                5
    X2250     R2309               -5   R2484                7
    X2251     COST                57   R2238                1
    X2251     R2363               -7   R2277                2
    X2251     R2296               -6   R2489                5
    X2252     COST               -17   R2354               -5
    X2252     R2208               -7   R2273                6
    X2252     R2293               -4   R2408               -7
    X2253     COST               -33   R2355               -3
    X2253     R2221               -8   R2392                1
    X2253     R2372               -9   R2407                9
    X2254     COST                 5   R2390               -5
    X2254     R2247               -5   R2275               -6
    X2254     R2315                5   R2442                3
    X2255     COST               -23   R2300                8
    X2255     R2376               -1   R2301                6
    X2255     R2217               -7   R2590               -1
    X2256     COST                99   R2221                7
    X2256     R2255                6   R2237               -8
    X2256     R2270                9   R2485               -5
    X2257     COST               -66   R2211               -2
    X2257     R2292                7   R2334               -9
    X2257     R2264               -7   R2416                1
    X2258     COST                14   R2210               -8
    X2258     R2277               -1   R2255                9
    X2258     R2213                7   R2544                7
    X2259     COST                12   R2226                3
    X2259     R2340                7   R2250                8
    X2259     R2279                5   R2433                5
    X2260     COST                 1   R2232                4
    X2260     R2202                7   R2204                6
    X2260     R2360               -7   R2499                7
    X2261     COST                50   R2246                3
    X2261     R2370               -3   R2311                6
    X2261     R2316                5   R2446                2
    X2262     COST                18   R2229                3
    X2262     R2286                1   R2362               -7
    X2262     R2267                2   R2560               -6
    X2263     COST                12   R2376               -1
    X2263     R2325                6   R2295                7
    X2263     R2229               -3   R2432               -3
    X2264     COST                10   R2399                5
    X2264     R2351               -9   R2295                4
    X2264     R2265                6   R2494               -9
    X2265     COST               -44   R2306                5
    X2265     R2336               -4   R2396                8
    X2265     R2353                5   R2511               -6
    X2266     COST               -80   R2292                9
    X2266     R2389               -3   R2231               -5
    X2266     R2274               -9   R2489               -1
    X2267     COST                56   R2386               -3
    X2267     R2392               -3   R2274                6
    X2267     R2295                6   R2578               -7
    X2268     COST                51   R2254               -1
    X2268     R2317                9   R2355               -6
    X2268     R2266                8   R2429                4
    X2269     COST               114   R2356                4
    X2269     R2249                1   R2246               -1
    X2269     R2219                4   R2527                9
    X2270     R2294               -5   R2288                6
    X2270     R2333               -5   R2273                6
    X2270     R2473               -3
    X2271     COST                 2   R2323               -4
    X2271     R2302               -5   R2395               -5
    X2271     R2275               -6   R2499               -5
    X2272     COST               -45   R2276               -9
    X2272     R2243                4   R2296                9
    X2272     R2287                7   R2456                8
    X2273     COST                28   R2282                4
    X2273     R2320                5   R2254               -7
    X2273     R2283               -5   R2426                2
    X2274     COST               -80   R2285                5
    X2274     R2220               -2   R2335               -3
    X2274     R2378               -8   R2544                7
    X2275     COST               -21   R2397               -9
    X2275     R2209                6   R2207               -6
    X2275     R2392               -8   R2562               -6
    X2276     COST               -27   R2212               -5
    X2276     R2256               -4   R2245                3
    X2276     R2365                7   R2502               -6
    X2277     COST                75   R2373                7
    X2277     R2252               -4   R2231                3
    X2277     R2201                2   R2510                2
    X2278     COST               -62   R2386                4
    X2278     R2345               -1   R2362               -4
    X2278     R2224               -8   R2465               -6
    X2279     COST                13   R2316                6
    X2279     R2260                2   R2323               -5
    X2279     R2221               -8   R2510               -1
    X2280     COST                63   R2216               -9
    X2280     R2274                6   R2316                4
    X2280     R2264                5   R2594                2
    X2281     COST                44   R2330                1
    X2281     R2317               -4   R2384                4
    X2281     R2271                6   R2494                6
    X2282     COST                16   R2355                8
    X2282     R2388                2   R2339               -5
    X2282     R2269                2   R2573                2
    X2283     COST               -36   R2326               -9
    X2283     R2323                1   R2252                8
    X2283     R2241                3   R2555               -5
    X2284     COST               -53   R2226                3
    X2284     R2242               -6   R2358                1
    X2284     R2258                8   R2572                1
    X2285     COST               -52   R2383                7
    X2285     R2354                6   R2251                9
    X2285     R2350               -8   R2527               -8
    X2286     COST                 9   R2280                8
    X2286     R2238               -2   R2277                2
    X2286     R2331               -2   R2533                9
    X2287     COST                 7   R2223               -9
    X2287     R2219                8   R2218                3
    X2287     R2314               -5   R2472                7
    X2288     COST               -34   R2258               -2
    X2288     R2300               -2   R2235               -4
    X2288     R2380               -4   R2447               -5
    X2289     COST                16   R2205                5
    X2289     R2358               -3   R2273               -3
    X2289     R2269                6   R2410                7
    X2290     COST                10   R2279               -8
    X2290     R2317               -7   R2266                1
    X2290     R2335               -8   R2583                1
    X2291     COST               -91   R2364               -7
    X2291     R2395               -8   R2268               -6
    X2291     R2249               -5   R2528               -1
    X2292     COST                40   R2317                7
    X2292     R2303                6   R2219               -2
    X2292     R2254                2   R2464                2
    X2293     R2259               -8   R2302                3
    X2293     R2308                6   R2368                2
    X2293     R2404                2
    X2294     COST               -20   R2207                6
    X2294     R2390               -9   R2330                9
    X2294     R2326               -4   R2516                1
    X2295     COST                22   R2249                1
    X2295     R2361                6   R2374               -8
    X2295     R2337                1   R2447                4
    X2296     COST               -68   R2298               -9
    X2296     R2390                9   R2234                8
    X2296     R2251                4   R2407               -6
    X2297     COST                28   R2249               -3
    X2297     R2278                5   R2223               -7
    X2297     R2220                4   R2434                2
    X2298     COST                43   R2271               -2
    X2298     R2242                1   R2334                6
    X2298     R2364                2   R2492                6
    X2299     COST                18   R2376               -3
    X2299     R2379                9   R2208                6
    X2299     R2315               -9   R2434               -3
    X2300     COST                79   R2214                1
    X2300     R2350                8   R2211               -1
    X2300     R2213                8   R2528                5
    X2301     COST                84   R2211                9
    X2301     R2320                5   R2396               -9
    X2301     R2251               -8   R2503                2
    X2302     COST               -43   R2258               -3
    X2302     R2241               -6   R2392                5
    X2302     R2359               -6   R2422                1
    X2303     COST                31   R2211                5
    X2303     R2225               -7   R2283               -8
    X2303     R2333                9   R2503               -9
    X2304     COST                66   R2351                5
    X2304     R2282               -2   R2281                6
    X2304     R2267                8   R2437                5
    X2305     COST                 4   R2265                1
    X2305     R2355                6   R2289               -4
    X2305     R2366                7   R2493               -3
    X2306     COST                 3   R2271                6
    X2306     R2276               -1   R2293               -8
    X2306     R2254               -3   R2509                6
    X2307     COST                53   R2383                8
    X2307     R2373               -8   R2281                9
    X2307     R2313                5   R2463                8
    X2308     COST                 7   R2228               -7
    X2308     R2272                3   R2234                3
    X2308     R2330                3   R2498                5
    X2309     COST                -6   R2278               -2
    X2309     R2250                2   R2275                5
    X2309     R2228                8   R2504                9
    X2310     R2389                4   R2343                3
    X2310     R2228               -6   R2258                5
    X2310     R2427                3
    X2311     COST                18   R2222               -8
    X2311     R2384               -2   R2247                6
    X2311     R2395                6   R2510                7
    X2312     COST               -49   R2393               -4
    X2312     R2267               -5   R2328               -7
    X2312     R2392               -8   R2452               -3
    X2313     COST                78   R2245                4
    X2313     R2323               -2   R2313                9
    X2313     R2294                7   R2469                7
    X2314     COST                91   R2270               -5
    X2314     R2345                7   R2372                2
    X2314     R2205               -8   R2537                8
    X2315     COST                17   R2348               -1
    X2315     R2320                2   R2386               -4
    X2315     R2271                9   R2568               -6
    X2316     COST               -17   R2225               -7
    X2316     R2223                5   R2288               -6
    X2316     R2311               -1   R2536                1
    X2317     COST               -10   R2298                2
    X2317     R2350               -6   R2395               -5
    X2317     R2297                6   R2586               -8
    X2318     COST              -139   R2256                2
    X2318     R2284               -3   R2242               -6
    X2318     R2251                9   R2556               -8
    X2319     COST                 6   R2369               -9
    X2319     R2391                1   R2231                8
    X2319     R2266                1   R2422                8
    X2320     COST               -19   R2257                8
    X2320     R2290               -7   R2313                2
    X2320     R2368                1   R2568                4
    X2321     COST                 8   R2243                6
    X2321     R2327                4   R2267               -4
    X2321     R2360               -2   R2471               -5
    X2322     COST               -64   R2229               -2
    X2322     R2370               -8   R2293                3
    X2322     R2313               -6   R2406               -7
    X2323     COST                -6   R2276                7
    X2323     R2365                4   R2309               -4
    X2323     R2354               -8   R2512               -6
    X2324     COST                18   R2261               -9
    X2324     R2283                8   R2346                4
    X2324     R2334                6   R2544               -7
    X2325     COST                58   R2201                2
    X2325     R2343                9   R2276                4
    X2325     R2251                4   R2447                8
    X2326     COST                59   R2318                1
    X2326     R2358                4   R2345                7
    X2326     R2205               -1   R2504                4
    X2327     COST               -19   R2274               -3
    X2327     R2305                4   R2392               -3
    X2327     R2234               -7   R2476               -7
    X2328     COST                 4   R2366               -9
    X2328     R2250               -5   R2321               -4
    X2328     R2367               -3   R2487                7
    X2329     COST                29   R2369                5
    X2329     R2377                1   R2281                8
    X2329     R2326               -7   R2564               -1
    X2330     COST               -88   R2354                2
    X2330     R2317                1   R2227               -5
    X2330     R2344               -8   R2424                8
    X2331     COST                26   R2244                8
    X2331     R2300               -9   R2377                4
    X2331     R2393               -7   R2409                3
    X2332     R2256                2   R2315                5
    X2332     R2272               -5   R2329               -5
    X2332     R2532                4
    X2333     COST                 6   R2259               -1
    X2333     R2380               -6   R2294                4
    X2333     R2240                7   R2413                4
    X2334     COST                 3   R2379                9
    X2334     R2293                5   R2309               -3
    X2334     R2324                3   R2561                4
    X2335     COST                64   R2390                2
    X2335     R2319               -7   R2364                9
    X2335     R2236               -1   R2576               -7
    X2336     COST               -31   R2375               -3
    X2336     R2313               -2   R2207                9
    X2336     R2246               -5   R2410                3
    X2337     COST               -87   R2244               -9
    X2337     R2376               -9   R2364               -2
    X2337     R2380               -1   R2505               -8
    X2338     COST               111   R2221               -7
    X2338     R2254                8   R2383                4
    X2338     R2234                8   R2406                9
    X2339     COST                78   R2241                7
    X2339     R2364                1   R2342               -7
    X2339     R2265               -7   R2420                6
    X2340     COST                 5   R2248               -3
    X2340     R2352               -1   R2307                2
    X2340     R2319                3   R2510               -4
    X2341     COST               -43   R2299               -6
    X2341     R2339                1   R2332                7
    X2341     R2224                2   R2597               -1
    X2342     COST                17   R2263                3
    X2342     R2398                5   R2355                3
    X2342     R2289               -3   R2535                8
    X2343     COST                 5   R2361                9
    X2343     R2233                1   R2355               -7
    X2343     R2370               -2   R2579               -2
    X2344     COST               -23   R2263               -6
    X2344     R2261                8   R2228               -4
    X2344     R2239                5   R2574               -6
    X2345     COST               -75   R2294                3
    X2345     R2211               -9   R2247               -5
    X2345     R2398                8   R2433                7
    X2346     COST                 4   R2301               -1
    X2346     R2223               -6   R2288                8
    X2346     R2277                1   R2553               -1
    X2347     R2387               -2   R2307               -3
    X2347     R2201                1   R2359                3
    X2347     R2484                3
    X2348     COST               -63   R2226                8
    X2348     R2247               -4   R2347                5
    X2348     R2251                1   R2400               -7
    X2349     COST                52   R2336               -3
    X2349     R2304                7   R2257               -1
    X2349     R2258               -3   R2449                7
    X2350     COST                 9   R2289               -9
    X2350     R2228                1   R2379                9
    X2350     R2250               -8   R2548                4
    X2351     COST               -25   R2324               -9
    X2351     R2254               -2   R2278               -2
    X2351     R2386                9   R2496               -2
    X2352     COST                -3   R2332               -2
    X2352     R2344               -1   R2319               -8
    X2352     R2334                2   R2532               -6
    X2353     COST               -74   R2332               -2
    X2353     R2390                3   R2213               -8
    X2353     R2350               -1   R2584               -9
    X2354     COST                -8   R2254               -8
    X2354     R2231               -6   R2321               -6
    X2354     R2392                2   R2421                7
    X2355     COST                -6   R2338               -1
    X2355     R2235               -1   R2204               -6
    X2355     R2219                4   R2425               -7
    X2356     COST               -57   R2388                2
    X2356     R2212               -8   R2259               -4
    X2356     R2367               -5   R2464               -7
    X2357     COST                38   R2252               -7
    X2357     R2228               -2   R2260                2
    X2357     R2332                1   R2500                8
    X2358     COST               -14   R2240               -2
    X2358     R2329                6   R2245               -2
    X2358     R2207                4   R2535                7
    X2359     COST                62   R2334               -2
    X2359     R2375                3   R2364                3
    X2359     R2211                4   R2432               -8
    X2360     COST               -78   R2284               -1
    X2360     R2207               -7   R2243                9
    X2360     R2299               -8   R2470               -7
    X2361     COST                48   R2232                7
    X2361     R2237                5   R2200                8
    X2361     R2316               -8   R2504               -4
    X2362     COST                46   R2239                4
    X2362     R2266                2   R2375                7
    X2362     R2211               -3   R2553                3
    X2363     COST               -13   R2225                1
    X2363     R2267               -7   R2229                8
    X2363     R2323               -9   R2588                9
    X2364     COST               -19   R2391               -4
    X2364     R2271                4   R2236               -2
    X2364     R2258                7   R2426               -9
    X2365     COST                49   R2326                5
    X2365     R2217                7   R2361               -1
    X2365     R2359               -9   R2419               -8
    X2366     COST                56   R2325                4
    X2366     R2234                5   R2266                8
    X2366     R2207               -6   R2415                4
    X2367     COST               -18   R2352               -3
    X2367     R2387               -9   R2215                3
    X2367     R2361                4   R2453                3
    X2368     COST               114   R2293                6
    X2368     R2284                9   R2276                5
    X2368     R2285               -1   R2460                7
    X2369     COST               -57   R2236                2
    X2369     R2388               -7   R2210               -7
    X2369     R2342                2   R2579                7
    X2370     COST                97   R2243                9
    X2370     R2381               -6   R2245                9
    X2370     R2334               -3   R2405                4
    X2371     COST                62   R2208               -6
    X2371     R2333               -4   R2200                7
    X2371     R2286               -2   R2469                5
    X2372     COST               -20   R2290                5
    X2372     R2227               -5   R2353               -4
    X2372     R2256               -9   R2528                7
    X2373     COST                20   R2236               -4
    X2373     R2304                2   R2208                7
    X2373     R2202                7   R2536               -1
    X2374     COST                14   R2225               -6
    X2374     R2350               -9   R2231                8
    X2374     R2233                4   R2440                8
    X2375     COST                51   R2208               -1
    X2375     R2284                8   R2393               -1
    X2375     R2376               -3   R2486                9
    X2376     COST                -7   R2340               -7
    X2376     R2335                5   R2206               -7
    X2376     R2273                1   R2480               -2
    X2377     COST                36   R2227               -1
    X2377     R2328               -4   R2358                6
    X2377     R2240                8   R2444                5
    X2378     COST               -17   R2304               -9
    X2378     R2399               -5   R2310               -9
    X2378     R2302                1   R2429               -2
    X2379     COST               -24   R2240                5
    X2379     R2297                2   R2267               -2
    X2379     R2205               -6   R2481               -6
    X2380     COST               -16   R2209                7
    X2380     R2203                3   R2398               -8
    X2380     R2277                4   R2452               -9
    X2381     COST               -59   R2220               -9
    X2381     R2387               -2   R2243                5
    X2381     R2384                5   R2564                9
    X2382     COST               -21   R2331                3
    X2382     R2308               -8   R2235               -4
    X2382     R2283                9   R2550               -4
    X2383     COST               -33   R2265               -3
    X2383     R2254               -8   R2294                7
    X2383     R2266               -3   R2503               -9
    X2384     COST                40   R2240                1
    X2384     R2365               -1   R2212                9
    X2384     R2281                8   R2451               -1
    X2385     COST               -10   R2317                2
    X2385     R2228               -7   R2340               -4
    X2385     R2336               -2   R2529               -1
    X2386     COST               -81   R2388               -7
    X2386     R2216                7   R2375               -4
    X2386     R2211               -6   R2498               -9
    X2387     COST                28   R2360                2
    X2387     R2312                9   R2391               -1
    X2387     R2326                4   R2471                9
    X2388     COST                 4   R2301               -2
    X2388     R2397               -6   R2386               -8
    X2388     R2230               -2   R2434               -3
    X2389     COST                54   R2287                8
    X2389     R2370                9   R2298                6
    X2389     R2324                6   R2454               -1
    X2390     COST               -66   R2244                3
    X2390     R2327               -9   R2326               -1
    X2390     R2225               -3   R2571                2
    X2391     COST                47   R2223               -1
    X2391     R2359               -3   R2373                2
    X2391     R2387                5   R2513                1
    X2392     COST               -32   R2206               -9
    X2392     R2397                5   R2373               -5
    X2392     R2232                5   R2482               -2
    X2393     COST                89   R2385                8
    X2393     R2210                9   R2285               -1
    X2393     R2293                1   R2479                2
    X2394     COST               -16   R2223                9
    X2394     R2225               -3   R2306               -3
    X2394     R2314                9   R2519               -7
    X2395     COST               -20   R2280               -7
    X2395     R2332                1   R2212               -5
    X2395     R2306               -5   R2416                5
    X2396     COST                20   R2339               -9
    X2396     R2239               -9   R2366               -2
    X2396     R2205               -1   R2519                8
    X2397     R2358                3   R2304               -5
    X2397     R2332               -1   R2343               -8
    X2397     R2438               -8
    X2398     R2247                1   R2398                6
    X2398     R2370                9   R2218                1
    X2398     R2487               -2
    X2399     COST               -32   R2359                8
    X2399     R2256                3   R2330               -2
    X2399     R2345               -4   R2501                7
    X2400     COST                -2   R2476               -2
    X2400     R2407               -3   R2576               -9
    X2400     R2593               -1   R2633               -5
    X2401     COST                64   R2567                6
    X2401     R2527                8   R2535                4
    X2401     R2458               -9   R2712                5
    X2402     COST               -35   R2551                1
    X2402     R2410               -7   R2508                6
    X2402     R2446               -4   R2746                6
    X2403     COST               -27   R2521               -9
    X2403     R2472               -4   R2401                4
    X2403     R2475               -5   R2646               -4
    X2404     COST               -28   R2572                1
    X2404     R2552                5   R2562                1
    X2404     R2486               -1   R2665               -8
    X2405     COST                50   R2595               -4
    X2405     R2445               -3   R2545                6
    X2405     R2447                6   R2669                5
    X2406     COST                -3   R2434               -3
    X2406     R2541               -3   R2539               -3
    X2406     R2441               -8   R2707                7
    X2407     COST                70   R2508                9
    X2407     R2581                9   R2521               -1
    X2407     R2515                1   R2717               -5
    X2408     COST                72   R2476                4
    X2408     R2461               -8   R2555                2
    X2408     R2479                3   R2656                8
    X2409     COST                74   R2444                2
    X2409     R2451               -7   R2551               -9
    X2409     R2415               -9   R2786                8
    X2410     COST               -78   R2451               -5
    X2410     R2468                8   R2453               -9
    X2410     R2520               -5   R2750                1
    X2411     COST               -64   R2439               -6
    X2411     R2528                2   R2576                1
    X2411     R2505               -8   R2627                8
    X2412     COST               -27   R2464               -5
    X2412     R2470               -3   R2453               -2
    X2412     R2495               -4   R2714                6
    X2413     COST                16   R2402                8
    X2413     R2532                7   R2597               -5
    X2413     R2498                3   R2741                8
    X2414     COST               -17   R2409                4
    X2414     R2419               -9   R2465               -5
    X2414     R2492                4   R2695                2
    X2415     COST               -62   R2480               -8
    X2415     R2429               -6   R2453               -9
    X2415     R2570               -5   R2773                5
    X2416     COST                53   R2416                8
    X2416     R2554                9   R2542                6
    X2416     R2562               -9   R2691                7
    X2417     COST               -54   R2465               -3
    X2417     R2572               -5   R2543               -8
    X2417     R2404               -3   R2610               -1
    X2418     COST               -16   R2578                3
    X2418     R2542               -7   R2474               -9
    X2418     R2503                9   R2774                8
    X2419     COST                 4   R2411               -1
    X2419     R2415                8   R2475               -8
    X2419     R2597                2   R2686                5
    X2420     COST                72   R2431               -3
    X2420     R2427               -7   R2457                8
    X2420     R2544                2   R2617                7
    X2421     COST                26   R2530                9
    X2421     R2474                1   R2483                1
    X2421     R2432               -4   R2737                3
    X2422     COST                 3   R2589               -2
    X2422     R2494                9   R2436               -3
    X2422     R2429               -1   R2608                1
    X2423     COST               -72   R2518               -7
    X2423     R2436               -6   R2443               -7
    X2423     R2590               -4   R2652               -3
    X2424     COST               -87   R2554               -2
    X2424     R2522               -1   R2457               -5
    X2424     R2434               -7   R2646               -6
    X2425     COST                13   R2417               -1
    X2425     R2472               -3   R2436               -2
    X2425     R2402               -8   R2780                6
    X2426     COST                34   R2530                1
    X2426     R2538                4   R2509                3
    X2426     R2500                9   R2615                8
    X2427     COST                 4   R2439               -1
    X2427     R2418               -7   R2432               -7
    X2427     R2548                4   R2780                2
    X2428     COST               -48   R2490               -4
    X2428     R2409                2   R2580               -4
    X2428     R2478               -8   R2738                4
    X2429     COST               -27   R2531                1
    X2429     R2431                6   R2545               -3
    X2429     R2554                9   R2660               -1
    X2430     COST               -56   R2466                6
    X2430     R2536               -8   R2408                5
    X2430     R2599                4   R2740               -8
    X2431     COST                24   R2527                3
    X2431     R2414               -2   R2523               -9
    X2431     R2517                6   R2767               -6
    X2432     COST               -75   R2406               -6
    X2432     R2440               -3   R2571               -7
    X2432     R2595                5   R2757               -6
    X2433     R2526               -4   R2501                5
    X2433     R2424                2   R2535                5
    X2433     R2638               -3
    X2434     COST                98   R2462                9
    X2434     R2424                4   R2585                3
    X2434     R2579               -2   R2777                5
    X2435     COST                50   R2411                4
    X2435     R2485               -4   R2445                7
    X2435     R2467               -9   R2766                5
    X2436     COST                 3   R2534                4
    X2436     R2437               -1   R2595                4
    X2436     R2479                6   R2648                8
    X2437     COST               -17   R2429               -4
    X2437     R2597               -9   R2454               -5
    X2437     R2476                5   R2671               -3
    X2438     COST                -4   R2579                6
    X2438     R2564               -9   R2496               -1
    X2438     R2427               -4   R2687                2
    X2439     COST                38   R2458                5
    X2439     R2434               -7   R2438               -6
    X2439     R2506               -5   R2691                6
    X2440     R2487                1   R2528                7
    X2440     R2479                8   R2522                9
    X2440     R2703                5
    X2441     COST               -42   R2454                2
    X2441     R2408               -8   R2565                2
    X2441     R2452               -8   R2739                3
    X2442     R2534               -8   R2594               -4
    X2442     R2492                5   R2533               -2
    X2442     R2609                8
    X2443     COST                85   R2521                6
    X2443     R2554               -1   R2593               -3
    X2443     R2580                9   R2715                8
    X2444     COST               -78   R2567               -6
    X2444     R2537               -9   R2500                1
    X2444     R2466                4   R2648               -9
    X2445     COST               -58   R2404               -8
    X2445     R2575                8   R2439               -6
    X2445     R2519                3   R2752               -6
    X2446     COST               -14   R2463               -1
    X2446     R2505                1   R2536                4
    X2446     R2583               -6   R2795                5
    X2447     COST                25   R2414               -1
    X2447     R2424               -2   R2405                5
    X2447     R2479               -5   R2743                7
    X2448     COST               -53   R2494               -1
    X2448     R2547               -8   R2496               -5
    X2448     R2574               -8   R2604               -7
    X2449     COST                 2   R2486                5
    X2449     R2485                8   R2472               -1
    X2449     R2542                1   R2749                9
    X2450     COST              -103   R2489               -7
    X2450     R2467               -9   R2510               -3
    X2450     R2491                5   R2771                5
    X2451     COST                73   R2492                8
    X2451     R2587                3   R2501                5
    X2451     R2423                1   R2779                4
    X2452     COST               -47   R2436                3
    X2452     R2453               -4   R2446               -4
    X2452     R2471               -3   R2784                8
    X2453     COST               -21   R2424               -6
    X2453     R2511               -3   R2413               -7
    X2453     R2457               -3   R2751                6
    X2454     COST                15   R2593               -4
    X2454     R2578               -1   R2427               -2
    X2454     R2410                8   R2768                2
    X2455     R2441                4   R2553                7
    X2455     R2450                8   R2578                9
    X2455     R2743                7
    X2456     COST                93   R2484                5
    X2456     R2433               -1   R2593                5
    X2456     R2587                5   R2797               -4
    X2457     COST                27   R2460                9
    X2457     R2493                1   R2438                1
    X2457     R2567                5   R2677               -3
    X2458     COST               -32   R2572               -2
    X2458     R2580                1   R2477               -9
    X2458     R2493                8   R2613                2
    X2459     COST                 4   R2522                5
    X2459     R2414               -1   R2439                1
    X2459     R2474                3   R2698                7
    X2460     COST                32   R2486               -4
    X2460     R2427                1   R2566                4
    X2460     R2448                9   R2725                4
    X2461     COST               -36   R2578                3
    X2461     R2575                9   R2468               -8
    X2461     R2451                8   R2799               -9
    X2462     COST                -1   R2595                2
    X2462     R2584               -7   R2552                8
    X2462     R2530               -1   R2638                2
    X2463     COST               -58   R2420                2
    X2463     R2569               -4   R2490               -4
    X2463     R2432                3   R2788               -8
    X2464     COST                19   R2507                1
    X2464     R2593               -3   R2476                3
    X2464     R2491                2   R2688                5
    X2465     COST                20   R2529               -3
    X2465     R2564                9   R2470               -5
    X2465     R2582                5   R2609               -8
    X2466     COST                -4   R2549                1
    X2466     R2455                6   R2520               -4
    X2466     R2492               -9   R2793               -1
    X2467     COST                80   R2556                9
    X2467     R2528                6   R2508                1
    X2467     R2507               -9   R2785                2
    X2468     COST                10   R2593                5
    X2468     R2479               -7   R2549                9
    X2468     R2417                1   R2652               -3
    X2469     COST                73   R2455               -5
    X2469     R2440                8   R2464                2
    X2469     R2441                4   R2641                7
    X2470     COST                18   R2532               -4
    X2470     R2593                3   R2463                3
    X2470     R2421                1   R2759               -7
    X2471     COST                55   R2429               -8
    X2471     R2581                9   R2591                1
    X2471     R2575               -3   R2617               -6
    X2472     COST               -98   R2444               -4
    X2472     R2471                8   R2428               -8
    X2472     R2431               -7   R2647                2
    X2473     COST                62   R2492               -8
    X2473     R2400                7   R2443               -3
    X2473     R2494                4   R2735                1
    X2474     COST                31   R2563                6
    X2474     R2430                6   R2419                7
    X2474     R2509                7   R2641               -1
    X2475     COST               -22   R2507               -7
    X2475     R2425               -4   R2581               -2
    X2475     R2577               -2   R2653                9
    X2476     R2554                4   R2575                3
    X2476     R2579               -2   R2419               -5
    X2476     R2669                1
    X2477     COST                20   R2457               -1
    X2477     R2522                5   R2435                7
    X2477     R2544                1   R2638                2
    X2478     COST               -15   R2486               -1
    X2478     R2593               -8   R2511                2
    X2478     R2443               -5   R2667               -7
    X2479     COST                37   R2532                9
    X2479     R2547               -3   R2457                5
    X2479     R2436               -2   R2736                4
    X2480     COST               -16   R2534               -1
    X2480     R2440               -1   R2426                5
    X2480     R2460               -9   R2726               -1
    X2481     COST                 2   R2420               -1
    X2481     R2446                2   R2517               -8
    X2481     R2461               -8   R2631               -1
    X2482     COST                44   R2581                5
    X2482     R2569                1   R2520                2
    X2482     R2458               -6   R2709                4
    X2483     COST                15   R2527                4
    X2483     R2436                4   R2508               -4
    X2483     R2582               -3   R2634               -3
    X2484     COST                25   R2525                2
    X2484     R2504                5   R2512                3
    X2484     R2416               -3   R2645                3
    X2485     COST                45   R2511                5
    X2485     R2416               -1   R2544               -4
    X2485     R2522                4   R2674               -9
    X2486     COST               -14   R2535                8
    X2486     R2582                1   R2420               -3
    X2486     R2431                4   R2677               -8
    X2487     COST                 8   R2522                5
    X2487     R2525                4   R2472                8
    X2487     R2508               -5   R2653                4
    X2488     COST               -29   R2561               -1
    X2488     R2559                1   R2418                9
    X2488     R2455                8   R2799               -9
    X2489     COST                24   R2590                5
    X2489     R2591                2   R2549                8
    X2489     R2460               -7   R2708               -6
    X2490     COST                65   R2569                6
    X2490     R2519               -1   R2401               -7
    X2490     R2526                9   R2680                3
    X2491     COST                58   R2522                8
    X2491     R2406                9   R2463                6
    X2491     R2558               -6   R2732               -5
    X2492     COST                26   R2404               -2
    X2492     R2525               -9   R2569                4
    X2492     R2539                6   R2706               -7
    X2493     COST                22   R2453                2
    X2493     R2516                4   R2470                5
    X2493     R2454                4   R2644               -5
    X2494     COST                61   R2545                7
    X2494     R2591               -1   R2456               -2
    X2494     R2593               -7   R2741                6
    X2495     COST                 1   R2500               -9
    X2495     R2504                1   R2463                7
    X2495     R2490                6   R2684               -7
    X2496     COST                43   R2457                7
    X2496     R2440               -5   R2536               -5
    X2496     R2474               -8   R2673               -1
    X2497     COST                26   R2563               -5
    X2497     R2546                9   R2407               -1
    X2497     R2425                8   R2776                5
    X2498     COST                25   R2525                4
    X2498     R2415                2   R2496                6
    X2498     R2544                9   R2748                1
    X2499     COST                41   R2420                7
    X2499     R2405               -4   R2582                4
    X2499     R2552               -1   R2640                5
    X2500     COST                23   R2519                3
    X2500     R2548                5   R2530                7
    X2500     R2544                8   R2654               -4
    X2501     COST               128   R2592                3
    X2501     R2551               -3   R2569                4
    X2501     R2406                8   R2751                4
    X2502     COST                31   R2596                4
    X2502     R2471               -8   R2554               -5
    X2502     R2522               -4   R2772                5
    X2503     COST              -115   R2453               -9
    X2503     R2483               -3   R2581               -4
    X2503     R2561               -7   R2669                3
    X2504     COST                 7   R2529                6
    X2504     R2431               -4   R2503               -9
    X2504     R2588                7   R2657               -2
    X2505     COST               -19   R2494                4
    X2505     R2501                7   R2449               -3
    X2505     R2538               -4   R2667                9
    X2506     COST               -72   R2563               -6
    X2506     R2550               -4   R2409               -8
    X2506     R2452                2   R2680                4
    X2507     COST               -73   R2458               -7
    X2507     R2505               -6   R2561               -8
    X2507     R2407               -3   R2773               -5
    X2508     COST                18   R2449               -4
    X2508     R2557                3   R2595                6
    X2508     R2405                4   R2786                3
    X2509     COST              -113   R2487                4
    X2509     R2536               -6   R2405               -9
    X2509     R2537               -7   R2649                3
    X2510     COST                84   R2583               -2
    X2510     R2537                2   R2489                9
    X2510     R2421               -8   R2735               -8
    X2511     COST                91   R2583                5
    X2511     R2503                7   R2464                8
    X2511     R2591                7   R2667               -3
    X2512     COST               -18   R2440               -6
    X2512     R2578               -1   R2417               -5
    X2512     R2560                5   R2735               -2
    X2513     COST                 9   R2547                7
    X2513     R2533                4   R2449               -1
    X2513     R2525                5   R2669               -6
    X2514     COST                -4   R2481               -6
    X2514     R2408               -2   R2553               -2
    X2514     R2485               -5   R2752               -7
    X2515     COST                16   R2544               -9
    X2515     R2440                2   R2447                3
    X2515     R2506                9   R2623               -7
    X2516     COST                24   R2485                6
    X2516     R2546                6   R2450                3
    X2516     R2434                1   R2627                5
    X2517     COST                20   R2461               -4
    X2517     R2435                7   R2538                3
    X2517     R2488               -8   R2621                3
    X2518     COST               -13   R2408                8
    X2518     R2590               -2   R2430               -3
    X2518     R2433                2   R2770                9
    X2519     COST                57   R2581                9
    X2519     R2541                3   R2558               -1
    X2519     R2474               -4   R2710               -7
    X2520     COST               -51   R2584                4
    X2520     R2404               -3   R2590               -5
    X2520     R2527                8   R2632               -8
    X2521     COST               -78   R2547               -5
    X2521     R2406               -5   R2457               -1
    X2521     R2598               -3   R2638                5
    X2522     COST                48   R2503               -3
    X2522     R2411                9   R2531               -6
    X2522     R2458                6   R2757                4
    X2523     COST               -81   R2487                4
    X2523     R2403                3   R2490                2
    X2523     R2465               -9   R2642                8
    X2524     COST               -52   R2412               -8
    X2524     R2582               -9   R2470                4
    X2524     R2431                5   R2623               -8
    X2525     COST               -59   R2526               -2
    X2525     R2491               -5   R2462               -5
    X2525     R2477               -6   R2644                3
    X2526     COST               -24   R2448                4
    X2526     R2463               -9   R2450               -4
    X2526     R2507               -6   R2720                6
    X2527     COST               126   R2494               -3
    X2527     R2561               -8   R2526               -5
    X2527     R2537                9   R2625                5
    X2528     COST               -56   R2515                4
    X2528     R2477               -7   R2596               -6
    X2528     R2433                1   R2752                9
    X2529     COST               -43   R2550               -7
    X2529     R2434                1   R2488               -4
    X2529     R2552                7   R2699               -3
    X2530     COST                59   R2573                1
    X2530     R2466                1   R2584                2
    X2530     R2507               -2   R2751                9
    X2531     R2405               -9   R2552                4
    X2531     R2484                2   R2485                3
    X2531     R2632                4
    X2532     COST                -2   R2423               -6
    X2532     R2436                4   R2527               -3
    X2532     R2594               -4   R2751                6
    X2533     R2520                1   R2498               -5
    X2533     R2474               -5   R2549                2
    X2533     R2611                1
    X2534     COST                -1   R2570               -8
    X2534     R2559               -6   R2416                7
    X2534     R2445                7   R2694               -4
    X2535     COST                -5   R2460                9
    X2535     R2546                4   R2417               -3
    X2535     R2484               -6   R2609                3
    X2536     COST              -112   R2436               -3
    X2536     R2438                2   R2505               -7
    X2536     R2457               -5   R2680               -1
    X2537     COST               -17   R2494               -4
    X2537     R2530               -9   R2508               -3
    X2537     R2461                9   R2640                4
    X2538     COST               -57   R2571                8
    X2538     R2548                4   R2528               -8
    X2538     R2512               -9   R2755                9
    X2539     COST                37   R2472                3
    X2539     R2526                6   R2511                4
    X2539     R2416                2   R2636               -7
    X2540     COST                72   R2457               -3
    X2540     R2406                9   R2445                4
    X2540     R2519               -5   R2759               -5
    X2541     COST                26   R2469                5
    X2541     R2561               -5   R2496               -4
    X2541     R2410                9   R2615               -5
    X2542     COST                47   R2420                8
    X2542     R2534               -9   R2586                8
    X2542     R2547               -9   R2660                4
    X2543     COST               -54   R2539               -1
    X2543     R2573               -7   R2560                2
    X2543     R2491                8   R2792                6
    X2544     COST               -91   R2446               -9
    X2544     R2449               -8   R2503               -5
    X2544     R2411                9   R2724               -1
    X2545     COST                69   R2448                5
    X2545     R2550                8   R2455               -1
    X2545     R2459               -1   R2603               -2
    X2546     COST                21   R2410                5
    X2546     R2509                6   R2540                4
    X2546     R2519                2   R2797                4
    X2547     COST               -20   R2481               -6
    X2547     R2519               -4   R2471                1
    X2547     R2522               -9   R2767                7
    X2548     R2408               -6   R2479               -5
    X2548     R2438                5   R2509                8
    X2548     R2756               -4
    X2549     COST                24   R2440               -7
    X2549     R2530               -7   R2499                8
    X2549     R2534                7   R2646                7
    X2550     COST                38   R2444                1
    X2550     R2590               -1   R2599                6
    X2550     R2469                4   R2769                7
    X2551     COST                -8   R2548                2
    X2551     R2567               -2   R2549                7
    X2551     R2416               -6   R2777               -6
    X2552     COST                84   R2459               -8
    X2552     R2405                7   R2493                1
    X2552     R2434               -7   R2711                8
    X2553     COST                68   R2544               -5
    X2553     R2471                4   R2546                8
    X2553     R2487                3   R2697                9
    X2554     COST               -38   R2492                5
    X2554     R2516                7   R2465               -6
    X2554     R2569                1   R2719                5
    X2555     COST                -7   R2426               -5
    X2555     R2484                2   R2415                1
    X2555     R2536               -8   R2728               -5
    X2556     COST               -12   R2580               -7
    X2556     R2482               -7   R2599                3
    X2556     R2504               -7   R2730                2
    X2557     COST               -19   R2460               -5
    X2557     R2499               -9   R2413               -1
    X2557     R2495               -2   R2770               -6
    X2558     COST               -10   R2469               -1
    X2558     R2406               -1   R2503               -5
    X2558     R2401                1   R2730               -7
    X2559     COST                46   R2461               -3
    X2559     R2538               -7   R2548               -9
    X2559     R2499                5   R2691                8
    X2560     COST                33   R2592               -4
    X2560     R2533                3   R2565                7
    X2560     R2574               -2   R2652                6
    X2561     COST                48   R2585                4
    X2561     R2431               -2   R2478                4
    X2561     R2535               -9   R2663                9
    X2562     COST               -37   R2403                4
    X2562     R2454                3   R2559               -8
    X2562     R2518                6   R2764               -3
    X2563     COST                23   R2485               -3
    X2563     R2514               -4   R2565                3
    X2563     R2443                3   R2765               -1
    X2564     COST               -11   R2562                7
    X2564     R2587               -8   R2563                1
    X2564     R2538                9   R2661                3
    X2565     COST              -100   R2560               -1
    X2565     R2586               -8   R2423               -2
    X2565     R2563               -7   R2632               -7
    X2566     COST               -14   R2464               -3
    X2566     R2447                1   R2460                2
    X2566     R2510               -1   R2649               -3
    X2567     COST                -2   R2459               -1
    X2567     R2598               -2   R2526               -2
    X2567     R2432                5   R2620                1
    X2568     R2401                2   R2455               -5
    X2568     R2437                3   R2414               -4
    X2568     R2644               -4
    X2569     COST               116   R2524                9
    X2569     R2419               -8   R2465                2
    X2569     R2457                4   R2643                1
    X2570     COST                12   R2581                1
    X2570     R2458                4   R2415               -8
    X2570     R2403               -1   R2746                8
    X2571     COST                16   R2451               -7
    X2571     R2427               -4   R2593                8
    X2571     R2408               -5   R2717                5
    X2572     COST                -4   R2476               -8
    X2572     R2513               -8   R2470                6
    X2572     R2496                5   R2633               -8
    X2573     COST                18   R2532                3
    X2573     R2469               -4   R2425               -5
    X2573     R2591                6   R2631                7
    X2574     COST                 9   R2504                5
    X2574     R2412               -7   R2517               -3
    X2574     R2539                9   R2744               -4
    X2575     COST               -16   R2546                2
    X2575     R2476               -9   R2597               -6
    X2575     R2422               -3   R2785                7
    X2576     COST               -32   R2459               -3
    X2576     R2437               -3   R2441               -4
    X2576     R2460               -9   R2605                1
    X2577     COST               -53   R2557               -5
    X2577     R2569                3   R2497                1
    X2577     R2465               -4   R2646               -4
    X2578     COST               100   R2412               -8
    X2578     R2500                2   R2472                7
    X2578     R2545                9   R2642                3
    X2579     COST               -21   R2548               -8
    X2579     R2579               -1   R2438               -8
    X2579     R2494               -4   R2747               -7
    X2580     COST                66   R2559                7
    X2580     R2540                8   R2517               -2
    X2580     R2599                8   R2676               -6
    X2581     COST               -76   R2501                8
    X2581     R2587               -8   R2483               -3
    X2581     R2452               -1   R2706                8
    X2582     COST               122   R2548               -1
    X2582     R2534               -3   R2428                7
    X2582     R2581                3   R2768                8
    X2583     COST                21   R2480                1
    X2583     R2446                3   R2531                6
    X2583     R2412               -7   R2698                2
    X2584     COST               -97   R2544                5
    X2584     R2504                8   R2505               -2
    X2584     R2444               -9   R2609               -3
    X2585     COST                48   R2513                6
    X2585     R2597                5   R2578                1
    X2585     R2504                4   R2740                5
    X2586     R2544               -6   R2566               -6
    X2586     R2407               -9   R2595                8
    X2586     R2649                6
    X2587     COST               -13   R2505                5
    X2587     R2469               -5   R2513               -5
    X2587     R2488               -4   R2603                7
    X2588     COST                12   R2408                8
    X2588     R2571               -6   R2480               -9
    X2588     R2547                3   R2708               -9
    X2589     COST                33   R2468                5
    X2589     R2492               -3   R2406                7
    X2589     R2498                5   R2754               -5
    X2590     COST               -16   R2554               -3
    X2590     R2414               -6   R2524               -3
    X2590     R2518                5   R2619                2
    X2591     R2579                9   R2588               -9
    X2591     R2576               -7   R2403               -8
    X2591     R2798               -7
    X2592     COST                 4   R2450               -9
    X2592     R2415               -7   R2409                1
    X2592     R2490               -4   R2738               -9
    X2593     COST                50   R2556                1
    X2593     R2539               -6   R2490               -3
    X2593     R2504                4   R2631                8
    X2594     COST                29   R2466               -2
    X2594     R2542               -1   R2488                8
    X2594     R2448                3   R2654                1
    X2595     COST               -29   R2525                2
    X2595     R2587               -7   R2443                9
    X2595     R2471                1   R2684               -1
    X2596     COST               -71   R2401                5
    X2596     R2480               -8   R2422               -1
    X2596     R2457               -7   R2699               -7
    X2597     COST               -15   R2464               -1
    X2597     R2483                8   R2412               -3
    X2597     R2440               -8   R2717                5
    X2598     COST               -14   R2572                4
    X2598     R2512               -1   R2459               -5
    X2598     R2523                6   R2615               -5
    X2599     COST               -26   R2421               -2
    X2599     R2487               -2   R2558               -6
    X2599     R2593                3   R2787                6
    X2600     COST               -15   R2750               -6
    X2600     R2668               -5   R2790               -6
    X2600     R2635               -3   R2869               -8
    X2601     COST                63   R2771               -9
    X2601     R2781                9   R2614                3
    X2601     R2649                5   R2912               -6
    X2602     COST                16   R2617               -6
    X2602     R2705               -9   R2780                7
    X2602     R2623               -8   R2895                5
    X2603     COST                62   R2686                2
    X2603     R2663               -4   R2634                9
    X2603     R2657                3   R2931               -5
    X2604     COST               -41   R2629               -8
    X2604     R2600                7   R2790                8
    X2604     R2772               -2   R2841                3
    X2605     COST                -5   R2773               -5
    X2605     R2672                5   R2675                4
    X2605     R2764                6   R2947               -4
    X2606     COST               -20   R2658               -8
    X2606     R2745                6   R2659               -9
    X2606     R2681               -6   R2971               -1
    X2607     COST                18   R2656                2
    X2607     R2784                3   R2618               -1
    X2607     R2611               -9   R2891                4
    X2608     COST                -8   R2692                6
    X2608     R2702               -1   R2642               -6
    X2608     R2760               -2   R2815                4
    X2609     COST                42   R2669                7
    X2609     R2772                8   R2713               -7
    X2609     R2637               -3   R2996                7
    X2610     COST                40   R2737                7
    X2610     R2708                6   R2693                8
    X2610     R2647               -9   R2845                1
    X2611     COST               -69   R2737               -2
    X2611     R2691               -9   R2734                9
    X2611     R2649               -6   R2842               -3
    X2612     COST                47   R2667               -9
    X2612     R2728               -7   R2701               -7
    X2612     R2645               -6   R2958                5
    X2613     COST                -3   R2687               -3
    X2613     R2713                2   R2657               -9
    X2613     R2732               -1   R2947                3
    X2614     COST               -60   R2611               -9
    X2614     R2630               -6   R2747               -9
    X2614     R2782                1   R2907               -6
    X2615     COST               -61   R2607               -6
    X2615     R2665               -6   R2632               -7
    X2615     R2704                4   R2965               -7
    X2616     COST               -54   R2712                3
    X2616     R2758                4   R2716               -2
    X2616     R2791                9   R2927               -9
    X2617     COST               -74   R2723               -5
    X2617     R2711               -8   R2714               -2
    X2617     R2724               -3   R2986                3
    X2618     COST                 2   R2752                1
    X2618     R2702                8   R2712                6
    X2618     R2660               -4   R2857                2
    X2619     COST                17   R2678                7
    X2619     R2600               -7   R2700                1
    X2619     R2643               -4   R2963               -1
    X2620     COST               -96   R2710                3
    X2620     R2789               -1   R2683               -9
    X2620     R2626               -2   R2922               -6
    X2621     COST                 4   R2618                7
    X2621     R2796               -3   R2711                3
    X2621     R2780               -5   R2968               -7
    X2622     COST               -20   R2683               -9
    X2622     R2669                8   R2661                7
    X2622     R2637                7   R2917               -3
    X2623     COST               -15   R2615               -3
    X2623     R2651               -1   R2684               -7
    X2623     R2639                3   R2903               -5
    X2624     COST               -50   R2715               -8
    X2624     R2722               -1   R2656                2
    X2624     R2783               -7   R2800                5
    X2625     COST                40   R2629                5
    X2625     R2768               -6   R2616                7
    X2625     R2789               -1   R2997                7
    X2626     COST                12   R2662                8
    X2626     R2686               -4   R2652                9
    X2626     R2692               -3   R2977                8
    X2627     COST                 4   R2690                6
    X2627     R2743               -3   R2775               -6
    X2627     R2700               -1   R2934               -5
    X2628     COST                 3   R2700                4
    X2628     R2708                6   R2608                1
    X2628     R2727                4   R2985               -6
    X2629     COST                52   R2711               -4
    X2629     R2656                7   R2661                9
    X2629     R2630               -9   R2972                3
    X2630     COST                -9   R2748               -2
    X2630     R2762               -7   R2675               -4
    X2630     R2757                3   R2854               -9
    X2631     COST               -35   R2678                2
    X2631     R2766               -5   R2741                5
    X2631     R2659               -8   R2824               -3
    X2632     COST                46   R2729               -3
    X2632     R2677                5   R2608               -8
    X2632     R2775                8   R2804                8
    X2633     COST              -107   R2671               -7
    X2633     R2621               -7   R2644                9
    X2633     R2726               -8   R2864               -6
    X2634     COST                -9   R2679                2
    X2634     R2697                2   R2692               -7
    X2634     R2662                1   R2872               -6
    X2635     COST               -34   R2693                1
    X2635     R2669                9   R2659               -6
    X2635     R2723               -9   R2935               -5
    X2636     COST                13   R2688               -3
    X2636     R2674               -1   R2621                6
    X2636     R2723                7   R2904                4
    X2637     COST               -24   R2796               -4
    X2637     R2745               -9   R2753                2
    X2637     R2736               -6   R2959               -8
    X2638     COST                59   R2602                4
    X2638     R2656                5   R2626                6
    X2638     R2741                7   R2993               -1
    X2639     COST               -25   R2689               -4
    X2639     R2710                3   R2635                5
    X2639     R2616               -7   R2965                4
    X2640     COST              -150   R2737               -9
    X2640     R2751               -9   R2714               -7
    X2640     R2735               -9   R2931               -8
    X2641     COST               -66   R2633                9
    X2641     R2757               -7   R2694               -9
    X2641     R2787               -5   R2816                7
    X2642     COST                12   R2630                4
    X2642     R2766               -3   R2702               -9
    X2642     R2727               -8   R2880                8
    X2643     COST                31   R2649                7
    X2643     R2682                7   R2602               -2
    X2643     R2673               -7   R2920               -8
    X2644     COST                 6   R2708                9
    X2644     R2735               -3   R2631                1
    X2644     R2649               -7   R2961                9
    X2645     COST                 7   R2721                7
    X2645     R2784                1   R2690               -4
    X2645     R2635               -4   R2978                1
    X2646     COST                11   R2619                6
    X2646     R2644                7   R2744                8
    X2646     R2736               -6   R2971               -5
    X2647     COST                17   R2732                8
    X2647     R2755               -1   R2604               -7
    X2647     R2750                6   R2995                7
    X2648     COST                -6   R2791                3
    X2648     R2727                6   R2688               -9
    X2648     R2732                6   R2939                6
    X2649     COST               -37   R2633               -9
    X2649     R2701                4   R2683               -9
    X2649     R2761               -1   R2841                8
    X2650     COST               -30   R2607                7
    X2650     R2691               -6   R2720               -1
    X2650     R2605                9   R2921                2
    X2651     COST               -62   R2610                4
    X2651     R2747               -8   R2632               -5
    X2651     R2795               -3   R2953               -9
    X2652     COST                -8   R2759                5
    X2652     R2795               -2   R2615               -6
    X2652     R2782                3   R2894                7
    X2653     COST               -46   R2746               -6
    X2653     R2722                2   R2768               -3
    X2653     R2681               -1   R2862               -6
    X2654     COST                 7   R2744               -7
    X2654     R2649               -1   R2711               -1
    X2654     R2662                8   R2859               -8
    X2655     COST               -31   R2677                7
    X2655     R2727                5   R2796                7
    X2655     R2640                4   R2907               -8
    X2656     COST                 4   R2690                8
    X2656     R2707                9   R2700                5
    X2656     R2717                6   R2961               -6
    X2657     COST               -40   R2728                3
    X2657     R2602                3   R2729                5
    X2657     R2714               -3   R2926               -7
    X2658     COST                 1   R2635               -9
    X2658     R2739                5   R2671               -1
    X2658     R2770                7   R2861               -4
    X2659     COST                 8   R2712               -6
    X2659     R2777               -6   R2762               -4
    X2659     R2730               -2   R2903                5
    X2660     COST               -42   R2792                6
    X2660     R2694               -4   R2629               -9
    X2660     R2691                5   R2944               -8
    X2661     COST                40   R2716                5
    X2661     R2724               -9   R2720               -1
    X2661     R2731               -1   R2850                5
    X2662     COST               -81   R2779               -8
    X2662     R2720               -1   R2726               -1
    X2662     R2716               -6   R2976               -4
    X2663     COST                11   R2611                8
    X2663     R2692               -2   R2758               -8
    X2663     R2709                7   R2923                1
    X2664     COST                21   R2627               -2
    X2664     R2663                5   R2732                7
    X2664     R2797               -4   R2858                4
    X2665     COST               -45   R2673                5
    X2665     R2761               -5   R2609                5
    X2665     R2652               -6   R2968               -3
    X2666     COST               -13   R2705                5
    X2666     R2792                4   R2634               -3
    X2666     R2750                3   R2857                8
    X2667     COST               -47   R2661               -8
    X2667     R2789                1   R2614               -2
    X2667     R2755                2   R2947                1
    X2668     COST                78   R2688               -2
    X2668     R2638               -3   R2619                7
    X2668     R2608               -5   R2889                9
    X2669     COST               -54   R2732               -8
    X2669     R2766                1   R2646               -6
    X2669     R2796                8   R2823               -5
    X2670     COST                32   R2681                8
    X2670     R2675               -2   R2724               -5
    X2670     R2646                1   R2989               -6
    X2671     COST                29   R2751                7
    X2671     R2630                6   R2690                7
    X2671     R2791                5   R2956               -8
    X2672     COST                17   R2728               -1
    X2672     R2785               -6   R2729                6
    X2672     R2765                5   R2923               -3
    X2673     COST                24   R2628               -4
    X2673     R2772                5   R2798               -8
    X2673     R2630                4   R2870                8
    X2674     COST               -23   R2685               -3
    X2674     R2733               -3   R2776               -2
    X2674     R2654                9   R2994                3
    X2675     COST               -23   R2711               -8
    X2675     R2619               -3   R2696                5
    X2675     R2771                2   R2954               -8
    X2676     COST                31   R2677                8
    X2676     R2716                9   R2758               -5
    X2676     R2700                1   R2804                4
    X2677     COST               -67   R2627               -8
    X2677     R2773               -7   R2668               -8
    X2677     R2724                8   R2894                3
    X2678     COST                 6   R2743               -8
    X2678     R2777               -1   R2738               -3
    X2678     R2651                8   R2947                9
    X2679     COST                57   R2602                2
    X2679     R2681                3   R2711               -3
    X2679     R2608                3   R2943                9
    X2680     COST               -21   R2615                3
    X2680     R2684               -6   R2609                7
    X2680     R2658                2   R2978               -3
    X2681     COST                 4   R2603                4
    X2681     R2770                4   R2674               -3
    X2681     R2683                1   R2956               -2
    X2682     COST                -7   R2611                9
    X2682     R2736               -6   R2638               -3
    X2682     R2659               -7   R2859               -3
    X2683     COST                16   R2750               -4
    X2683     R2671                7   R2779               -3
    X2683     R2714                1   R2883               -6
    X2684     COST                16   R2646                1
    X2684     R2603               -3   R2753                8
    X2684     R2676                7   R2915                3
    X2685     COST                -5   R2674               -2
    X2685     R2621               -2   R2749                1
    X2685     R2769               -3   R2878                3
    X2686     COST               -10   R2637                3
    X2686     R2746                4   R2694               -3
    X2686     R2657               -4   R2810                7
    X2687     COST                 5   R2760                4
    X2687     R2768                7   R2671                5
    X2687     R2726               -9   R2808               -2
    X2688     COST                -3   R2691               -1
    X2688     R2673               -2   R2796                1
    X2688     R2744               -3   R2986                3
    X2689     COST               -35   R2639               -8
    X2689     R2705               -1   R2708                2
    X2689     R2696               -9   R2916                4
    X2690     COST                 1   R2766               -1
    X2690     R2612                1   R2724                4
    X2690     R2698                8   R2961               -7
    X2691     COST                54   R2694                9
    X2691     R2665                1   R2780               -1
    X2691     R2768               -7   R2916                5
    X2692     COST                21   R2696                3
    X2692     R2724               -1   R2608                2
    X2692     R2708                3   R2892                8
    X2693     COST                26   R2661                7
    X2693     R2607               -8   R2605               -6
    X2693     R2697               -7   R2954               -2
    X2694     COST               -62   R2763               -6
    X2694     R2619                2   R2701                6
    X2694     R2723               -4   R2974               -8
    X2695     COST               -67   R2708                8
    X2695     R2691               -2   R2754               -9
    X2695     R2684                7   R2815               -7
    X2696     COST                76   R2715                9
    X2696     R2619               -5   R2744                1
    X2696     R2721               -8   R2949                7
    X2697     COST                23   R2678               -3
    X2697     R2784               -2   R2643                6
    X2697     R2706               -8   R2972               -1
    X2698     COST                35   R2628                5
    X2698     R2789               -7   R2797               -2
    X2698     R2681                9   R2897                2
    X2699     COST                 7   R2796               -6
    X2699     R2776                6   R2734               -2
    X2699     R2737                1   R2824               -3
    X2700     COST                42   R2740                7
    X2700     R2673                6   R2745               -1
    X2700     R2701                1   R2868               -1
    X2701     COST                 6   R2627               -4
    X2701     R2614                1   R2778                2
    X2701     R2618                7   R2859                4
    X2702     COST                39   R2696                2
    X2702     R2751                1   R2685                4
    X2702     R2660                8   R2858                2
    X2703     COST              -138   R2789                5
    X2703     R2763                5   R2678               -7
    X2703     R2799               -5   R2855               -8
    X2704     COST               -60   R2607               -1
    X2704     R2643               -4   R2665               -7
    X2704     R2767               -9   R2994                1
    X2705     COST               -68   R2656               -9
    X2705     R2685                9   R2793               -8
    X2705     R2743               -6   R2912                2
    X2706     COST                65   R2636               -2
    X2706     R2686                2   R2657               -8
    X2706     R2769                4   R2992                8
    X2707     COST               -69   R2785                9
    X2707     R2754                4   R2688               -7
    X2707     R2760               -8   R2808                2
    X2708     R2763               -5   R2706               -4
    X2708     R2784                8   R2707                9
    X2708     R2975               -3
    X2709     COST                10   R2775                2
    X2709     R2711                5   R2608               -6
    X2709     R2632               -5   R2947               -1
    X2710     COST               -54   R2686               -3
    X2710     R2649                2   R2685               -9
    X2710     R2705               -9   R2831               -1
    X2711     COST               -22   R2712               -2
    X2711     R2792               -3   R2782               -5
    X2711     R2636                7   R2851               -5
    X2712     COST                14   R2672                4
    X2712     R2718               -3   R2787               -7
    X2712     R2773                1   R2846                4
    X2713     COST                19   R2771                5
    X2713     R2770                4   R2698                5
    X2713     R2673                2   R2892               -4
    X2714     COST                27   R2720                8
    X2714     R2610               -6   R2786                9
    X2714     R2636                7   R2980                9
    X2715     COST                13   R2639                4
    X2715     R2761                5   R2685               -7
    X2715     R2741               -1   R2801                1
    X2716     COST               -36   R2763               -7
    X2716     R2703                5   R2632               -9
    X2716     R2697                8   R2995               -7
    X2717     COST               -42   R2694               -3
    X2717     R2749               -2   R2630               -1
    X2717     R2634               -3   R2960               -1
    X2718     COST                 6   R2627               -6
    X2718     R2607                7   R2654                8
    X2718     R2666                5   R2961                6
    X2719     COST                27   R2684                4
    X2719     R2661                3   R2782                8
    X2719     R2795                1   R2954               -2
    X2720     COST                -1   R2705                6
    X2720     R2739                6   R2722               -3
    X2720     R2638               -2   R2840                2
    X2721     COST                36   R2699                4
    X2721     R2701               -3   R2638                1
    X2721     R2739                8   R2863                4
    X2722     COST               -24   R2702                6
    X2722     R2660                2   R2667               -3
    X2722     R2689               -8   R2853                1
    X2723     COST               -21   R2675               -5
    X2723     R2757               -7   R2728               -5
    X2723     R2613               -1   R2913                1
    X2724     COST               -53   R2754               -8
    X2724     R2706               -1   R2695               -2
    X2724     R2698               -4   R2950                3
    X2725     COST               -20   R2603               -2
    X2725     R2652                4   R2645               -8
    X2725     R2701               -7   R2836               -5
    X2726     COST                49   R2723               -7
    X2726     R2628               -7   R2682                1
    X2726     R2627                1   R2943                5
    X2727     COST               -45   R2742               -4
    X2727     R2608               -2   R2733                9
    X2727     R2602               -7   R2820               -8
    X2728     COST               -42   R2675               -8
    X2728     R2794                3   R2770                4
    X2728     R2689                4   R2818               -6
    X2729     COST               -35   R2750               -7
    X2729     R2783               -9   R2740               -6
    X2729     R2669                1   R2963                2
    X2730     COST                 1   R2652               -1
    X2730     R2661                9   R2794               -3
    X2730     R2713               -1   R2958               -7
    X2731     COST                 1   R2681               -8
    X2731     R2710                1   R2729               -6
    X2731     R2793                9   R2944                8
    X2732     COST                25   R2623                8
    X2732     R2714                3   R2666                8
    X2732     R2651               -6   R2975                7
    X2733     COST                 8   R2725                5
    X2733     R2796               -3   R2617                8
    X2733     R2686                1   R2938               -1
    X2734     COST                18   R2690               -6
    X2734     R2704                2   R2782                7
    X2734     R2797                9   R2899               -9
    X2735     COST               -30   R2770                2
    X2735     R2673               -5   R2773               -6
    X2735     R2794                9   R2902                9
    X2736     COST                -4   R2682                5
    X2736     R2714                6   R2648                7
    X2736     R2656               -9   R2949               -1
    X2737     R2674               -4   R2672               -9
    X2737     R2706               -7   R2648               -8
    X2737     R2883               -3
    X2738     COST                22   R2734                8
    X2738     R2647               -4   R2754               -4
    X2738     R2740                7   R2829               -1
    X2739     COST               -29   R2712                1
    X2739     R2704                7   R2662               -4
    X2739     R2646               -9   R2862               -5
    X2740     COST                25   R2785               -9
    X2740     R2748               -3   R2715                3
    X2740     R2764               -4   R2964                9
    X2741     COST                 1   R2607               -2
    X2741     R2681               -1   R2787                7
    X2741     R2775                9   R2856                8
    X2742     COST                -9   R2791                5
    X2742     R2605                4   R2642               -9
    X2742     R2711               -4   R2905                6
    X2743     COST               -67   R2773                7
    X2743     R2760               -7   R2706               -2
    X2743     R2631               -9   R2813               -5
    X2744     COST                 1   R2686                2
    X2744     R2717                7   R2791                1
    X2744     R2789               -9   R2816               -7
    X2745     COST                50   R2757               -8
    X2745     R2719                3   R2623                7
    X2745     R2697                3   R2992                8
    X2746     COST               -32   R2768               -5
    X2746     R2638                6   R2777                5
    X2746     R2737               -3   R2843                8
    X2747     COST               -99   R2746               -7
    X2747     R2610               -5   R2650               -9
    X2747     R2661               -5   R2846                9
    X2748     COST               -12   R2626               -1
    X2748     R2690                1   R2726               -5
    X2748     R2793                7   R2951               -9
    X2749     COST                43   R2779                7
    X2749     R2668               -5   R2796                4
    X2749     R2736               -2   R2826               -6
    X2750     COST                -7   R2641               -7
    X2750     R2780                9   R2693                9
    X2750     R2632                3   R2801               -7
    X2751     COST               -14   R2664               -4
    X2751     R2694                6   R2773               -8
    X2751     R2687                4   R2947               -2
    X2752     COST               -61   R2716               -5
    X2752     R2740               -9   R2652               -9
    X2752     R2628                6   R2916               -1
    X2753     COST               -35   R2722                1
    X2753     R2682               -4   R2687               -3
    X2753     R2772                1   R2975                4
    X2754     COST                -4   R2636               -9
    X2754     R2677                7   R2628                6
    X2754     R2638               -4   R2901               -4
    X2755     COST               -70   R2681               -7
    X2755     R2604               -7   R2715               -7
    X2755     R2688                7   R2913                8
    X2756     COST                 6   R2686               -9
    X2756     R2778                3   R2670               -3
    X2756     R2717               -3   R2823                1
    X2757     COST               -73   R2683               -5
    X2757     R2614               -5   R2670               -1
    X2757     R2742               -5   R2888               -2
    X2758     COST               -19   R2642                2
    X2758     R2729                1   R2658                1
    X2758     R2786               -3   R2891               -7
    X2759     COST                63   R2715               -6
    X2759     R2781                5   R2703               -3
    X2759     R2675                7   R2818                7
    X2760     COST                 5   R2632                2
    X2760     R2720                5   R2611                8
    X2760     R2699                5   R2983               -7
    X2761     COST               101   R2629                2
    X2761     R2717                5   R2633               -2
    X2761     R2616                8   R2866                8
    X2762     COST                77   R2714                4
    X2762     R2692                6   R2726               -2
    X2762     R2764                6   R2908                7
    X2763     COST                -4   R2799                1
    X2763     R2631               -7   R2785                8
    X2763     R2771                2   R2863                3
    X2764     COST                45   R2790                8
    X2764     R2614               -3   R2777               -9
    X2764     R2762                9   R2837                7
    X2765     COST               -20   R2622                3
    X2765     R2718               -8   R2780               -4
    X2765     R2668               -1   R2856                7
    X2766     COST               -50   R2794                6
    X2766     R2704               -6   R2634                4
    X2766     R2637                4   R2801               -5
    X2767     COST                 2   R2605                2
    X2767     R2747                4   R2739                5
    X2767     R2681               -1   R2945               -5
    X2768     COST                -1   R2739               -6
    X2768     R2774               -2   R2786               -1
    X2768     R2717               -7   R2857                4
    X2769     COST                30   R2653               -3
    X2769     R2740                1   R2735                3
    X2769     R2630                4   R2909               -7
    X2770     COST               -36   R2782                8
    X2770     R2624               -9   R2684                6
    X2770     R2759                9   R2958                3
    X2771     COST                26   R2633                6
    X2771     R2798                7   R2624                5
    X2771     R2609               -3   R2857               -9
    X2772     COST               -30   R2690                9
    X2772     R2686               -7   R2740               -5
    X2772     R2628               -2   R2887               -6
    X2773     COST                 8   R2758               -9
    X2773     R2750                1   R2672               -4
    X2773     R2789               -5   R2853               -9
    X2774     COST                 3   R2651                3
    X2774     R2653                7   R2699               -1
    X2774     R2739               -2   R2847               -5
    X2775     COST               -35   R2656                3
    X2775     R2683               -8   R2720                4
    X2775     R2690               -9   R2884                1
    X2776     COST               -83   R2757               -7
    X2776     R2792                3   R2711               -9
    X2776     R2718               -2   R2846                3
    X2777     COST               -51   R2781               -8
    X2777     R2623                7   R2794               -8
    X2777     R2673                5   R2820                1
    X2778     COST               -13   R2662                4
    X2778     R2737               -7   R2613                4
    X2778     R2751                5   R2821                5
    X2779     COST                17   R2660               -9
    X2779     R2724               -9   R2623                6
    X2779     R2746               -4   R2847               -5
    X2780     COST                37   R2767               -6
    X2780     R2678                3   R2648                4
    X2780     R2673                6   R2920                4
    X2781     COST               103   R2652                3
    X2781     R2624                8   R2647                2
    X2781     R2603                5   R2801                9
    X2782     COST                36   R2603                3
    X2782     R2697                5   R2686                8
    X2782     R2628                1   R2995                4
    X2783     COST                 5   R2650                7
    X2783     R2734                2   R2683               -5
    X2783     R2708               -6   R2813                6
    X2784     COST               -54   R2754               -9
    X2784     R2620               -3   R2611               -9
    X2784     R2784                8   R2980               -6
    X2785     COST                53   R2752               -1
    X2785     R2724               -1   R2643                6
    X2785     R2622               -5   R2866                1
    X2786     COST               -46   R2603               -7
    X2786     R2707                4   R2761               -9
    X2786     R2778                9   R2894               -9
    X2787     COST               -24   R2632               -1
    X2787     R2729                8   R2658               -6
    X2787     R2779                2   R2935               -8
    X2788     COST                -8   R2718                5
    X2788     R2713               -3   R2640               -2
    X2788     R2705               -2   R2903               -2
    X2789     COST                11   R2635               -2
    X2789     R2746                2   R2788                1
    X2789     R2659               -8   R2967                3
    X2790     COST               -55   R2718               -8
    X2790     R2748               -1   R2786               -7
    X2790     R2664               -6   R2962                2
    X2791     COST                12   R2734               -1
    X2791     R2746                2   R2669               -7
    X2791     R2752               -7   R2871                9
    X2792     COST                29   R2732                8
    X2792     R2615               -9   R2612                7
    X2792     R2672                1   R2942                8
    X2793     COST                47   R2701                8
    X2793     R2688                9   R2647               -4
    X2793     R2767               -7   R2800                6
    X2794     COST                24   R2601                4
    X2794     R2702               -1   R2608               -3
    X2794     R2737                4   R2899                9
    X2795     COST                12   R2675                2
    X2795     R2732                3   R2653                7
    X2795     R2762               -4   R2875               -9
    X2796     COST                 6   R2779               -7
    X2796     R2723                6   R2656                9
    X2796     R2631               -8   R2900                6
    X2797     COST               -31   R2664               -1
    X2797     R2734               -6   R2760               -3
    X2797     R2759                8   R2994                9
    X2798     COST               -86   R2760               -7
    X2798     R2736               -7   R2613               -2
    X2798     R2632               -5   R2963                9
    X2799     COST                39   R2643                9
    X2799     R2770               -2   R2674               -3
    X2799     R2691               -3   R2984               -3
    X2800     COST               -24   R2934               -6
    X2800     R2823                8   R2988                8
    X2800     R2944                7   R2904               -8
    X2801     COST               -41   R2951               -2
    X2801     R2839                2   R2918               -6
    X2801     R2899                2   R2964                5
    X2802     COST                 1   R2913                7
    X2802     R2967               -1   R2800                5
    X2802     R2887                3   R2899                6
    X2803     COST                85   R2987                3
    X2803     R2964                7   R2826                3
    X2803     R2889                8   R2929                6
    X2804     COST                97   R2807                3
    X2804     R2904                9   R2809                2
    X2804     R2829               -6   R2887                7
    X2805     COST                21   R2822               -6
    X2805     R2839               -1   R2898                1
    X2805     R2871                6   R2888                5
    X2806     R2843                9   R2968                2
    X2806     R2856                3   R2912                7
    X2806     R2998               -6
    X2807     COST                48   R2891                2
    X2807     R2996                8   R2963               -6
    X2807     R2814               -5   R2924                3
    X2808     COST               -26   R2870                3
    X2808     R2911                9   R2845               -5
    X2808     R2880               -5   R2951                6
    X2809     COST                14   R2808               -2
    X2809     R2859               -2   R2801                4
    X2809     R2853                5   R2828               -9
    X2810     COST               -18   R2823                6
    X2810     R2955               -9   R2975                7
    X2810     R2940               -1   R2987                7
    X2811     COST                72   R2803               -1
    X2811     R2976               -6   R2951                4
    X2811     R2934                9   R2837                8
    X2812     COST                50   R2873                3
    X2812     R2819                7   R2818                1
    X2812     R2884               -4   R2834                9
    X2813     COST               109   R2889                4
    X2813     R2941                7   R2950                3
    X2813     R2807                3   R2805                8
    X2814     COST                93   R2884               -4
    X2814     R2943                6   R2934                3
    X2814     R2837                5   R2859                6
    X2815     COST                20   R2941                6
    X2815     R2863                4   R2856                4
    X2815     R2880                4   R2988               -5
    X2816     COST                -6   R2863                2
    X2816     R2822                7   R2900               -4
    X2816     R2957                1   R2950               -2
    X2817     COST                17   R2955               -7
    X2817     R2817               -1   R2858                9
    X2817     R2890                4   R2894               -9
    X2818     COST              -128   R2956               -9
    X2818     R2963                2   R2943               -7
    X2818     R2888                7   R2900               -3
    X2819     COST                26   R2957               -9
    X2819     R2916                3   R2886               -2
    X2819     R2801                1   R2902               -2
    X2820     COST                59   R2865                6
    X2820     R2808                8   R2999                9
    X2820     R2975                9   R2953               -5
    X2821     COST               -14   R2934                2
    X2821     R2846                3   R2997               -5
    X2821     R2954               -6   R2851               -3
    X2822     COST               -61   R2974               -1
    X2822     R2821                5   R2843               -4
    X2822     R2806               -9   R2904               -8
    X2823     COST                85   R2925                4
    X2823     R2961                2   R2975                8
    X2823     R2900               -1   R2850                9
    X2824     COST                19   R2839               -9
    X2824     R2822                7   R2940                2
    X2824     R2894                4   R2943                2
    X2825     COST                24   R2951               -7
    X2825     R2820                8   R2823               -4
    X2825     R2917               -5   R2928                2
    X2826     COST               -76   R2913                4
    X2826     R2832               -9   R2993                1
    X2826     R2931               -4   R2923               -8
    X2827     COST                83   R2813               -6
    X2827     R2902                7   R2908                7
    X2827     R2802                5   R2924               -8
    X2828     COST               113   R2802                6
    X2828     R2806               -8   R2991                4
    X2828     R2914                9   R2937               -6
    X2829     COST               -22   R2853               -2
    X2829     R2963               -4   R2975                3
    X2829     R2970               -3   R2806               -9
    X2830     COST               -41   R2907                1
    X2830     R2859               -5   R2999                3
    X2830     R2918               -9   R2892               -5
    X2831     COST                -9   R2918               -9
    X2831     R2994                8   R2824                3
    X2831     R2972                1   R2923                5
    X2832     COST               -22   R2907               -4
    X2832     R2909               -8   R2893               -1
    X2832     R2969               -9   R2802                9
    X2833     COST               -24   R2834                7
    X2833     R2932               -5   R2945               -3
    X2833     R2911               -3   R2806               -7
    X2834     COST                35   R2825                7
    X2834     R2917               -2   R2981                9
    X2834     R2837               -2   R2961                2
    X2835     COST                54   R2934               -5
    X2835     R2861                3   R2992                9
    X2835     R2996               -6   R2958                4
    X2836     COST               -21   R2894                2
    X2836     R2860               -7   R2966               -7
    X2836     R2844               -2   R2838               -4
    X2837     COST                61   R2868                9
    X2837     R2812                2   R2857                5
    X2837     R2980               -5   R2855                6
    X2838     COST                75   R2968                2
    X2838     R2805                8   R2970                8
    X2838     R2943               -5   R2947               -7
    X2839     COST               -22   R2848                6
    X2839     R2879               -5   R2815               -6
    X2839     R2973               -4   R2894               -6
    X2840     COST               -73   R2899               -4
    X2840     R2988               -6   R2818               -6
    X2840     R2874                8   R2822                5
    X2841     COST               -50   R2958               -6
    X2841     R2934                4   R2931                2
    X2841     R2979                8   R2945               -6
    X2842     COST                37   R2849               -6
    X2842     R2913                6   R2812                8
    X2842     R2801                7   R2957               -1
    X2843     COST               -91   R2914               -7
    X2843     R2985               -6   R2850               -4
    X2843     R2986               -8   R2886                5
    X2844     COST               -13   R2839                1
    X2844     R2806               -1   R2925               -1
    X2844     R2955               -3   R2869                5
    X2845     COST               126   R2803                9
    X2845     R2957               -4   R2837                8
    X2845     R2805                9   R2839                1
    X2846     COST               -30   R2970               -2
    X2846     R2884                8   R2819                5
    X2846     R2835               -4   R2994               -7
    X2847     COST               -29   R2977               -8
    X2847     R2910               -8   R2968                8
    X2847     R2893                1   R2960                2
    X2848     COST                35   R2930                2
    X2848     R2918                3   R2853               -4
    X2848     R2875                9   R2997               -3
    X2849     COST                18   R2992                3
    X2849     R2933                9   R2830               -1
    X2849     R2997               -7   R2966               -6
    X2850     COST               -27   R2918               -1
    X2850     R2851               -5   R2850               -7
    X2850     R2921                6   R2844                8
    X2851     COST               -15   R2919               -4
    X2851     R2829                2   R2887                2
    X2851     R2886               -9   R2984               -5
    X2852     COST               -40   R2885               -4
    X2852     R2824               -5   R2898                1
    X2852     R2889               -1   R2902               -3
    X2853     COST                46   R2898                5
    X2853     R2901                2   R2812                6
    X2853     R2828                5   R2806                6
    X2854     COST               -34   R2849                2
    X2854     R2954               -9   R2952               -5
    X2854     R2986               -6   R2972               -9
    X2855     COST                69   R2865                7
    X2855     R2954               -6   R2988                5
    X2855     R2841                9   R2800               -3
    X2856     COST                 6   R2991                3
    X2856     R2844                2   R2803                2
    X2856     R2811                4   R2875               -2
    X2857     COST               -73   R2900               -8
    X2857     R2972               -5   R2873               -1
    X2857     R2820               -2   R2813               -3
    X2858     COST                62   R2927                5
    X2858     R2939               -2   R2988               -4
    X2858     R2950               -5   R2918                7
    X2859     COST               -26   R2922               -8
    X2859     R2913               -1   R2933               -9
    X2859     R2991                3   R2883               -3
    X2860     R2937                1   R2829                9
    X2860     R2947                2   R2945               -3
    X2860     R2949               -3
    X2861     COST                66   R2808               -5
    X2861     R2918                6   R2862               -2
    X2861     R2894               -5   R2824                7
    X2862     COST               -72   R2871               -8
    X2862     R2891               -9   R2998               -2
    X2862     R2897               -2   R2970               -8
    X2863     COST               -56   R2808               -1
    X2863     R2921               -8   R2861               -4
    X2863     R2977               -1   R2832                3
    X2864     COST                40   R2935                1
    X2864     R2924               -4   R2988                8
    X2864     R2977               -8   R2825                1
    X2865     COST               -23   R2855               -1
    X2865     R2814                7   R2853               -5
    X2865     R2956               -9   R2809                4
    X2866     COST                 8   R2910                7
    X2866     R2975               -5   R2853               -8
    X2866     R2926               -4   R2828               -1
    X2867     COST               -16   R2890               -2
    X2867     R2900               -8   R2976               -1
    X2867     R2851                7   R2809                1
    X2868     COST                 4   R2906               -4
    X2868     R2901               -7   R2820               -1
    X2868     R2858               -3   R2862                2
    X2869     COST               -39   R2902                1
    X2869     R2877               -7   R2852               -8
    X2869     R2994               -7   R2835                4
    X2870     COST                15   R2939                1
    X2870     R2885               -2   R2901               -8
    X2870     R2826                4   R2943                3
    X2871     COST               -15   R2830                3
    X2871     R2867                8   R2996               -4
    X2871     R2921                1   R2987               -6
    X2872     COST               -17   R2806                5
    X2872     R2827               -5   R2877               -2
    X2872     R2954                3   R2979               -8
    X2873     COST                68   R2898                8
    X2873     R2920                3   R2960                9
    X2873     R2986                3   R2942                1
    X2874     COST                23   R2935                2
    X2874     R2997               -6   R2806               -9
    X2874     R2888               -9   R2962               -8
    X2875     COST                62   R2915                7
    X2875     R2888               -4   R2942                1
    X2875     R2883                4   R2904                5
    X2876     COST                69   R2913                3
    X2876     R2893                1   R2877                8
    X2876     R2979               -7   R2849               -6
    X2877     COST              -133   R2979                4
    X2877     R2806                5   R2990               -7
    X2877     R2801               -6   R2932               -8
    X2878     COST                32   R2861                5
    X2878     R2899               -9   R2851               -4
    X2878     R2979                7   R2879                7
    X2879     COST                16   R2847               -6
    X2879     R2894               -1   R2912                6
    X2879     R2932                1   R2886                9
    X2880     COST                39   R2883                9
    X2880     R2802                3   R2913                8
    X2880     R2856               -4   R2914                3
    X2881     COST                14   R2913                3
    X2881     R2800                2   R2900               -6
    X2881     R2974                5   R2844                6
    X2882     COST                 4   R2822               -3
    X2882     R2817               -6   R2949               -3
    X2882     R2965                6   R2961               -6
    X2883     R2912                8   R2829                6
    X2883     R2859               -1   R2895                5
    X2883     R2827               -5
    X2884     COST               -41   R2814                5
    X2884     R2923                8   R2809                1
    X2884     R2863               -9   R2993                1
    X2885     COST                -2   R2840                4
    X2885     R2892               -2   R2978                1
    X2885     R2983               -9   R2902               -8
    X2886     COST                68   R2861               -3
    X2886     R2809                8   R2928                7
    X2886     R2892               -2   R2942                8
    X2887     COST              -115   R2975               -8
    X2887     R2864                7   R2926               -4
    X2887     R2932               -6   R2863               -6
    X2888     COST                29   R2891                7
    X2888     R2836                8   R2980               -1
    X2888     R2863               -1   R2894               -6
    X2889     COST                93   R2872                3
    X2889     R2936                8   R2871               -8
    X2889     R2927                7   R2862               -1
    X2890     COST               131   R2889                9
    X2890     R2920                9   R2981                6
    X2890     R2903               -7   R2885                6
    X2891     COST                15   R2871                3
    X2891     R2835               -3   R2912               -7
    X2891     R2901                9   R2834                6
    X2892     COST                68   R2890                9
    X2892     R2868                1   R2984               -1
    X2892     R2936               -2   R2933               -4
    X2893     COST               -34   R2996                2
    X2893     R2812               -1   R2962                2
    X2893     R2837               -5   R2882               -5
    X2894     COST               -27   R2839               -3
    X2894     R2950                5   R2857                8
    X2894     R2920               -8   R2905               -1
    X2895     COST                39   R2971                1
    X2895     R2829               -3   R2956                5
    X2895     R2958                3   R2854               -9
    X2896     COST               -47   R2834                8
    X2896     R2927               -9   R2876                5
    X2896     R2941               -1   R2917               -3
    X2897     COST                -8   R2878                5
    X2897     R2951               -9   R2976               -1
    X2897     R2920               -2   R2827                4
    X2898     R2856               -1   R2955               -3
    X2898     R2900                1   R2829                9
    X2898     R2968               -4
    X2899     COST               -43   R2937               -3
    X2899     R2904               -9   R2981                4
    X2899     R2968                1   R2858                2
    X2900     COST                22   R2935               -1
    X2900     R2911               -7   R2955               -9
    X2900     R2807                9   R2822               -2
    X2901     COST                17   R2944                8
    X2901     R2940               -9   R2837                3
    X2901     R2879               -6   R2855                4
    X2902     COST               -23   R2914                1
    X2902     R2929                5   R2973               -9
    X2902     R2852                6   R2903                3
    X2903     COST               -33   R2963               -6
    X2903     R2883               -6   R2893               -7
    X2903     R2981               -3   R2840               -7
    X2904     COST                11   R2966               -5
    X2904     R2937                7   R2945               -2
    X2904     R2882               -7   R2854                4
    X2905     COST                20   R2915                4
    X2905     R2920                2   R2979                5
    X2905     R2924                1   R2997               -9
    X2906     COST               108   R2915                9
    X2906     R2960               -4   R2868               -6
    X2906     R2890                9   R2895               -5
    X2907     COST                12   R2964               -9
    X2907     R2914                4   R2996               -4
    X2907     R2844               -2   R2825                7
    X2908     COST                48   R2961               -5
    X2908     R2851                6   R2951                3
    X2908     R2823                8   R2973                2
    X2909     COST                69   R2822                1
    X2909     R2819                2   R2848                8
    X2909     R2899                8   R2948                7
    X2910     R2914               -4   R2865                1
    X2910     R2980               -8   R2920                8
    X2910     R2892                2
    X2911     COST               -73   R2832               -6
    X2911     R2957               -7   R2940                6
    X2911     R2821               -2   R2824               -7
    X2912     COST               -53   R2805               -5
    X2912     R2911               -5   R2851               -1
    X2912     R2913               -9   R2804               -2
    X2913     COST                72   R2811                6
    X2913     R2935                9   R2895                3
    X2913     R2987                5   R2861               -6
    X2914     COST               -72   R2984               -8
    X2914     R2947                9   R2956               -8
    X2914     R2944               -3   R2853                8
    X2915     COST                 6   R2932                2
    X2915     R2888               -4   R2868               -5
    X2915     R2977                5   R2903               -3
    X2916     COST               -38   R2884                5
    X2916     R2813                8   R2842                8
    X2916     R2936               -8   R2949                1
    X2917     COST               -75   R2990               -9
    X2917     R2857                1   R2916               -3
    X2917     R2884               -7   R2994                1
    X2918     COST                31   R2971               -9
    X2918     R2898                1   R2830                1
    X2918     R2974                3   R2968                7
    X2919     R2945                7   R2971                8
    X2919     R2822               -4   R2840                2
    X2919     R2844                5
    X2920     COST               -25   R2996                8
    X2920     R2982               -7   R2937                2
    X2920     R2816                2   R2832               -6
    X2921     COST               -46   R2864               -8
    X2921     R2841               -8   R2872               -6
    X2921     R2898                2   R2957                2
    X2922     COST                21   R2929                8
    X2922     R2822                2   R2811               -5
    X2922     R2803                6   R2950               -7
    X2923     COST                 1   R2862                8
    X2923     R2848               -2   R2871                9
    X2923     R2931               -1   R2907               -8
    X2924     COST               -25   R2915               -1
    X2924     R2971                4   R2882               -6
    X2924     R2855               -3   R2901               -3
    X2925     COST                45   R2894               -5
    X2925     R2998               -2   R2969                9
    X2925     R2986                7   R2906                3
    X2926     COST                -6   R2814                8
    X2926     R2852               -5   R2815               -4
    X2926     R2910                3   R2854               -9
    X2927     COST               -10   R2942                1
    X2927     R2945                5   R2882               -5
    X2927     R2815               -6   R2885               -5
    X2928     COST               -72   R2931                5
    X2928     R2898               -7   R2905               -2
    X2928     R2958               -3   R2895                3
    X2929     COST               -28   R2852               -5
    X2929     R2878               -3   R2870               -4
    X2929     R2925               -4   R2876               -8
    X2930     COST                14   R2869               -8
    X2930     R2882                7   R2984                3
    X2930     R2997                4   R2853               -8
    X2931     COST                57   R2804               -1
    X2931     R2895               -4   R2824                9
    X2931     R2940                9   R2842               -4
    X2932     COST               -11   R2957               -4
    X2932     R2822               -3   R2954               -9
    X2932     R2956                4   R2936               -7
    X2933     COST                13   R2808                2
    X2933     R2973                1   R2912                7
    X2933     R2983               -6   R2919                6
    X2934     COST                88   R2866                3
    X2934     R2904                7   R2875                1
    X2934     R2820                8   R2823                8
    X2935     COST                26   R2916               -6
    X2935     R2849               -4   R2848                8
    X2935     R2974                2   R2941                5
    X2936     COST                86   R2805                5
    X2936     R2846               -3   R2850                8
    X2936     R2814               -7   R2951                2
    X2937     COST                14   R2858                7
    X2937     R2901                7   R2821               -7
    X2937     R2911                3   R2854                2
    X2938     COST                71   R2970                7
    X2938     R2855               -3   R2841                3
    X2938     R2930                4   R2929                7
    X2939     COST                -4   R2971                2
    X2939     R2943               -8   R2916                8
    X2939     R2812                4   R2980               -5
    X2940     COST               -51   R2843                8
    X2940     R2938                7   R2933               -4
    X2940     R2837               -4   R2808               -5
    X2941     COST               -16   R2974               -3
    X2941     R2885                4   R2966                2
    X2941     R2968                8   R2906                2
    X2942     COST                81   R2851               -9
    X2942     R2891                7   R2898                9
    X2942     R2958                7   R2838                6
    X2943     COST                 6   R2893                9
    X2943     R2913                2   R2918               -2
    X2943     R2828               -3   R2922               -2
    X2944     COST               -26   R2843               -8
    X2944     R2917                7   R2820               -8
    X2944     R2955                6   R2935               -3
    X2945     COST              -131   R2872               -8
    X2945     R2958               -9   R2949               -8
    X2945     R2889               -2   R2977                1
    X2946     COST                42   R2882               -4
    X2946     R2816                5   R2850                7
    X2946     R2951                9   R2904               -1
    X2947     COST                -7   R2975               -3
    X2947     R2811               -4   R2841               -5
    X2947     R2854                9   R2941               -8
    X2948     COST                25   R2950               -9
    X2948     R2976                1   R2816                8
    X2948     R2804                5   R2834               -7
    X2949     COST               -73   R2889               -8
    X2949     R2869               -7   R2881                6
    X2949     R2939                1   R2800               -4
    X2950     COST               -60   R2922               -9
    X2950     R2834                5   R2917               -2
    X2950     R2809               -5   R2853               -4
    X2951     COST                13   R2995               -6
    X2951     R2918                7   R2825               -2
    X2951     R2853               -5   R2802               -6
    X2952     COST                -7   R2812                1
    X2952     R2940               -7   R2819               -9
    X2952     R2965                2   R2859               -6
    X2953     COST                 7   R2990                1
    X2953     R2991               -8   R2881               -1
    X2953     R2974                2   R2825               -2
    X2954     COST               -32   R2975               -2
    X2954     R2968               -5   R2927               -4
    X2954     R2802               -1   R2899                4
    X2955     COST                51   R2855                8
    X2955     R2904               -3   R2919                1
    X2955     R2880               -6   R2897                2
    X2956     COST               -42   R2888                5
    X2956     R2821               -4   R2904               -3
    X2956     R2981                3   R2805               -7
    X2957     COST                11   R2928                9
    X2957     R2815               -6   R2901                5
    X2957     R2919                1   R2806               -9
    X2958     COST                 9   R2986                4
    X2958     R2971               -1   R2951               -5
    X2958     R2979               -7   R2830                4
    X2959     COST               -34   R2865               -6
    X2959     R2923               -7   R2994                2
    X2959     R2951               -4   R2815               -9
    X2960     COST                25   R2863                3
    X2960     R2880               -5   R2963                2
    X2960     R2937               -2   R2849               -5
    X2961     COST                76   R2825               -2
    X2961     R2900                6   R2862               -2
    X2961     R2854               -3   R2809                7
    X2962     COST               -30   R2862               -9
    X2962     R2979               -2   R2893                5
    X2962     R2823                7   R2873                5
    X2963     COST               -37   R2950               -4
    X2963     R2926               -6   R2800               -7
    X2963     R2934               -9   R2989               -1
    X2964     R2898                3   R2888               -6
    X2964     R2949                5   R2850               -3
    X2964     R2998                9
    X2965     COST                10   R2933               -5
    X2965     R2848               -7   R2854                5
    X2965     R2898                7   R2873                8
    X2966     COST                76   R2908                8
    X2966     R2876                4   R2816                1
    X2966     R2983               -1   R2936                1
    X2967     COST                78   R2970                5
    X2967     R2838               -6   R2808                6
    X2967     R2969                4   R2867                6
    X2968     COST                20   R2968                7
    X2968     R2833                3   R2866               -3
    X2968     R2890                7   R2863               -6
    X2969     COST                26   R2969               -3
    X2969     R2851                3   R2964                4
    X2969     R2833                2   R2909               -7
    X2970     COST                59   R2931                7
    X2970     R2855               -5   R2867                8
    X2970     R2991                9   R2921                8
    X2971     COST                27   R2867               -5
    X2971     R2936               -2   R2820                6
    X2971     R2845                2   R2946               -4
    X2972     COST                27   R2910                4
    X2972     R2870                5   R2897               -3
    X2972     R2944                6   R2901                2
    X2973     COST               -30   R2878                2
    X2973     R2840               -7   R2873               -7
    X2973     R2879               -4   R2856                3
    X2974     COST                43   R2833                8
    X2974     R2885               -2   R2825                2
    X2974     R2876               -6   R2931               -6
    X2975     COST               -92   R2973               -9
    X2975     R2874               -5   R2848               -8
    X2975     R2895               -4   R2854                9
    X2976     COST               -35   R2922                5
    X2976     R2889               -8   R2929                4
    X2976     R2876                3   R2873                8
    X2977     COST               -63   R2896               -5
    X2977     R2869                3   R2875               -8
    X2977     R2921               -7   R2883               -7
    X2978     COST               -29   R2852               -1
    X2978     R2872               -1   R2815               -2
    X2978     R2987                3   R2923               -8
    X2979     COST                16   R2876               -8
    X2979     R2938                8   R2923                8
    X2979     R2943               -2   R2964                6
    X2980     COST                64   R2939                8
    X2980     R2984                5   R2906               -7
    X2980     R2967                6   R2823               -7
    X2981     R2815               -1   R2852               -2
    X2981     R2843                6   R2806               -9
    X2981     R2986               -8
    X2982     COST                44   R2960               -1
    X2982     R2941               -9   R2924               -8
    X2982     R2801                8   R2976               -6
    X2983     COST                55   R2903                7
    X2983     R2932                7   R2904               -6
    X2983     R2957                9   R2832                5
    X2984     COST                32   R2907                5
    X2984     R2905                4   R2940               -7
    X2984     R2964               -6   R2830                1
    X2985     COST                -5   R2993               -4
    X2985     R2987                3   R2979                8
    X2985     R2841               -1   R2938                7
    X2986     COST               -35   R2882               -4
    X2986     R2895               -9   R2977                1
    X2986     R2964               -6   R2809               -5
    X2987     COST              -110   R2879               -6
    X2987     R2855                4   R2875               -1
    X2987     R2831               -4   R2916               -9
    X2988     COST                 9   R2878               -2
    X2988     R2829               -4   R2818                1
    X2988     R2950               -1   R2989               -6
    X2989     COST                13   R2874                2
    X2989     R2966                5   R2931                6
    X2989     R2815               -9   R2892                6
    X2990     COST                67   R2984                3
    X2990     R2829                4   R2918                6
    X2990     R2929                5   R2840                7
    X2991     COST                89   R2990                5
    X2991     R2882                4   R2909                6
    X2991     R2835                9   R2993                2
    X2992     COST               -45   R2818                2
    X2992     R2950                3   R2935               -2
    X2992     R2978               -7   R2880                1
    X2993     COST                75   R2974               -1
    X2993     R2851                7   R2872                4
    X2993     R2847                7   R2862                5
    X2994     COST                66   R2859               -5
    X2994     R2896                4   R2877                5
    X2994     R2939                7   R2993                2
    X2995     COST                23   R2976                2
    X2995     R2882                5   R2862                1
    X2995     R2893                6   R2844                5
    X2996     COST               -61   R2960                6
    X2996     R2968               -2   R2847               -2
    X2996     R2910               -3   R2927               -7
    X2997     COST                12   R2978               -4
    X2997     R2897                3   R2965                8
    X2997     R2942               -2   R2864               -9
    X2998     COST               156   R2949                5
    X2998     R2965                6   R2918                9
    X2998     R2977                4   R2848                9
    X2999     COST                 2   R2869                5
    X2999     R2949                8   R2975               -9
    X2999     R2955                1   R2843               -6
RHS
    RHS       R0                 -30
    RHS       R1                  50
    RHS       R2                   6
    RHS       R3                  58
    RHS       R4                   0
    RHS       R5                   0
    RHS       R6                  -8
    RHS       R7                  47
    RHS       R8                  -1
    RHS       R9                  44
    RHS       R10                -68
    RHS       R11                  0
    RHS       R12                 50
    RHS       R13                 30
    RHS       R14                152
    RHS       R15                 43
    RHS       R16                 35
    RHS       R17                 48
    RHS       R18                  3
    RHS       R19                  5
    RHS       R20                -25
    RHS       R21                  9
    RHS       R22                -33
    RHS       R23                -51
    RHS       R24                  1
    RHS       R25                 28
    RHS       R26                -49
    RHS       R27                 45
    RHS       R28                -56
    RHS       R29                -56
    RHS       R30                  7
    RHS       R31                 41
    RHS       R32                 -2
    RHS       R33                 -4
    RHS       R34                 -4
    RHS       R35               -139
    RHS       R36                  8
    RHS       R37                 73
    RHS       R38                 44
    RHS       R39                 25
    RHS       R40                  0
    RHS       R41                -47
    RHS       R42                 -3
    RHS       R43                -74
    RHS       R44                -23
    RHS       R45                  0
    RHS       R46                 28
    RHS       R47                  3
    RHS       R48                135
    RHS       R49                 27
    RHS       R50                104
    RHS       R51                -87
    RHS       R52                -55
    RHS       R53                 54
    RHS       R54                -41
    RHS       R55                 -1
    RHS       R56                 -4
    RHS       R57                 -4
    RHS       R58                 -3
    RHS       R59                -27
    RHS       R60                 52
    RHS       R61                 -2
    RHS       R62               -122
    RHS       R63                -16
    RHS       R64                 25
    RHS       R65                -18
    RHS       R66                 32
    RHS       R67                -20
    RHS       R68                 -2
    RHS       R69                 56
    RHS       R70                 -4
    RHS       R71                -48
    RHS       R72                -23
    RHS       R73                -77
    RHS       R74                -56
    RHS       R75                 30
    RHS       R76                -63
    RHS       R77                -51
    RHS       R78                -55
    RHS       R79                -35
    RHS       R80               -120
    RHS       R81                -16
    RHS       R82                 -4
    RHS       R83                -59
    RHS       R84                 72
    RHS       R85                  0
    RHS       R86                -34
    RHS       R87                 41
    RHS       R88                -17
    RHS       R89                  2
    RHS       R90                -25
    RHS       R91                -43
    RHS       R92                 60
    RHS       R93                -29
    RHS       R94                -12
    RHS       R95                -27
    RHS       R96                 33
    RHS       R97                  7
    RHS       R98                -43
    RHS       R99               -119
    RHS       R100                21
    RHS       R101                -2
    RHS       R102                24
    RHS       R103                -7
    RHS       R104                -2
    RHS       R105                 0
    RHS       R106               -48
    RHS       R107                38
    RHS       R108                 0
    RHS       R109               -42
    RHS       R110                20
    RHS       R111               -26
    RHS       R112               -87
    RHS       R113                -1
    RHS       R114                 0
    RHS       R115               -19
    RHS       R116                83
    RHS       R117                10
    RHS       R118                -2
    RHS       R119                18
    RHS       R120                -4
    RHS       R121               -10
    RHS       R122                 0
    RHS       R123               107
    RHS       R124               -10
    RHS       R125                 0
    RHS       R126                39
    RHS       R127               -10
    RHS       R128                17
    RHS       R129               -82
    RHS       R130                62
    RHS       R131                45
    RHS       R132                72
    RHS       R133               -11
    RHS       R134               -28
    RHS       R135                -1
    RHS       R136               -21
    RHS       R137                60
    RHS       R138               -12
    RHS       R139               -15
    RHS       R140               -61
    RHS       R141                17
    RHS       R142               -60
    RHS       R143                35
    RHS       R144                28
    RHS       R145                 0
    RHS       R146               180
    RHS       R147               -24
    RHS       R148                24
    RHS       R149                48
    RHS       R150                36
    RHS       R151                 0
    RHS       R152               -29
    RHS       R153               -27
    RHS       R154                -8
    RHS       R155                -5
    RHS       R156                20
    RHS       R157                62
    RHS       R158               -13
    RHS       R159               -34
    RHS       R160                47
    RHS       R161               -14
    RHS       R162               -47
    RHS       R163               -69
    RHS       R164               -72
    RHS       R165              -155
    RHS       R166               -69
    RHS       R167               -72
    RHS       R168               -22
    RHS       R169                24
    RHS       R170               -64
    RHS       R171                 2
    RHS       R172                41
    RHS       R173               -30
    RHS       R174               -50
    RHS       R175               -21
    RHS       R176                44
    RHS       R177                33
    RHS       R178                -1
    RHS       R179                -8
    RHS       R180               -38
    RHS       R181               -40
    RHS       R182                -3
    RHS       R183                 0
    RHS       R184               -45
    RHS       R185                19
    RHS       R186                -3
    RHS       R187               -64
    RHS       R188                 0
    RHS       R189                20
    RHS       R190                -4
    RHS       R191               -20
    RHS       R192                 9
    RHS       R193               -38
    RHS       R194               -96
    RHS       R195                 3
    RHS       R196                -3
    RHS       R197               152
    RHS       R198               -10
    RHS       R199              -100
    RHS       R200                -2
    RHS       R201               -48
    RHS       R202               -88
    RHS       R203               158
    RHS       R204                40
    RHS       R205               -25
    RHS       R206                28
    RHS       R207               -78
    RHS       R208               -23
    RHS       R209                -3
    RHS       R210                16
    RHS       R211                24
    RHS       R212                -2
    RHS       R213                 5
    RHS       R214                21
    RHS       R215                -3
    RHS       R216               -67
    RHS       R217              -120
    RHS       R218                70
    RHS       R219                 2
    RHS       R220                 0
    RHS       R221                36
    RHS       R222                -8
    RHS       R223                 8
    RHS       R224                19
    RHS       R225                27
    RHS       R226                48
    RHS       R227                 0
    RHS       R228                25
    RHS       R229               -48
    RHS       R230               -25
    RHS       R231               -69
    RHS       R232                -8
    RHS       R233              -125
    RHS       R234                79
    RHS       R235               -59
    RHS       R236               165
    RHS       R237                 8
    RHS       R238                66
    RHS       R239                 2
    RHS       R240                 2
    RHS       R241               -45
    RHS       R242                27
    RHS       R243               -12
    RHS       R244                 0
    RHS       R245                45
    RHS       R246               -29
    RHS       R247               -27
    RHS       R248               -15
    RHS       R249                66
    RHS       R250                18
    RHS       R251                 5
    RHS       R252               -35
    RHS       R253               -58
    RHS       R254                31
    RHS       R255                20
    RHS       R256                34
    RHS       R257                 4
    RHS       R258                18
    RHS       R259               -47
    RHS       R260                28
    RHS       R261                70
    RHS       R262                21
    RHS       R263                11
    RHS       R264               -12
    RHS       R265                -6
    RHS       R266               -12
    RHS       R267                -3
    RHS       R268                53
    RHS       R269               -67
    RHS       R270                15
    RHS       R271                 0
    RHS       R272                -6
    RHS       R273                66
    RHS       R274                31
    RHS       R275               -19
    RHS       R276                13
    RHS       R277               -68
    RHS       R278               -14
    RHS       R279                92
    RHS       R280               -69
    RHS       R281               -57
    RHS       R282               -32
    RHS       R283               166
    RHS       R284               -93
    RHS       R285               -11
    RHS       R286              -123
    RHS       R287                30
    RHS       R288                62
    RHS       R289                 2
    RHS       R290                10
    RHS       R291               -30
    RHS       R292              -106
    RHS       R293                 0
    RHS       R294                36
    RHS       R295                 8
    RHS       R296                -3
    RHS       R297                32
    RHS       R298                20
    RHS       R299               -22
    RHS       R300               -79
    RHS       R301                -2
    RHS       R302               -35
    RHS       R303                 0
    RHS       R304                45
    RHS       R305                 6
    RHS       R306                29
    RHS       R307                 7
    RHS       R308               -19
    RHS       R309               -14
    RHS       R310                 6
    RHS       R311                44
    RHS       R312                48
    RHS       R313               -14
    RHS       R314                23
    RHS       R315                 8
    RHS       R316               -11
    RHS       R317               105
    RHS       R318                64
    RHS       R319               -10
    RHS       R320                33
    RHS       R321               -40
    RHS       R322               -54
    RHS       R323                28
    RHS       R324               -46
    RHS       R325                20
    RHS       R326                -4
    RHS       R327                17
    RHS       R328                -6
    RHS       R329               110
    RHS       R330               -11
    RHS       R331                52
    RHS       R332                57
    RHS       R333               -84
    RHS       R334                -6
    RHS       R335                72
    RHS       R336                52
    RHS       R337               -90
    RHS       R338                31
    RHS       R339               -95
    RHS       R340                17
    RHS       R341                -3
    RHS       R342                -1
    RHS       R343                 0
    RHS       R344                -2
    RHS       R345                 4
    RHS       R346                44
    RHS       R347               -64
    RHS       R348                -6
    RHS       R349                 7
    RHS       R350                37
    RHS       R351               -37
    RHS       R352                41
    RHS       R353                44
    RHS       R354                18
    RHS       R355               -47
    RHS       R356               104
    RHS       R357               -15
    RHS       R358                -1
    RHS       R359               -10
    RHS       R360               -45
    RHS       R361                13
    RHS       R362                14
    RHS       R363               -57
    RHS       R364                -2
    RHS       R365                32
    RHS       R366               -13
    RHS       R367                18
    RHS       R368               -40
    RHS       R369               -49
    RHS       R370               -33
    RHS       R371               105
    RHS       R372                16
    RHS       R373                 0
    RHS       R374                -8
    RHS       R375                74
    RHS       R376               -31
    RHS       R377              -130
    RHS       R378               -31
    RHS       R379                18
    RHS       R380               -12
    RHS       R381               -16
    RHS       R382                31
    RHS       R383               -44
    RHS       R384                 1
    RHS       R385               -16
    RHS       R386                -3
    RHS       R387                 5
    RHS       R388                -3
    RHS       R389                 0
    RHS       R390               -19
    RHS       R391               -98
    RHS       R392               -67
    RHS       R393                69
    RHS       R394                52
    RHS       R395                -9
    RHS       R396                56
    RHS       R397               110
    RHS       R398                 1
    RHS       R399                14
    RHS       R400                23
    RHS       R401               -45
    RHS       R402                17
    RHS       R403                33
    RHS       R404                26
    RHS       R405                 9
    RHS       R406               -61
    RHS       R407                -4
    RHS       R408                21
    RHS       R409                 4
    RHS       R410                45
    RHS       R411               -64
    RHS       R412               -19
    RHS       R413               -15
    RHS       R414                42
    RHS       R415                -5
    RHS       R416                 3
    RHS       R417                 6
    RHS       R418               -24
    RHS       R419               158
    RHS       R420                14
    RHS       R421               -75
    RHS       R422               -30
    RHS       R423                37
    RHS       R424                14
    RHS       R425               -14
    RHS       R426                 5
    RHS       R427                34
    RHS       R428                58
    RHS       R429                54
    RHS       R430                35
    RHS       R431               -77
    RHS       R432                84
    RHS       R433                50
    RHS       R434               -27
    RHS       R435                17
    RHS       R436                26
    RHS       R437                 2
    RHS       R438                -2
    RHS       R439               -62
    RHS       R440                78
    RHS       R441                -7
    RHS       R442               -74
    RHS       R443                65
    RHS       R444               -84
    RHS       R445                28
    RHS       R446                34
    RHS       R447                27
    RHS       R448                 0
    RHS       R449                -9
    RHS       R450                18
    RHS       R451                19
    RHS       R452               -35
    RHS       R453                -1
    RHS       R454                16
    RHS       R455                49
    RHS       R456               -37
    RHS       R457                28
    RHS       R458               -57
    RHS       R459               106
    RHS       R460               -32
    RHS       R461                -9
    RHS       R462                -6
    RHS       R463               -31
    RHS       R464                21
    RHS       R465               -26
    RHS       R466               -21
    RHS       R467               -50
    RHS       R468                99
    RHS       R469               112
    RHS       R470                75
    RHS       R471               -28
    RHS       R472                81
    RHS       R473               -40
    RHS       R474               -49
    RHS       R475                24
    RHS       R476                -8
    RHS       R477               -49
    RHS       R478                -5
    RHS       R479               -40
    RHS       R480                 9
    RHS       R481                -3
    RHS       R482               -14
    RHS       R483                 0
    RHS       R484                26
    RHS       R485                45
    RHS       R486               -11
    RHS       R487                55
    RHS       R488                60
    RHS       R489               -53
    RHS       R490               -58
    RHS       R491                 0
    RHS       R492                49
    RHS       R493               -67
    RHS       R494                 6
    RHS       R495               -96
    RHS       R496                57
    RHS       R497              -117
    RHS       R498                14
    RHS       R499                26
    RHS       R500                 0
    RHS       R501               -14
    RHS       R502                54
    RHS       R503                20
    RHS       R504                65
    RHS       R505                -3
    RHS       R506                12
    RHS       R507                -8
    RHS       R508                 0
    RHS       R509                78
    RHS       R510                 5
    RHS       R511                63
    RHS       R512               205
    RHS       R513                47
    RHS       R514                73
    RHS       R515                22
    RHS       R516                33
    RHS       R517                44
    RHS       R518               -65
    RHS       R519                54
    RHS       R520              -122
    RHS       R521                 2
    RHS       R522               -64
    RHS       R523               -78
    RHS       R524               -37
    RHS       R525                 2
    RHS       R526               -11
    RHS       R527                -5
    RHS       R528               -23
    RHS       R529               -16
    RHS       R530               -12
    RHS       R531               -75
    RHS       R532                -4
    RHS       R533               -18
    RHS       R534                -1
    RHS       R535                19
    RHS       R536                62
    RHS       R537               -38
    RHS       R538                30
    RHS       R539                47
    RHS       R540                38
    RHS       R541                19
    RHS       R542                -8
    RHS       R543               185
    RHS       R544                59
    RHS       R545                68
    RHS       R546               -17
    RHS       R547               129
    RHS       R548                38
    RHS       R549               -27
    RHS       R550               -61
    RHS       R551                 5
    RHS       R552               -60
    RHS       R553               101
    RHS       R554                44
    RHS       R555               -48
    RHS       R556               -20
    RHS       R557                15
    RHS       R558                18
    RHS       R559                 0
    RHS       R560                10
    RHS       R561               -26
    RHS       R562                63
    RHS       R563                14
    RHS       R564              -205
    RHS       R565                16
    RHS       R566               -11
    RHS       R567               -49
    RHS       R568                -3
    RHS       R569               105
    RHS       R570               -10
    RHS       R571               -80
    RHS       R572               -20
    RHS       R573              -107
    RHS       R574                51
    RHS       R575                44
    RHS       R576                -2
    RHS       R577                 1
    RHS       R578                13
    RHS       R579                -4
    RHS       R580               117
    RHS       R581                -9
    RHS       R582               -41
    RHS       R583                 0
    RHS       R584                -4
    RHS       R585                 0
    RHS       R586                19
    RHS       R587                96
    RHS       R588               -33
    RHS       R589               -96
    RHS       R590               -48
    RHS       R591                19
    RHS       R592                65
    RHS       R593                28
    RHS       R594                41
    RHS       R595                -4
    RHS       R596                 6
    RHS       R597               -13
    RHS       R598               -15
    RHS       R599               -18
    RHS       R600               125
    RHS       R601                 0
    RHS       R602                48
    RHS       R603               100
    RHS       R604               -70
    RHS       R605               -49
    RHS       R606               -60
    RHS       R607                11
    RHS       R608                -3
    RHS       R609               -16
    RHS       R610                 6
    RHS       R611                 0
    RHS       R612                51
    RHS       R613                10
    RHS       R614                -1
    RHS       R615               -16
    RHS       R616                31
    RHS       R617                27
    RHS       R618                47
    RHS       R619                93
    RHS       R620                -2
    RHS       R621               -10
    RHS       R622                84
    RHS       R623                45
    RHS       R624                 0
    RHS       R625                 2
    RHS       R626               -95
    RHS       R627                19
    RHS       R628               -74
    RHS       R629                66
    RHS       R630                -2
    RHS       R631                 8
    RHS       R632                 0
    RHS       R633              -177
    RHS       R634               -49
    RHS       R635               -27
    RHS       R636                 6
    RHS       R637               -78
    RHS       R638                94
    RHS       R639                89
    RHS       R640                44
    RHS       R641                -1
    RHS       R642                 4
    RHS       R643                 1
    RHS       R644               -87
    RHS       R645                36
    RHS       R646               -29
    RHS       R647               -97
    RHS       R648                 4
    RHS       R649                81
    RHS       R650               -24
    RHS       R651                16
    RHS       R652                 6
    RHS       R653               -10
    RHS       R654                16
    RHS       R655               -75
    RHS       R656                72
    RHS       R657                47
    RHS       R658               -54
    RHS       R659                48
    RHS       R660               -12
    RHS       R661               -26
    RHS       R662               -17
    RHS       R663                 9
    RHS       R664               101
    RHS       R665                -3
    RHS       R666                 9
    RHS       R667                70
    RHS       R668                37
    RHS       R669               -28
    RHS       R670                16
    RHS       R671               -21
    RHS       R672                63
    RHS       R673                -3
    RHS       R674               -60
    RHS       R675              -107
    RHS       R676               -57
    RHS       R677               -69
    RHS       R678                -1
    RHS       R679               -50
    RHS       R680                -2
    RHS       R681                91
    RHS       R682               -14
    RHS       R683               -20
    RHS       R684               111
    RHS       R685               -26
    RHS       R686               -12
    RHS       R687                 0
    RHS       R688                19
    RHS       R689                38
    RHS       R690                 7
    RHS       R691                -3
    RHS       R692                21
    RHS       R693                47
    RHS       R694               -22
    RHS       R695                 4
    RHS       R696                13
    RHS       R697               -28
    RHS       R698               -18
    RHS       R699               -21
    RHS       R700                35
    RHS       R701                11
    RHS       R702               -41
    RHS       R703               -35
    RHS       R704                61
    RHS       R705               -44
    RHS       R706               -24
    RHS       R707               -31
    RHS       R708               -42
    RHS       R709                92
    RHS       R710               -65
    RHS       R711               -87
    RHS       R712               -19
    RHS       R713               -19
    RHS       R714               -95
    RHS       R715               -43
    RHS       R716                -9
    RHS       R717               -92
    RHS       R718                28
    RHS       R719               -46
    RHS       R720                64
    RHS       R721               -12
    RHS       R722                -4
    RHS       R723                29
    RHS       R724                 0
    RHS       R725                30
    RHS       R726               -26
    RHS       R727                17
    RHS       R728                -5
    RHS       R729               -15
    RHS       R730               -44
    RHS       R731                -6
    RHS       R732               -44
    RHS       R733               -61
    RHS       R734               132
    RHS       R735                65
    RHS       R736                -9
    RHS       R737                12
    RHS       R738               -71
    RHS       R739               -24
    RHS       R740                50
    RHS       R741              -168
    RHS       R742               -93
    RHS       R743                22
    RHS       R744                23
    RHS       R745                26
    RHS       R746               -34
    RHS       R747                16
    RHS       R748               -11
    RHS       R749                21
    RHS       R750                82
    RHS       R751                -4
    RHS       R752                 2
    RHS       R753                16
    RHS       R754               -49
    RHS       R755                 0
    RHS       R756                -7
    RHS       R757                -9
    RHS       R758               -60
    RHS       R759                36
    RHS       R760               -12
    RHS       R761                30
    RHS       R762               139
    RHS       R763               -19
    RHS       R764                32
    RHS       R765                35
    RHS       R766                81
    RHS       R767               -11
    RHS       R768               -49
    RHS       R769                24
    RHS       R770               -71
    RHS       R771                25
    RHS       R772                47
    RHS       R773                 8
    RHS       R774                -2
    RHS       R775                 0
    RHS       R776                64
    RHS       R777                55
    RHS       R778               -50
    RHS       R779              -140
    RHS       R780                -8
    RHS       R781              -113
    RHS       R782                45
    RHS       R783               -27
    RHS       R784               -19
    RHS       R785               -61
    RHS       R786                73
    RHS       R787               -26
    RHS       R788                -5
    RHS       R789                 0
    RHS       R790               -35
    RHS       R791                45
    RHS       R792                -3
    RHS       R793                23
    RHS       R794               -53
    RHS       R795              -107
    RHS       R796                 0
    RHS       R797                45
    RHS       R798               -23
    RHS       R799               -10
    RHS       R800               -21
    RHS       R801                10
    RHS       R802               -45
    RHS       R803                13
    RHS       R804                -8
    RHS       R805               -37
    RHS       R806               -29
    RHS       R807               -17
    RHS       R808                59
    RHS       R809                 2
    RHS       R810               -98
    RHS       R811                -1
    RHS       R812               -24
    RHS       R813                 7
    RHS       R814               -21
    RHS       R815               -40
    RHS       R816                -6
    RHS       R817               -48
    RHS       R818                31
    RHS       R819               -84
    RHS       R820               -42
    RHS       R821                28
    RHS       R822                -4
    RHS       R823               -53
    RHS       R824               -75
    RHS       R825                20
    RHS       R826                 1
    RHS       R827               -69
    RHS       R828               -11
    RHS       R829               -25
    RHS       R830               -13
    RHS       R831                -4
    RHS       R832                14
    RHS       R833               -27
    RHS       R834               -13
    RHS       R835              -114
    RHS       R836                -8
    RHS       R837                79
    RHS       R838                 6
    RHS       R839                28
    RHS       R840               -11
    RHS       R841                29
    RHS       R842                 2
    RHS       R843                84
    RHS       R844                25
    RHS       R845                15
    RHS       R846                -5
    RHS       R847                -3
    RHS       R848                48
    RHS       R849                 2
    RHS       R850                 0
    RHS       R851                21
    RHS       R852               -45
    RHS       R853                27
    RHS       R854               -42
    RHS       R855                82
    RHS       R856                 3
    RHS       R857               -36
    RHS       R858                23
    RHS       R859               -15
    RHS       R860               -39
    RHS       R861                29
    RHS       R862                52
    RHS       R863                42
    RHS       R864                -4
    RHS       R865                 8
    RHS       R866               105
    RHS       R867                16
    RHS       R868               -73
    RHS       R869               -67
    RHS       R870               -35
    RHS       R871               -30
    RHS       R872                -3
    RHS       R873                34
    RHS       R874                 5
    RHS       R875                40
    RHS       R876               -88
    RHS       R877               -16
    RHS       R878               -58
    RHS       R879                78
    RHS       R880                71
    RHS       R881                47
    RHS       R882              -100
    RHS       R883                92
    RHS       R884                 0
    RHS       R885               -60
    RHS       R886                62
    RHS       R887               -56
    RHS       R888                30
    RHS       R889               -12
    RHS       R890               -23
    RHS       R891                56
    RHS       R892                36
    RHS       R893              -109
    RHS       R894                42
    RHS       R895                27
    RHS       R896               -98
    RHS       R897                16
    RHS       R898               -15
    RHS       R899                17
    RHS       R900                 0
    RHS       R901               -17
    RHS       R902               -39
    RHS       R903               -72
    RHS       R904               -72
    RHS       R905                 8
    RHS       R906               -12
    RHS       R907                24
    RHS       R908               -56
    RHS       R909                18
    RHS       R910               -12
    RHS       R911               -13
    RHS       R912               -13
    RHS       R913               -25
    RHS       R914                35
    RHS       R915                81
    RHS       R916               -25
    RHS       R917               -14
    RHS       R918               -67
    RHS       R919                35
    RHS       R920                82
    RHS       R921                20
    RHS       R922               -11
    RHS       R923               160
    RHS       R924                -1
    RHS       R925                -3
    RHS       R926                26
    RHS       R927                 0
    RHS       R928              -129
    RHS       R929                77
    RHS       R930               -50
    RHS       R931                -7
    RHS       R932                18
    RHS       R933                10
    RHS       R934                -2
    RHS       R935                 0
    RHS       R936               -54
    RHS       R937               -92
    RHS       R938                28
    RHS       R939                16
    RHS       R940               161
    RHS       R941               -66
    RHS       R942                 0
    RHS       R943                -8
    RHS       R944                39
    RHS       R945                23
    RHS       R946               -66
    RHS       R947               -82
    RHS       R948               -21
    RHS       R949                -6
    RHS       R950               -97
    RHS       R951                23
    RHS       R952                20
    RHS       R953               -16
    RHS       R954                50
    RHS       R955                -4
    RHS       R956                13
    RHS       R957                58
    RHS       R958                 7
    RHS       R959                -2
    RHS       R960                -1
    RHS       R961               -23
    RHS       R962               137
    RHS       R963                 2
    RHS       R964                14
    RHS       R965               -18
    RHS       R966                50
    RHS       R967                99
    RHS       R968               -13
    RHS       R969                24
    RHS       R970                40
    RHS       R971                12
    RHS       R972               -51
    RHS       R973               -57
    RHS       R974                52
    RHS       R975                -3
    RHS       R976               -18
    RHS       R977                38
    RHS       R978                 2
    RHS       R979                -4
    RHS       R980                58
    RHS       R981                -3
    RHS       R982               -33
    RHS       R983                34
    RHS       R984                24
    RHS       R985                 3
    RHS       R986                 7
    RHS       R987                -8
    RHS       R988                -7
    RHS       R989                 2
    RHS       R990                35
    RHS       R991                99
    RHS       R992                56
    RHS       R993                35
    RHS       R994              -107
    RHS       R995                98
    RHS       R996               148
    RHS       R997               -36
    RHS       R998                30
    RHS       R999                 7
    RHS       R1000              -51
    RHS       R1001              -46
    RHS       R1002               26
    RHS       R1003               50
    RHS       R1004               56
    RHS       R1005              -82
    RHS       R1006               29
    RHS       R1007               61
    RHS       R1008               20
    RHS       R1009             -118
    RHS       R1010               33
    RHS       R1011              -48
    RHS       R1012               38
    RHS       R1013              -52
    RHS       R1014               50
    RHS       R1015              -50
    RHS       R1016               81
    RHS       R1017                9
    RHS       R1018                7
    RHS       R1019               51
    RHS       R1020              -57
    RHS       R1021               -8
    RHS       R1022              -64
    RHS       R1023              -89
    RHS       R1024              -70
    RHS       R1025              -65
    RHS       R1026               29
    RHS       R1027                0
    RHS       R1028              -68
    RHS       R1029               53
    RHS       R1030              -24
    RHS       R1031              -95
    RHS       R1032               39
    RHS       R1033                7
    RHS       R1034              -67
    RHS       R1035              -13
    RHS       R1036              -98
    RHS       R1037               17
    RHS       R1038                0
    RHS       R1039               39
    RHS       R1040               42
    RHS       R1041               -4
    RHS       R1042               36
    RHS       R1043               -6
    RHS       R1044               11
    RHS       R1045              -92
    RHS       R1046               32
    RHS       R1047              107
    RHS       R1048                3
    RHS       R1049               69
    RHS       R1050               11
    RHS       R1051              160
    RHS       R1052              -26
    RHS       R1053               10
    RHS       R1054              -87
    RHS       R1055              -24
    RHS       R1056             -117
    RHS       R1057              -24
    RHS       R1058              -38
    RHS       R1059              -58
    RHS       R1060              -13
    RHS       R1061              -36
    RHS       R1062               32
    RHS       R1063               80
    RHS       R1064              -25
    RHS       R1065               93
    RHS       R1066               39
    RHS       R1067               21
    RHS       R1068               17
    RHS       R1069               27
    RHS       R1070               34
    RHS       R1071              -21
    RHS       R1072               35
    RHS       R1073               59
    RHS       R1074              -31
    RHS       R1075                0
    RHS       R1076               23
    RHS       R1077               -3
    RHS       R1078               42
    RHS       R1079             -124
    RHS       R1080              -12
    RHS       R1081             -144
    RHS       R1082              -54
    RHS       R1083               66
    RHS       R1084              -30
    RHS       R1085              -17
    RHS       R1086               29
    RHS       R1087              -16
    RHS       R1088              -24
    RHS       R1089               54
    RHS       R1090              106
    RHS       R1091              -44
    RHS       R1092              -51
    RHS       R1093              -47
    RHS       R1094               -4
    RHS       R1095              -25
    RHS       R1096               48
    RHS       R1097              -40
    RHS       R1098              -11
    RHS       R1099              -63
    RHS       R1100               -1
    RHS       R1101               -2
    RHS       R1102              -62
    RHS       R1103              -72
    RHS       R1104                0
    RHS       R1105               55
    RHS       R1106               21
    RHS       R1107              -35
    RHS       R1108                0
    RHS       R1109               31
    RHS       R1110              -20
    RHS       R1111               34
    RHS       R1112              -37
    RHS       R1113              100
    RHS       R1114              -85
    RHS       R1115                7
    RHS       R1116              -69
    RHS       R1117              -28
    RHS       R1118              -40
    RHS       R1119               21
    RHS       R1120               56
    RHS       R1121              -40
    RHS       R1122               -2
    RHS       R1123              -15
    RHS       R1124               22
    RHS       R1125               -5
    RHS       R1126              -31
    RHS       R1127              -36
    RHS       R1128              -13
    RHS       R1129                7
    RHS       R1130               65
    RHS       R1131              -47
    RHS       R1132               15
    RHS       R1133               24
    RHS       R1134              -29
    RHS       R1135               48
    RHS       R1136              -25
    RHS       R1137              -48
    RHS       R1138              -17
    RHS       R1139               36
    RHS       R1140              -15
    RHS       R1141               12
    RHS       R1142              -11
    RHS       R1143               42
    RHS       R1144              -16
    RHS       R1145               30
    RHS       R1146               75
    RHS       R1147                9
    RHS       R1148              -12
    RHS       R1149               60
    RHS       R1150                3
    RHS       R1151               84
    RHS       R1152              -45
    RHS       R1153              -19
    RHS       R1154               78
    RHS       R1155                5
    RHS       R1156              -14
    RHS       R1157               46
    RHS       R1158                7
    RHS       R1159               53
    RHS       R1160               17
    RHS       R1161                0
    RHS       R1162              104
    RHS       R1163              -38
    RHS       R1164             -108
    RHS       R1165              -38
    RHS       R1166               -4
    RHS       R1167               91
    RHS       R1168              -13
    RHS       R1169              -40
    RHS       R1170              -48
    RHS       R1171               17
    RHS       R1172              -24
    RHS       R1173              -31
    RHS       R1174               -3
    RHS       R1175               73
    RHS       R1176               68
    RHS       R1177              -21
    RHS       R1178              -10
    RHS       R1179              -32
    RHS       R1180                4
    RHS       R1181              -16
    RHS       R1182               41
    RHS       R1183               44
    RHS       R1184              -86
    RHS       R1185               81
    RHS       R1186              -42
    RHS       R1187               -1
    RHS       R1188                0
    RHS       R1189               39
    RHS       R1190              -31
    RHS       R1191               -5
    RHS       R1192              -37
    RHS       R1193               -9
    RHS       R1194               47
    RHS       R1195             -111
    RHS       R1196               -3
    RHS       R1197               40
    RHS       R1198               25
    RHS       R1199               33
    RHS       R1200              -15
    RHS       R1201               -8
    RHS       R1202               -3
    RHS       R1203              -27
    RHS       R1204                6
    RHS       R1205               79
    RHS       R1206              -90
    RHS       R1207              -38
    RHS       R1208               -8
    RHS       R1209               -9
    RHS       R1210              -49
    RHS       R1211               -9
    RHS       R1212               24
    RHS       R1213               63
    RHS       R1214              -32
    RHS       R1215               74
    RHS       R1216              -14
    RHS       R1217               21
    RHS       R1218               22
    RHS       R1219             -113
    RHS       R1220              -30
    RHS       R1221               29
    RHS       R1222              -26
    RHS       R1223               39
    RHS       R1224                1
    RHS       R1225              -96
    RHS       R1226              -51
    RHS       R1227               21
    RHS       R1228              -66
    RHS       R1229               78
    RHS       R1230               34
    RHS       R1231                8
    RHS       R1232              -48
    RHS       R1233               -1
    RHS       R1234               16
    RHS       R1235              -42
    RHS       R1236               -2
    RHS       R1237              -72
    RHS       R1238               13
    RHS       R1239              -25
    RHS       R1240               21
    RHS       R1241              -20
    RHS       R1242               -6
    RHS       R1243               19
    RHS       R1244              104
    RHS       R1245              -26
    RHS       R1246               40
    RHS       R1247               -7
    RHS       R1248              -13
    RHS       R1249              -51
    RHS       R1250               -5
    RHS       R1251              -21
    RHS       R1252             -203
    RHS       R1253               12
    RHS       R1254               14
    RHS       R1255              -20
    RHS       R1256               -4
    RHS       R1257              -39
    RHS       R1258               -4
    RHS       R1259               72
    RHS       R1260              -79
    RHS       R1261              -98
    RHS       R1262               46
    RHS       R1263              -16
    RHS       R1264               13
    RHS       R1265              -33
    RHS       R1266              -27
    RHS       R1267             -144
    RHS       R1268               17
    RHS       R1269              -28
    RHS       R1270                4
    RHS       R1271               21
    RHS       R1272               -9
    RHS       R1273               10
    RHS       R1274                0
    RHS       R1275                0
    RHS       R1276                0
    RHS       R1277               44
    RHS       R1278               -2
    RHS       R1279               14
    RHS       R1280               41
    RHS       R1281               56
    RHS       R1282              122
    RHS       R1283               -4
    RHS       R1284               28
    RHS       R1285                5
    RHS       R1286              -47
    RHS       R1287              -73
    RHS       R1288              -36
    RHS       R1289              110
    RHS       R1290               79
    RHS       R1291               -2
    RHS       R1292               -2
    RHS       R1293               -7
    RHS       R1294              -45
    RHS       R1295               -3
    RHS       R1296                7
    RHS       R1297               24
    RHS       R1298              -45
    RHS       R1299             -171
    RHS       R1300             -121
    RHS       R1301               24
    RHS       R1302                5
    RHS       R1303                1
    RHS       R1304                5
    RHS       R1305              -16
    RHS       R1306              -24
    RHS       R1307              117
    RHS       R1308               12
    RHS       R1309               24
    RHS       R1310               29
    RHS       R1311               60
    RHS       R1312                3
    RHS       R1313               -4
    RHS       R1314               23
    RHS       R1315              -16
    RHS       R1316              -74
    RHS       R1317              -72
    RHS       R1318               35
    RHS       R1319               30
    RHS       R1320              -35
    RHS       R1321               -8
    RHS       R1322               72
    RHS       R1323               53
    RHS       R1324                8
    RHS       R1325               18
    RHS       R1326               24
    RHS       R1327               70
    RHS       R1328               15
    RHS       R1329               30
    RHS       R1330               39
    RHS       R1331                8
    RHS       R1332               25
    RHS       R1333              -58
    RHS       R1334              -11
    RHS       R1335              144
    RHS       R1336               41
    RHS       R1337                2
    RHS       R1338              -90
    RHS       R1339               39
    RHS       R1340              -10
    RHS       R1341               32
    RHS       R1342             -157
    RHS       R1343              -97
    RHS       R1344               57
    RHS       R1345              -14
    RHS       R1346              -41
    RHS       R1347               39
    RHS       R1348              -13
    RHS       R1349              -49
    RHS       R1350              -50
    RHS       R1351              -84
    RHS       R1352               67
    RHS       R1353              -21
    RHS       R1354              -17
    RHS       R1355              -59
    RHS       R1356               79
    RHS       R1357               62
    RHS       R1358               -1
    RHS       R1359              -11
    RHS       R1360               32
    RHS       R1361                0
    RHS       R1362              -66
    RHS       R1363              -29
    RHS       R1364               16
    RHS       R1365               17
    RHS       R1366             -113
    RHS       R1367              -34
    RHS       R1368              -36
    RHS       R1369              -19
    RHS       R1370               72
    RHS       R1371               -3
    RHS       R1372               17
    RHS       R1373                5
    RHS       R1374              -29
    RHS       R1375               -1
    RHS       R1376              -73
    RHS       R1377                0
    RHS       R1378              -77
    RHS       R1379              -84
    RHS       R1380              -40
    RHS       R1381               -6
    RHS       R1382               24
    RHS       R1383              -13
    RHS       R1384              -93
    RHS       R1385              -71
    RHS       R1386                3
    RHS       R1387               -4
    RHS       R1388                0
    RHS       R1389               49
    RHS       R1390              -33
    RHS       R1391               73
    RHS       R1392               48
    RHS       R1393               39
    RHS       R1394              150
    RHS       R1395              -62
    RHS       R1396              -69
    RHS       R1397              -53
    RHS       R1398              -77
    RHS       R1399                4
    RHS       R1400              -24
    RHS       R1401               18
    RHS       R1402              -67
    RHS       R1403               -1
    RHS       R1404              -88
    RHS       R1405              -20
    RHS       R1406               22
    RHS       R1407               -7
    RHS       R1408               69
    RHS       R1409              -86
    RHS       R1410              -90
    RHS       R1411              -22
    RHS       R1412              -37
    RHS       R1413              -19
    RHS       R1414               49
    RHS       R1415              -48
    RHS       R1416               42
    RHS       R1417               88
    RHS       R1418               57
    RHS       R1419               50
    RHS       R1420              -22
    RHS       R1421                0
    RHS       R1422                2
    RHS       R1423                6
    RHS       R1424              -25
    RHS       R1425               39
    RHS       R1426               33
    RHS       R1427               30
    RHS       R1428               32
    RHS       R1429               36
    RHS       R1430               52
    RHS       R1431               -1
    RHS       R1432              -54
    RHS       R1433               40
    RHS       R1434                7
    RHS       R1435              -54
    RHS       R1436                0
    RHS       R1437              -19
    RHS       R1438               34
    RHS       R1439               -2
    RHS       R1440               15
    RHS       R1441              -48
    RHS       R1442              -32
    RHS       R1443               22
    RHS       R1444               28
    RHS       R1445              -14
    RHS       R1446               -5
    RHS       R1447              -54
    RHS       R1448              -19
    RHS       R1449              -11
    RHS       R1450              -38
    RHS       R1451              -54
    RHS       R1452              106
    RHS       R1453              -81
    RHS       R1454               18
    RHS       R1455              -39
    RHS       R1456              -30
    RHS       R1457               -4
    RHS       R1458               26
    RHS       R1459               90
    RHS       R1460                2
    RHS       R1461              -99
    RHS       R1462             -120
    RHS       R1463              -36
    RHS       R1464               12
    RHS       R1465              -19
    RHS       R1466              -48
    RHS       R1467              -56
    RHS       R1468               -1
    RHS       R1469               11
    RHS       R1470              -50
    RHS       R1471               29
    RHS       R1472              -34
    RHS       R1473                7
    RHS       R1474              -33
    RHS       R1475              113
    RHS       R1476               44
    RHS       R1477               80
    RHS       R1478              -57
    RHS       R1479               16
    RHS       R1480              -18
    RHS       R1481               -9
    RHS       R1482              -33
    RHS       R1483               56
    RHS       R1484               10
    RHS       R1485               -8
    RHS       R1486               -3
    RHS       R1487              -46
    RHS       R1488              -27
    RHS       R1489               -9
    RHS       R1490               34
    RHS       R1491              -14
    RHS       R1492               21
    RHS       R1493               70
    RHS       R1494               10
    RHS       R1495                4
    RHS       R1496               23
    RHS       R1497              -26
    RHS       R1498               17
    RHS       R1499                2
    RHS       R1500                0
    RHS       R1501                0
    RHS       R1502               78
    RHS       R1503               -1
    RHS       R1504               42
    RHS       R1505                1
    RHS       R1506                0
    RHS       R1507               15
    RHS       R1508                1
    RHS       R1509               21
    RHS       R1510               10
    RHS       R1511              -22
    RHS       R1512               -2
    RHS       R1513               -9
    RHS       R1514              -33
    RHS       R1515              -42
    RHS       R1516                0
    RHS       R1517              -16
    RHS       R1518               -9
    RHS       R1519               -4
    RHS       R1520               -1
    RHS       R1521              -25
    RHS       R1522               72
    RHS       R1523              -27
    RHS       R1524               -4
    RHS       R1525               73
    RHS       R1526              -94
    RHS       R1527              -24
    RHS       R1528                5
    RHS       R1529               58
    RHS       R1530               28
    RHS       R1531               29
    RHS       R1532                6
    RHS       R1533               -1
    RHS       R1534                5
    RHS       R1535               -2
    RHS       R1536              -40
    RHS       R1537               41
    RHS       R1538              -52
    RHS       R1539              -46
    RHS       R1540               -7
    RHS       R1541              -60
    RHS       R1542               52
    RHS       R1543                9
    RHS       R1544               30
    RHS       R1545                6
    RHS       R1546              -30
    RHS       R1547                0
    RHS       R1548               40
    RHS       R1549               16
    RHS       R1550             -115
    RHS       R1551               23
    RHS       R1552               -4
    RHS       R1553              -33
    RHS       R1554              -20
    RHS       R1555               22
    RHS       R1556                0
    RHS       R1557               22
    RHS       R1558              -28
    RHS       R1559               12
    RHS       R1560               -3
    RHS       R1561              -61
    RHS       R1562                3
    RHS       R1563              -39
    RHS       R1564               18
    RHS       R1565              -64
    RHS       R1566              -27
    RHS       R1567              -33
    RHS       R1568               19
    RHS       R1569              105
    RHS       R1570                6
    RHS       R1571                1
    RHS       R1572               75
    RHS       R1573               15
    RHS       R1574                0
    RHS       R1575                7
    RHS       R1576              -21
    RHS       R1577               15
    RHS       R1578               72
    RHS       R1579              -11
    RHS       R1580               -7
    RHS       R1581               80
    RHS       R1582              126
    RHS       R1583                0
    RHS       R1584               38
    RHS       R1585               40
    RHS       R1586              -26
    RHS       R1587             -259
    RHS       R1588              -49
    RHS       R1589               24
    RHS       R1590               98
    RHS       R1591              -27
    RHS       R1592               20
    RHS       R1593              -43
    RHS       R1594               30
    RHS       R1595               -4
    RHS       R1596               37
    RHS       R1597              -20
    RHS       R1598             -128
    RHS       R1599               46
    RHS       R1600               -4
    RHS       R1601              -30
    RHS       R1602              -12
    RHS       R1603              -76
    RHS       R1604               26
    RHS       R1605              -57
    RHS       R1606              -56
    RHS       R1607               23
    RHS       R1608              -16
    RHS       R1609               30
    RHS       R1610               16
    RHS       R1611               49
    RHS       R1612              -40
    RHS       R1613              -37
    RHS       R1614              -20
    RHS       R1615              -10
    RHS       R1616               -8
    RHS       R1617              -15
    RHS       R1618               41
    RHS       R1619              -17
    RHS       R1620              -51
    RHS       R1621              -16
    RHS       R1622               -2
    RHS       R1623             -127
    RHS       R1624                2
    RHS       R1625              -28
    RHS       R1626              -52
    RHS       R1627               -4
    RHS       R1628               53
    RHS       R1629              -22
    RHS       R1630              -93
    RHS       R1631               60
    RHS       R1632              -24
    RHS       R1633              -46
    RHS       R1634              -72
    RHS       R1635               77
    RHS       R1636               31
    RHS       R1637              -34
    RHS       R1638               13
    RHS       R1639              -50
    RHS       R1640               -6
    RHS       R1641               71
    RHS       R1642               15
    RHS       R1643               -1
    RHS       R1644               11
    RHS       R1645                5
    RHS       R1646               -9
    RHS       R1647                6
    RHS       R1648               16
    RHS       R1649              -40
    RHS       R1650                0
    RHS       R1651               -9
    RHS       R1652               -6
    RHS       R1653               -2
    RHS       R1654               51
    RHS       R1655               61
    RHS       R1656              -36
    RHS       R1657              -60
    RHS       R1658              -10
    RHS       R1659              -11
    RHS       R1660              -21
    RHS       R1661              -36
    RHS       R1662              -69
    RHS       R1663                9
    RHS       R1664              -51
    RHS       R1665              -19
    RHS       R1666               21
    RHS       R1667               -3
    RHS       R1668              -28
    RHS       R1669               70
    RHS       R1670                0
    RHS       R1671               -2
    RHS       R1672             -113
    RHS       R1673               57
    RHS       R1674              140
    RHS       R1675              -78
    RHS       R1676              -60
    RHS       R1677              -12
    RHS       R1678               12
    RHS       R1679               -2
    RHS       R1680               29
    RHS       R1681               34
    RHS       R1682              -21
    RHS       R1683              -56
    RHS       R1684               -4
    RHS       R1685               32
    RHS       R1686               17
    RHS       R1687                5
    RHS       R1688              -23
    RHS       R1689               41
    RHS       R1690               96
    RHS       R1691                0
    RHS       R1692               11
    RHS       R1693               26
    RHS       R1694              -47
    RHS       R1695                2
    RHS       R1696              -54
    RHS       R1697               -1
    RHS       R1698               63
    RHS       R1699               53
    RHS       R1700             -182
    RHS       R1701               -2
    RHS       R1702              -46
    RHS       R1703               -1
    RHS       R1704               -2
    RHS       R1705               48
    RHS       R1706               41
    RHS       R1707                8
    RHS       R1708               11
    RHS       R1709               28
    RHS       R1710               15
    RHS       R1711              -12
    RHS       R1712              -31
    RHS       R1713              104
    RHS       R1714               -1
    RHS       R1715               28
    RHS       R1716               75
    RHS       R1717               36
    RHS       R1718              -40
    RHS       R1719             -170
    RHS       R1720               30
    RHS       R1721              -70
    RHS       R1722              -88
    RHS       R1723               54
    RHS       R1724               -2
    RHS       R1725              -42
    RHS       R1726              -54
    RHS       R1727                0
    RHS       R1728              -54
    RHS       R1729              -13
    RHS       R1730               24
    RHS       R1731              -12
    RHS       R1732              -64
    RHS       R1733               63
    RHS       R1734               39
    RHS       R1735              -13
    RHS       R1736              -46
    RHS       R1737               26
    RHS       R1738               36
    RHS       R1739              -51
    RHS       R1740               -7
    RHS       R1741               -7
    RHS       R1742               -3
    RHS       R1743              -59
    RHS       R1744               56
    RHS       R1745              -39
    RHS       R1746               12
    RHS       R1747               14
    RHS       R1748               61
    RHS       R1749             -154
    RHS       R1750               40
    RHS       R1751                2
    RHS       R1752               69
    RHS       R1753              -57
    RHS       R1754               23
    RHS       R1755               56
    RHS       R1756                6
    RHS       R1757                7
    RHS       R1758              -31
    RHS       R1759              -36
    RHS       R1760               -6
    RHS       R1761              -12
    RHS       R1762              -28
    RHS       R1763              -39
    RHS       R1764                9
    RHS       R1765              -44
    RHS       R1766               53
    RHS       R1767              -33
    RHS       R1768               -9
    RHS       R1769              -17
    RHS       R1770               -9
    RHS       R1771               12
    RHS       R1772              -26
    RHS       R1773                5
    RHS       R1774                0
    RHS       R1775              -19
    RHS       R1776                0
    RHS       R1777              -29
    RHS       R1778               49
    RHS       R1779              -48
    RHS       R1780              -85
    RHS       R1781              148
    RHS       R1782              -36
    RHS       R1783               66
    RHS       R1784             -157
    RHS       R1785              -30
    RHS       R1786               71
    RHS       R1787               90
    RHS       R1788               12
    RHS       R1789              -32
    RHS       R1790              -66
    RHS       R1791              -32
    RHS       R1792              -62
    RHS       R1793              -18
    RHS       R1794              -81
    RHS       R1795               34
    RHS       R1796               10
    RHS       R1797              -59
    RHS       R1798                8
    RHS       R1799               37
    RHS       R1800                0
    RHS       R1801              -32
    RHS       R1802               42
    RHS       R1803               10
    RHS       R1804               42
    RHS       R1805              -16
    RHS       R1806                4
    RHS       R1807              -41
    RHS       R1808               -1
    RHS       R1809               73
    RHS       R1810              -44
    RHS       R1811               47
    RHS       R1812               32
    RHS       R1813               53
    RHS       R1814              -35
    RHS       R1815               -3
    RHS       R1816               24
    RHS       R1817                8
    RHS       R1818                1
    RHS       R1819              -14
    RHS       R1820               -4
    RHS       R1821               62
    RHS       R1822              -52
    RHS       R1823               53
    RHS       R1824               79
    RHS       R1825                0
    RHS       R1826               63
    RHS       R1827              -50
    RHS       R1828              -82
    RHS       R1829              -28
    RHS       R1830             -133
    RHS       R1831              -24
    RHS       R1832               32
    RHS       R1833              -21
    RHS       R1834                9
    RHS       R1835               30
    RHS       R1836               73
    RHS       R1837               90
    RHS       R1838              -97
    RHS       R1839              -13
    RHS       R1840             -113
    RHS       R1841              -76
    RHS       R1842               42
    RHS       R1843              -47
    RHS       R1844              -46
    RHS       R1845              -56
    RHS       R1846              -13
    RHS       R1847               32
    RHS       R1848                4
    RHS       R1849                2
    RHS       R1850               39
    RHS       R1851              -43
    RHS       R1852               62
    RHS       R1853              -54
    RHS       R1854              -18
    RHS       R1855              -11
    RHS       R1856             -139
    RHS       R1857              130
    RHS       R1858              -78
    RHS       R1859              -84
    RHS       R1860              -42
    RHS       R1861              -38
    RHS       R1862               97
    RHS       R1863               32
    RHS       R1864              126
    RHS       R1865               34
    RHS       R1866               24
    RHS       R1867              -15
    RHS       R1868              -46
    RHS       R1869               35
    RHS       R1870                0
    RHS       R1871              -61
    RHS       R1872                0
    RHS       R1873              -12
    RHS       R1874              -17
    RHS       R1875               67
    RHS       R1876               55
    RHS       R1877             -110
    RHS       R1878              -61
    RHS       R1879               64
    RHS       R1880               -2
    RHS       R1881              -40
    RHS       R1882               -3
    RHS       R1883              -64
    RHS       R1884                0
    RHS       R1885              -36
    RHS       R1886              -18
    RHS       R1887               63
    RHS       R1888              -32
    RHS       R1889                9
    RHS       R1890              -36
    RHS       R1891              -44
    RHS       R1892               58
    RHS       R1893              162
    RHS       R1894              -28
    RHS       R1895               -6
    RHS       R1896                4
    RHS       R1897              -67
    RHS       R1898              -47
    RHS       R1899               10
    RHS       R1900              -14
    RHS       R1901              -43
    RHS       R1902               21
    RHS       R1903               25
    RHS       R1904               56
    RHS       R1905                5
    RHS       R1906               37
    RHS       R1907               19
    RHS       R1908              -63
    RHS       R1909               35
    RHS       R1910               12
    RHS       R1911              -44
    RHS       R1912              129
    RHS       R1913              106
    RHS       R1914              -15
    RHS       R1915               34
    RHS       R1916              -40
    RHS       R1917               50
    RHS       R1918              -57
    RHS       R1919              -22
    RHS       R1920              -86
    RHS       R1921               21
    RHS       R1922               -6
    RHS       R1923                0
    RHS       R1924               -3
    RHS       R1925              -13
    RHS       R1926                0
    RHS       R1927             -108
    RHS       R1928               -6
    RHS       R1929              -77
    RHS       R1930                6
    RHS       R1931                9
    RHS       R1932               25
    RHS       R1933               -3
    RHS       R1934               59
    RHS       R1935              -10
    RHS       R1936              115
    RHS       R1937               28
    RHS       R1938               30
    RHS       R1939               34
    RHS       R1940                0
    RHS       R1941              -41
    RHS       R1942               -3
    RHS       R1943               42
    RHS       R1944                6
    RHS       R1945               40
    RHS       R1946              -90
    RHS       R1947             -116
    RHS       R1948             -195
    RHS       R1949              111
    RHS       R1950               64
    RHS       R1951               35
    RHS       R1952               -4
    RHS       R1953               -3
    RHS       R1954              -95
    RHS       R1955               31
    RHS       R1956               -2
    RHS       R1957              -69
    RHS       R1958               50
    RHS       R1959               52
    RHS       R1960                0
    RHS       R1961               -1
    RHS       R1962              -34
    RHS       R1963               25
    RHS       R1964               81
    RHS       R1965               29
    RHS       R1966                9
    RHS       R1967                3
    RHS       R1968              -30
    RHS       R1969                7
    RHS       R1970              -39
    RHS       R1971               57
    RHS       R1972               49
    RHS       R1973              -12
    RHS       R1974              -40
    RHS       R1975               -4
    RHS       R1976              -72
    RHS       R1977               41
    RHS       R1978               37
    RHS       R1979              -20
    RHS       R1980               56
    RHS       R1981               57
    RHS       R1982               -7
    RHS       R1983                6
    RHS       R1984              -22
    RHS       R1985              -22
    RHS       R1986                0
    RHS       R1987               61
    RHS       R1988              -66
    RHS       R1989             -154
    RHS       R1990                0
    RHS       R1991               68
    RHS       R1992               54
    RHS       R1993               -8
    RHS       R1994             -105
    RHS       R1995               66
    RHS       R1996               14
    RHS       R1997                7
    RHS       R1998               29
    RHS       R1999               53
    RHS       R2000               96
    RHS       R2001               77
    RHS       R2002               69
    RHS       R2003               24
    RHS       R2004              -30
    RHS       R2005               14
    RHS       R2006               10
    RHS       R2007                6
    RHS       R2008                0
    RHS       R2009              -20
    RHS       R2010              -21
    RHS       R2011              -76
    RHS       R2012              -54
    RHS       R2013               60
    RHS       R2014               70
    RHS       R2015                9
    RHS       R2016               34
    RHS       R2017               18
    RHS       R2018               31
    RHS       R2019              -14
    RHS       R2020               35
    RHS       R2021              -58
    RHS       R2022              -53
    RHS       R2023              146
    RHS       R2024               44
    RHS       R2025                8
    RHS       R2026               12
    RHS       R2027               -5
    RHS       R2028                2
    RHS       R2029              -95
    RHS       R2030              -35
    RHS       R2031               27
    RHS       R2032               81
    RHS       R2033             -136
    RHS       R2034               81
    RHS       R2035               14
    RHS       R2036              -12
    RHS       R2037               11
    RHS       R2038              -31
    RHS       R2039               39
    RHS       R2040               35
    RHS       R2041              -75
    RHS       R2042               71
    RHS       R2043               27
    RHS       R2044               12
    RHS       R2045               49
    RHS       R2046                4
    RHS       R2047               -5
    RHS       R2048              108
    RHS       R2049               25
    RHS       R2050             -135
    RHS       R2051                3
    RHS       R2052              -54
    RHS       R2053               13
    RHS       R2054              -30
    RHS       R2055               52
    RHS       R2056              -50
    RHS       R2057              109
    RHS       R2058               15
    RHS       R2059              -32
    RHS       R2060             -194
    RHS       R2061               67
    RHS       R2062               37
    RHS       R2063                8
    RHS       R2064               52
    RHS       R2065               27
    RHS       R2066               -4
    RHS       R2067              -40
    RHS       R2068               32
    RHS       R2069              -37
    RHS       R2070              -10
    RHS       R2071               54
    RHS       R2072              -51
    RHS       R2073               -5
    RHS       R2074              -51
    RHS       R2075               67
    RHS       R2076               37
    RHS       R2077              -49
    RHS       R2078               91
    RHS       R2079               -4
    RHS       R2080               50
    RHS       R2081               69
    RHS       R2082              -10
    RHS       R2083               -1
    RHS       R2084               24
    RHS       R2085               64
    RHS       R2086                0
    RHS       R2087              -84
    RHS       R2088             -117
    RHS       R2089               55
    RHS       R2090                1
    RHS       R2091              -43
    RHS       R2092              -73
    RHS       R2093              -56
    RHS       R2094               -9
    RHS       R2095              -77
    RHS       R2096                8
    RHS       R2097              -91
    RHS       R2098               -1
    RHS       R2099              -21
    RHS       R2100              -18
    RHS       R2101              130
    RHS       R2102             -105
    RHS       R2103               18
    RHS       R2104               43
    RHS       R2105              -45
    RHS       R2106               63
    RHS       R2107              -12
    RHS       R2108                9
    RHS       R2109               30
    RHS       R2110                9
    RHS       R2111              -11
    RHS       R2112              -45
    RHS       R2113              106
    RHS       R2114              -36
    RHS       R2115               19
    RHS       R2116             -100
    RHS       R2117              -58
    RHS       R2118              -66
    RHS       R2119               62
    RHS       R2120               85
    RHS       R2121              -99
    RHS       R2122                1
    RHS       R2123               99
    RHS       R2124               -1
    RHS       R2125               72
    RHS       R2126              -27
    RHS       R2127                5
    RHS       R2128               12
    RHS       R2129               28
    RHS       R2130                0
    RHS       R2131               11
    RHS       R2132              -32
    RHS       R2133              135
    RHS       R2134               14
    RHS       R2135              -20
    RHS       R2136              -20
    RHS       R2137               53
    RHS       R2138               -4
    RHS       R2139              -19
    RHS       R2140               -3
    RHS       R2141                5
    RHS       R2142               79
    RHS       R2143              -51
    RHS       R2144                0
    RHS       R2145               62
    RHS       R2146               -4
    RHS       R2147              -77
    RHS       R2148              -38
    RHS       R2149              -36
    RHS       R2150               32
    RHS       R2151              -64
    RHS       R2152               48
    RHS       R2153              -56
    RHS       R2154              -12
    RHS       R2155              -39
    RHS       R2156                0
    RHS       R2157              -52
    RHS       R2158               -5
    RHS       R2159               40
    RHS       R2160              -16
    RHS       R2161              -38
    RHS       R2162              -41
    RHS       R2163              -18
    RHS       R2164               -7
    RHS       R2165                1
    RHS       R2166               59
    RHS       R2167              -21
    RHS       R2168               50
    RHS       R2169               -4
    RHS       R2170               -4
    RHS       R2171               52
    RHS       R2172                0
    RHS       R2173              -32
    RHS       R2174               18
    RHS       R2175               13
    RHS       R2176               -4
    RHS       R2177              -67
    RHS       R2178              -23
    RHS       R2179              -35
    RHS       R2180              -43
    RHS       R2181                0
    RHS       R2182               35
    RHS       R2183              127
    RHS       R2184               13
    RHS       R2185                4
    RHS       R2186                6
    RHS       R2187                0
    RHS       R2188               61
    RHS       R2189                6
    RHS       R2190              159
    RHS       R2191             -135
    RHS       R2192               -9
    RHS       R2193               11
    RHS       R2194              -37
    RHS       R2195               47
    RHS       R2196              154
    RHS       R2197               74
    RHS       R2198              -93
    RHS       R2199               33
    RHS       R2200               32
    RHS       R2201               42
    RHS       R2202                4
    RHS       R2203               -4
    RHS       R2204              -16
    RHS       R2205              -60
    RHS       R2206             -100
    RHS       R2207               -4
    RHS       R2208               16
    RHS       R2209               -1
    RHS       R2210              -27
    RHS       R2211               -7
    RHS       R2212              -49
    RHS       R2213               29
    RHS       R2214                3
    RHS       R2215              -60
    RHS       R2216               -6
    RHS       R2217               58
    RHS       R2218               56
    RHS       R2219               23
    RHS       R2220               -7
    RHS       R2221              -10
    RHS       R2222               65
    RHS       R2223              -56
    RHS       R2224              -55
    RHS       R2225              -49
    RHS       R2226               13
    RHS       R2227              -53
    RHS       R2228              -75
    RHS       R2229              -12
    RHS       R2230                5
    RHS       R2231              -17
    RHS       R2232               23
    RHS       R2233               64
    RHS       R2234               -7
    RHS       R2235              -53
    RHS       R2236              -13
    RHS       R2237               63
    RHS       R2238               16
    RHS       R2239               35
    RHS       R2240               67
    RHS       R2241               66
    RHS       R2242             -116
    RHS       R2243               54
    RHS       R2244               11
    RHS       R2245               57
    RHS       R2246               42
    RHS       R2247                9
    RHS       R2248              -57
    RHS       R2249              -93
    RHS       R2250              -31
    RHS       R2251               63
    RHS       R2252              -35
    RHS       R2253                0
    RHS       R2254             -141
    RHS       R2255               43
    RHS       R2256              -17
    RHS       R2257               47
    RHS       R2258               42
    RHS       R2259              -42
    RHS       R2260               -7
    RHS       R2261              -34
    RHS       R2262               20
    RHS       R2263              -45
    RHS       R2264              -32
    RHS       R2265              -62
    RHS       R2266               38
    RHS       R2267              102
    RHS       R2268               21
    RHS       R2269               27
    RHS       R2270              -30
    RHS       R2271              180
    RHS       R2272                0
    RHS       R2273               11
    RHS       R2274              -24
    RHS       R2275               76
    RHS       R2276               73
    RHS       R2277              -20
    RHS       R2278                9
    RHS       R2279                0
    RHS       R2280                0
    RHS       R2281              117
    RHS       R2282              -40
    RHS       R2283              126
    RHS       R2284              107
    RHS       R2285               14
    RHS       R2286              -46
    RHS       R2287               36
    RHS       R2288               55
    RHS       R2289               -7
    RHS       R2290              -17
    RHS       R2291              -56
    RHS       R2292               74
    RHS       R2293              -14
    RHS       R2294               58
    RHS       R2295               61
    RHS       R2296               -7
    RHS       R2297               13
    RHS       R2298               30
    RHS       R2299              -96
    RHS       R2300              -29
    RHS       R2301               -6
    RHS       R2302               13
    RHS       R2303              -27
    RHS       R2304              -65
    RHS       R2305                5
    RHS       R2306               41
    RHS       R2307               -7
    RHS       R2308               13
    RHS       R2309              -77
    RHS       R2310              -14
    RHS       R2311                4
    RHS       R2312               41
    RHS       R2313              115
    RHS       R2314              -16
    RHS       R2315                4
    RHS       R2316               -8
    RHS       R2317               52
    RHS       R2318               64
    RHS       R2319              -13
    RHS       R2320              -32
    RHS       R2321              -94
    RHS       R2322               -3
    RHS       R2323                1
    RHS       R2324               78
    RHS       R2325               54
    RHS       R2326               45
    RHS       R2327               -7
    RHS       R2328              -55
    RHS       R2329              -16
    RHS       R2330               -2
    RHS       R2331               27
    RHS       R2332              -45
    RHS       R2333               10
    RHS       R2334              -23
    RHS       R2335               32
    RHS       R2336              -47
    RHS       R2337               52
    RHS       R2338                0
    RHS       R2339                6
    RHS       R2340              -71
    RHS       R2341                0
    RHS       R2342              -97
    RHS       R2343              -40
    RHS       R2344                7
    RHS       R2345               81
    RHS       R2346                5
    RHS       R2347               24
    RHS       R2348               -4
    RHS       R2349                6
    RHS       R2350               43
    RHS       R2351               53
    RHS       R2352              -75
    RHS       R2353               -5
    RHS       R2354                0
    RHS       R2355               29
    RHS       R2356                0
    RHS       R2357               -3
    RHS       R2358               48
    RHS       R2359             -113
    RHS       R2360               12
    RHS       R2361               50
    RHS       R2362              -89
    RHS       R2363              -65
    RHS       R2364              -48
    RHS       R2365               85
    RHS       R2366                6
    RHS       R2367               17
    RHS       R2368              -25
    RHS       R2369                8
    RHS       R2370              110
    RHS       R2371              -25
    RHS       R2372               12
    RHS       R2373              -85
    RHS       R2374               19
    RHS       R2375               12
    RHS       R2376              -25
    RHS       R2377               10
    RHS       R2378              -58
    RHS       R2379               -7
    RHS       R2380              -38
    RHS       R2381               -4
    RHS       R2382               40
    RHS       R2383               -4
    RHS       R2384               20
    RHS       R2385               25
    RHS       R2386               22
    RHS       R2387                4
    RHS       R2388                4
    RHS       R2389              -26
    RHS       R2390               15
    RHS       R2391              -24
    RHS       R2392              -31
    RHS       R2393              -17
    RHS       R2394               -4
    RHS       R2395              -38
    RHS       R2396              -22
    RHS       R2397              -17
    RHS       R2398               28
    RHS       R2399               -3
    RHS       R2400                0
    RHS       R2401               26
    RHS       R2402              -12
    RHS       R2403               17
    RHS       R2404              -74
    RHS       R2405                0
    RHS       R2406               96
    RHS       R2407              -35
    RHS       R2408              -70
    RHS       R2409               31
    RHS       R2410                0
    RHS       R2411               56
    RHS       R2412             -121
    RHS       R2413              -48
    RHS       R2414              -53
    RHS       R2415             -112
    RHS       R2416              -11
    RHS       R2417              -21
    RHS       R2418               -3
    RHS       R2419             -225
    RHS       R2420               46
    RHS       R2421               48
    RHS       R2422               -1
    RHS       R2423              -18
    RHS       R2424              -27
    RHS       R2425              -45
    RHS       R2426              -66
    RHS       R2427              -77
    RHS       R2428              -77
    RHS       R2429              -96
    RHS       R2430               -4
    RHS       R2431              -96
    RHS       R2432              -32
    RHS       R2433                0
    RHS       R2434             -103
    RHS       R2435                0
    RHS       R2436               18
    RHS       R2437               64
    RHS       R2438              -49
    RHS       R2439              -76
    RHS       R2440               -2
    RHS       R2441              -38
    RHS       R2442                0
    RHS       R2443              -39
    RHS       R2444              -36
    RHS       R2445               94
    RHS       R2446                7
    RHS       R2447              -13
    RHS       R2448                0
    RHS       R2449               23
    RHS       R2450              -39
    RHS       R2451              -85
    RHS       R2452                5
    RHS       R2453              -54
    RHS       R2454               19
    RHS       R2455              -55
    RHS       R2456              -13
    RHS       R2457               55
    RHS       R2458              -32
    RHS       R2459              -24
    RHS       R2460               88
    RHS       R2461              -82
    RHS       R2462              -40
    RHS       R2463               77
    RHS       R2464               23
    RHS       R2465             -169
    RHS       R2466               46
    RHS       R2467             -108
    RHS       R2468               -4
    RHS       R2469               52
    RHS       R2470               14
    RHS       R2471              175
    RHS       R2472               -7
    RHS       R2473               -6
    RHS       R2474              -85
    RHS       R2475               -4
    RHS       R2476              -80
    RHS       R2477              -55
    RHS       R2478              -12
    RHS       R2479              -16
    RHS       R2480              -78
    RHS       R2481              -90
    RHS       R2482               -2
    RHS       R2483               31
    RHS       R2484               50
    RHS       R2485               44
    RHS       R2486               49
    RHS       R2487               95
    RHS       R2488              -12
    RHS       R2489              -43
    RHS       R2490              -48
    RHS       R2491                5
    RHS       R2492              -28
    RHS       R2493              -23
    RHS       R2494               78
    RHS       R2495              -10
    RHS       R2496               31
    RHS       R2497                0
    RHS       R2498               36
    RHS       R2499              -42
    RHS       R2500              -19
    RHS       R2501               66
    RHS       R2502              -30
    RHS       R2503              -55
    RHS       R2504              135
    RHS       R2505               39
    RHS       R2506               11
    RHS       R2507              -25
    RHS       R2508              -16
    RHS       R2509               71
    RHS       R2510                2
    RHS       R2511               -6
    RHS       R2512              -22
    RHS       R2513              -17
    RHS       R2514               -3
    RHS       R2515               12
    RHS       R2516               80
    RHS       R2517              -51
    RHS       R2518                8
    RHS       R2519              -16
    RHS       R2520              -19
    RHS       R2521               -2
    RHS       R2522              -11
    RHS       R2523                5
    RHS       R2524               48
    RHS       R2525              -20
    RHS       R2526              -44
    RHS       R2527               49
    RHS       R2528               86
    RHS       R2529                7
    RHS       R2530                1
    RHS       R2531               17
    RHS       R2532               37
    RHS       R2533               24
    RHS       R2534               -2
    RHS       R2535               20
    RHS       R2536              -63
    RHS       R2537              -24
    RHS       R2538              -18
    RHS       R2539               12
    RHS       R2540                0
    RHS       R2541               -4
    RHS       R2542                6
    RHS       R2543               -2
    RHS       R2544                1
    RHS       R2545               39
    RHS       R2546              139
    RHS       R2547               18
    RHS       R2548               32
    RHS       R2549              154
    RHS       R2550              -48
    RHS       R2551             -127
    RHS       R2552               60
    RHS       R2553                5
    RHS       R2554               22
    RHS       R2555                2
    RHS       R2556              -44
    RHS       R2557                0
    RHS       R2558               -8
    RHS       R2559              -30
    RHS       R2560               -9
    RHS       R2561               78
    RHS       R2562                1
    RHS       R2563              -33
    RHS       R2564              112
    RHS       R2565                0
    RHS       R2566               -1
    RHS       R2567               -9
    RHS       R2568               -6
    RHS       R2569               24
    RHS       R2570              -70
    RHS       R2571               -4
    RHS       R2572               25
    RHS       R2573                2
    RHS       R2574              -15
    RHS       R2575               92
    RHS       R2576              -55
    RHS       R2577               -8
    RHS       R2578                7
    RHS       R2579              -18
    RHS       R2580              -24
    RHS       R2581              139
    RHS       R2582               -9
    RHS       R2583              -33
    RHS       R2584              -97
    RHS       R2585               36
    RHS       R2586                0
    RHS       R2587               -4
    RHS       R2588               49
    RHS       R2589               -8
    RHS       R2590               27
    RHS       R2591               68
    RHS       R2592               50
    RHS       R2593              -17
    RHS       R2594               -9
    RHS       R2595               13
    RHS       R2596               -6
    RHS       R2597              -14
    RHS       R2598               -8
    RHS       R2599               13
    RHS       R2600                7
    RHS       R2601               34
    RHS       R2602               42
    RHS       R2603               28
    RHS       R2604              -14
    RHS       R2605               88
    RHS       R2606                0
    RHS       R2607               60
    RHS       R2608              -38
    RHS       R2609              -28
    RHS       R2610              -30
    RHS       R2611              -61
    RHS       R2612               -4
    RHS       R2613               13
    RHS       R2614               -7
    RHS       R2615              -24
    RHS       R2616               35
    RHS       R2617               12
    RHS       R2618               77
    RHS       R2619                9
    RHS       R2620              -12
    RHS       R2621               11
    RHS       R2622               -1
    RHS       R2623              -45
    RHS       R2624               97
    RHS       R2625                0
    RHS       R2626               36
    RHS       R2627              -50
    RHS       R2628               18
    RHS       R2629              -23
    RHS       R2630              -52
    RHS       R2631               76
    RHS       R2632              -50
    RHS       R2633              -24
    RHS       R2634              -27
    RHS       R2635              -32
    RHS       R2636              -23
    RHS       R2637               -4
    RHS       R2638              -53
    RHS       R2639              -26
    RHS       R2640                5
    RHS       R2641               63
    RHS       R2642               44
    RHS       R2643              112
    RHS       R2644              -44
    RHS       R2645              -50
    RHS       R2646              -49
    RHS       R2647              -80
    RHS       R2648             -122
    RHS       R2649               38
    RHS       R2650                0
    RHS       R2651               21
    RHS       R2652              -22
    RHS       R2653              106
    RHS       R2654               13
    RHS       R2655               -4
    RHS       R2656               57
    RHS       R2657              -41
    RHS       R2658               11
    RHS       R2659              -84
    RHS       R2660               29
    RHS       R2661               36
    RHS       R2662               25
    RHS       R2663               93
    RHS       R2664              -66
    RHS       R2665               -8
    RHS       R2666                6
    RHS       R2667              -52
    RHS       R2668             -112
    RHS       R2669              -17
    RHS       R2670                0
    RHS       R2671                5
    RHS       R2672              -55
    RHS       R2673               17
    RHS       R2674              -52
    RHS       R2675              -74
    RHS       R2676               52
    RHS       R2677               -7
    RHS       R2678               28
    RHS       R2679                2
    RHS       R2680               12
    RHS       R2681                0
    RHS       R2682               47
    RHS       R2683              -18
    RHS       R2684              -47
    RHS       R2685               15
    RHS       R2686              -60
    RHS       R2687                0
    RHS       R2688                0
    RHS       R2689              -24
    RHS       R2690               41
    RHS       R2691              -40
    RHS       R2692               45
    RHS       R2693               61
    RHS       R2694              -38
    RHS       R2695               16
    RHS       R2696              -25
    RHS       R2697              110
    RHS       R2698               13
    RHS       R2699               23
    RHS       R2700                4
    RHS       R2701                1
    RHS       R2702               82
    RHS       R2703               34
    RHS       R2704               21
    RHS       R2705              -40
    RHS       R2706             -146
    RHS       R2707               87
    RHS       R2708               54
    RHS       R2709               13
    RHS       R2710              -51
    RHS       R2711              -18
    RHS       R2712               38
    RHS       R2713              -13
    RHS       R2714              -17
    RHS       R2715               66
    RHS       R2716              -61
    RHS       R2717               84
    RHS       R2718              -77
    RHS       R2719               42
    RHS       R2720               52
    RHS       R2721              -23
    RHS       R2722               16
    RHS       R2723              -17
    RHS       R2724               59
    RHS       R2725               -3
    RHS       R2726              -34
    RHS       R2727                3
    RHS       R2728              -35
    RHS       R2729               40
    RHS       R2730              -12
    RHS       R2731                0
    RHS       R2732               32
    RHS       R2733              -14
    RHS       R2734               40
    RHS       R2735              -48
    RHS       R2736             -105
    RHS       R2737              -10
    RHS       R2738              -23
    RHS       R2739               13
    RHS       R2740               81
    RHS       R2741              148
    RHS       R2742                0
    RHS       R2743              -36
    RHS       R2744               -7
    RHS       R2745              -28
    RHS       R2746                5
    RHS       R2747              -45
    RHS       R2748              -20
    RHS       R2749               46
    RHS       R2750                4
    RHS       R2751               69
    RHS       R2752              -40
    RHS       R2753               64
    RHS       R2754              -74
    RHS       R2755               -4
    RHS       R2756              -34
    RHS       R2757              -43
    RHS       R2758               11
    RHS       R2759              -64
    RHS       R2760              -99
    RHS       R2761              -15
    RHS       R2762                2
    RHS       R2763              -62
    RHS       R2764               54
    RHS       R2765                0
    RHS       R2766              -10
    RHS       R2767               12
    RHS       R2768              -47
    RHS       R2769               56
    RHS       R2770              -26
    RHS       R2771                8
    RHS       R2772               -5
    RHS       R2773              -96
    RHS       R2774                0
    RHS       R2775               -3
    RHS       R2776               43
    RHS       R2777             -138
    RHS       R2778               10
    RHS       R2779                7
    RHS       R2780              -17
    RHS       R2781               27
    RHS       R2782               10
    RHS       R2783               -8
    RHS       R2784               66
    RHS       R2785               87
    RHS       R2786               46
    RHS       R2787              -22
    RHS       R2788              -40
    RHS       R2789              -44
    RHS       R2790               95
    RHS       R2791               44
    RHS       R2792               -2
    RHS       R2793              -54
    RHS       R2794               35
    RHS       R2795               36
    RHS       R2796              -30
    RHS       R2797              -16
    RHS       R2798               33
    RHS       R2799              -36
    RHS       R2800               22
    RHS       R2801              139
    RHS       R2802               35
    RHS       R2803               75
    RHS       R2804               -3
    RHS       R2805               81
    RHS       R2806             -117
    RHS       R2807               54
    RHS       R2808               22
    RHS       R2809               42
    RHS       R2810               -4
    RHS       R2811              -13
    RHS       R2812               74
    RHS       R2813              -25
    RHS       R2814               37
    RHS       R2815             -135
    RHS       R2816               42
    RHS       R2817               -3
    RHS       R2818               -7
    RHS       R2819              -24
    RHS       R2820               88
    RHS       R2821                5
    RHS       R2822                7
    RHS       R2823               59
    RHS       R2824              -12
    RHS       R2825               14
    RHS       R2826              -24
    RHS       R2827               -9
    RHS       R2828              -19
    RHS       R2829              -19
    RHS       R2830                5
    RHS       R2831               -3
    RHS       R2832              -21
    RHS       R2833                0
    RHS       R2834               74
    RHS       R2835               11
    RHS       R2836              -30
    RHS       R2837               87
    RHS       R2838              -33
    RHS       R2839              -19
    RHS       R2840               33
    RHS       R2841               23
    RHS       R2842              -15
    RHS       R2843              116
    RHS       R2844               62
    RHS       R2845              -12
    RHS       R2846                0
    RHS       R2847              -30
    RHS       R2848              -14
    RHS       R2849              -96
    RHS       R2850               56
    RHS       R2851               41
    RHS       R2852              -95
    RHS       R2853               -9
    RHS       R2854              -84
    RHS       R2855               24
    RHS       R2856               15
    RHS       R2857               68
    RHS       R2858               99
    RHS       R2859              -39
    RHS       R2860              -14
    RHS       R2861               14
    RHS       R2862              -17
    RHS       R2863               16
    RHS       R2864              -57
    RHS       R2865               21
    RHS       R2866               11
    RHS       R2867               95
    RHS       R2868               15
    RHS       R2869               12
    RHS       R2870              -27
    RHS       R2871               21
    RHS       R2872              -26
    RHS       R2873               63
    RHS       R2874              -11
    RHS       R2875                3
    RHS       R2876              -32
    RHS       R2877               63
    RHS       R2878              -20
    RHS       R2879               -9
    RHS       R2880              -35
    RHS       R2881                8
    RHS       R2882              -14
    RHS       R2883               20
    RHS       R2884               35
    RHS       R2885                8
    RHS       R2886              -71
    RHS       R2887               14
    RHS       R2888               22
    RHS       R2889               74
    RHS       R2890              102
    RHS       R2891              -26
    RHS       R2892              -10
    RHS       R2893               80
    RHS       R2894              -58
    RHS       R2895              -10
    RHS       R2896                0
    RHS       R2897               14
    RHS       R2898               46
    RHS       R2899               76
    RHS       R2900              -29
    RHS       R2901              -53
    RHS       R2902               -2
    RHS       R2903               51
    RHS       R2904              -56
    RHS       R2905                5
    RHS       R2906               21
    RHS       R2907              -57
    RHS       R2908              131
    RHS       R2909              -13
    RHS       R2910              -20
    RHS       R2911                5
    RHS       R2912               67
    RHS       R2913              148
    RHS       R2914               59
    RHS       R2915               80
    RHS       R2916               62
    RHS       R2917              -53
    RHS       R2918               30
    RHS       R2919              -25
    RHS       R2920              -71
    RHS       R2921               69
    RHS       R2922              -20
    RHS       R2923              -35
    RHS       R2924              -15
    RHS       R2925              -25
    RHS       R2926              -73
    RHS       R2927              -99
    RHS       R2928               15
    RHS       R2929               10
    RHS       R2930                0
    RHS       R2931                6
    RHS       R2932               33
    RHS       R2933              -50
    RHS       R2934               33
    RHS       R2935              -14
    RHS       R2936              -49
    RHS       R2937              -17
    RHS       R2938              110
    RHS       R2939               16
    RHS       R2940              -30
    RHS       R2941              -22
    RHS       R2942              -10
    RHS       R2943               30
    RHS       R2944              -11
    RHS       R2945               32
    RHS       R2946               -2
    RHS       R2947               51
    RHS       R2948               -2
    RHS       R2949               74
    RHS       R2950               15
    RHS       R2951              -34
    RHS       R2952               -6
    RHS       R2953              -25
    RHS       R2954              -84
    RHS       R2955              -93
    RHS       R2956              -21
    RHS       R2957              -59
    RHS       R2958              -36
    RHS       R2959              -16
    RHS       R2960               49
    RHS       R2961               23
    RHS       R2962               28
    RHS       R2963               42
    RHS       R2964              -68
    RHS       R2965               66
    RHS       R2966              -50
    RHS       R2967               -4
    RHS       R2968               26
    RHS       R2969               70
    RHS       R2970              -16
    RHS       R2971               35
    RHS       R2972               -4
    RHS       R2973              -54
    RHS       R2974              -13
    RHS       R2975                3
    RHS       R2976              -36
    RHS       R2977              -48
    RHS       R2978              -59
    RHS       R2979               39
    RHS       R2980              -27
    RHS       R2981               64
    RHS       R2982              -49
    RHS       R2983              -92
    RHS       R2984             -100
    RHS       R2985               -1
    RHS       R2986              -10
    RHS       R2987               30
    RHS       R2988                7
    RHS       R2989              -43
    RHS       R2990               22
    RHS       R2991                9
    RHS       R2992               26
    RHS       R2993              -27
    RHS       R2994              -17
    RHS       R2995              -26
    RHS       R2996               71
    RHS       R2997              -52
    RHS       R2998              -33
    RHS       R2999               54
BOUNDS
 UP BND       X0                   1
 UP BND       X1                   2
 UP BND       X2                   7
 UP BND       X3                   9
 UP BND       X4                   1
 UP BND       X5                  11
 UP BND       X6                   6
 UP BND       X7                   1
 UP BND       X8                   5
 UP BND       X9                   5
 UP BND       X10                  3
 UP BND       X11                  6
 UP BND       X12                  0
 UP BND       X13                  3
 UP BND       X14                  4
 UP BND       X15                  3
 UP BND       X16                  8
 UP BND       X17                  4
 UP BND       X18                  2
 UP BND       X19                  6
 UP BND       X20                 12
 UP BND       X21                  1
 UP BND       X22                  9
 UP BND       X23                  0
 UP BND       X24                  3
 UP BND       X25                  3
 UP BND       X26                  0
 UP BND       X27                  3
 UP BND       X28                  2
 UP BND       X29                  8
 UP BND       X30                  5
 UP BND       X31                 10
 UP BND       X32                  3
 UP BND       X33                  3
 UP BND       X34                  3
 UP BND       X35                 10
 UP BND       X36                  0
 UP BND       X37                  1
 UP BND       X38                  0
 UP BND       X39                  3
 UP BND       X40                  2
 UP BND       X41                  0
 UP BND       X42                  2
 UP BND       X43                 10
 UP BND       X44                  8
 UP BND       X45                  3
 UP BND       X46                 10
 UP BND       X47                 10
 UP BND       X48                  8
 UP BND       X49                 10
 UP BND       X50                  0
 UP BND       X51                  3
 UP BND       X52                  0
 UP BND       X53                  3
 UP BND       X54                  0
 UP BND       X55                  4
 UP BND       X56                  9
 UP BND       X57                  7
 UP BND       X58                  7
 UP BND       X59                  6
 UP BND       X60                  4
 UP BND       X61                  2
 UP BND       X62                  5
 UP BND       X63                  1
 UP BND       X64                 11
 UP BND       X65                  0
 UP BND       X66                  4
 UP BND       X67                  3
 UP BND       X68                  3
 UP BND       X69                  0
 UP BND       X70                 12
 UP BND       X71                  3
 UP BND       X72                  2
 UP BND       X73                  0
 UP BND       X74                  1
 UP BND       X75                  9
 UP BND       X76                 11
 UP BND       X77                  1
 UP BND       X78                 12
 UP BND       X79                  1
 UP BND       X80                  1
 UP BND       X81                  0
 UP BND       X82                  8
 UP BND       X83                  1
 UP BND       X84                  0
 UP BND       X85                  0
 UP BND       X86                  8
 UP BND       X87                  8
 UP BND       X88                  6
 UP BND       X89                  3
 UP BND       X90                  8
 UP BND       X91                  6
 UP BND       X92                  2
 UP BND       X93                  3
 UP BND       X94                 12
 UP BND       X95                  2
 UP BND       X96                  3
 UP BND       X97                  1
 UP BND       X98                  7
 UP BND       X99                  2
 UP BND       X100                 0
 UP BND       X101                 2
 UP BND       X102                 1
 UP BND       X103                 3
 UP BND       X104                 5
 UP BND       X105                 5
 UP BND       X106                 1
 UP BND       X107                 2
 UP BND       X108                12
 UP BND       X109                 2
 UP BND       X110                 2
 UP BND       X111                 6
 UP BND       X112                 3
 UP BND       X113                 1
 UP BND       X114                 1
 UP BND       X115                 9
 UP BND       X116                 8
 UP BND       X117                 4
 UP BND       X118                 8
 UP BND       X119                 8
 UP BND       X120                 3
 UP BND       X121                 3
 UP BND       X122                 4
 UP BND       X123                 2
 UP BND       X124                 6
 UP BND       X125                 7
 UP BND       X126                 3
 UP BND       X127                 2
 UP BND       X128                 5
 UP BND       X129                 3
 UP BND       X130                 4
 UP BND       X131                 2
 UP BND       X132                 6
 UP BND       X133                 6
 UP BND       X134                 0
 UP BND       X135                 8
 UP BND       X136                 1
 UP BND       X137                 3
 UP BND       X138                 1
 UP BND       X139                 4
 UP BND       X140                 2
 UP BND       X141                 4
 UP BND       X142                 8
 UP BND       X143                 2
 UP BND       X144                 3
 UP BND       X145                 4
 UP BND       X146                 9
 UP BND       X147                 5
 UP BND       X148                 8
 UP BND       X149                 8
 UP BND       X150                 2
 UP BND       X151                 9
 UP BND       X152                 4
 UP BND       X153                 0
 UP BND       X154                 0
 UP BND       X155                 0
 UP BND       X156                 6
 UP BND       X157                 1
 UP BND       X158                 5
 UP BND       X159                 6
 UP BND       X160                 2
 UP BND       X161                10
 UP BND       X162                 8
 UP BND       X163                 3
 UP BND       X164                 3
 UP BND       X165                 9
 UP BND       X166                 8
 UP BND       X167                 8
 UP BND       X168                10
 UP BND       X169                 1
 UP BND       X170                 0
 UP BND       X171                 3
 UP BND       X172                 2
 UP BND       X173                 0
 UP BND       X174                 3
 UP BND       X175                 3
 UP BND       X176                 3
 UP BND       X177                 9
 UP BND       X178                 6
 UP BND       X179                 3
 UP BND       X180                 0
 UP BND       X181                 2
 UP BND       X182                 3
 UP BND       X183                 0
 UP BND       X184                 1
 UP BND       X185                 7
 UP BND       X186                 3
 UP BND       X187                 0
 UP BND       X188                 9
 UP BND       X189                 3
 UP BND       X190                10
 UP BND       X191                 2
 UP BND       X192                 2
 UP BND       X193                 6
 UP BND       X194                 2
 UP BND       X195                 5
 UP BND       X196                 3
 UP BND       X197                10
 UP BND       X198                 1
 UP BND       X199                 4
 UP BND       X200                10
 UP BND       X201                11
 UP BND       X202                 9
 UP BND       X203                 0
 UP BND       X204                10
 UP BND       X205                 2
 UP BND       X206                 4
 UP BND       X207                 1
 UP BND       X208                 7
 UP BND       X209                 2
 UP BND       X210                 1
 UP BND       X211                 2
 UP BND       X212                 5
 UP BND       X213                 7
 UP BND       X214                12
 UP BND       X215                11
 UP BND       X216                 2
 UP BND       X217                10
 UP BND       X218                 0
 UP BND       X219                 9
 UP BND       X220                 4
 UP BND       X221                 1
 UP BND       X222                 0
 UP BND       X223                10
 UP BND       X224                 0
 UP BND       X225                 1
 UP BND       X226                 8
 UP BND       X227                12
 UP BND       X228                 1
 UP BND       X229                 4
 UP BND       X230                 3
 UP BND       X231                 4
 UP BND       X232                 2
 UP BND       X233                 1
 UP BND       X234                 6
 UP BND       X235                 5
 UP BND       X236                 8
 UP BND       X237                10
 UP BND       X238                 2
 UP BND       X239                 0
 UP BND       X240                 1
 UP BND       X241                 0
 UP BND       X242                 3
 UP BND       X243                 1
 UP BND       X244                 3
 UP BND       X245                 3
 UP BND       X246                 3
 UP BND       X247                 2
 UP BND       X248                 4
 UP BND       X249                 1
 UP BND       X250                 8
 UP BND       X251                 5
 UP BND       X252                 9
 UP BND       X253                 3
 UP BND       X254                 6
 UP BND       X255                 0
 UP BND       X256                 7
 UP BND       X257                 4
 UP BND       X258                 2
 UP BND       X259                 4
 UP BND       X260                 8
 UP BND       X261                 5
 UP BND       X262                 2
 UP BND       X263                 0
 UP BND       X264                 3
 UP BND       X265                11
 UP BND       X266                10
 UP BND       X267                 3
 UP BND       X268                 4
 UP BND       X269                 0
 UP BND       X270                11
 UP BND       X271                 5
 UP BND       X272                 3
 UP BND       X273                 8
 UP BND       X274                 3
 UP BND       X275                 3
 UP BND       X276                 5
 UP BND       X277                 6
 UP BND       X278                 6
 UP BND       X279                 0
 UP BND       X280                 7
 UP BND       X281                 9
 UP BND       X282                 5
 UP BND       X283                 9
 UP BND       X284                 2
 UP BND       X285                 4
 UP BND       X286                 6
 UP BND       X287                 0
 UP BND       X288                 4
 UP BND       X289                 9
 UP BND       X290                 9
 UP BND       X291                 6
 UP BND       X292                 8
 UP BND       X293                 2
 UP BND       X294                 0
 UP BND       X295                 3
 UP BND       X296                 8
 UP BND       X297                 8
 UP BND       X298                 2
 UP BND       X299                 3
 UP BND       X300                 1
 UP BND       X301                 2
 UP BND       X302                 8
 UP BND       X303                 6
 UP BND       X304                 5
 UP BND       X305                 3
 UP BND       X306                 3
 UP BND       X307                 1
 UP BND       X308                 9
 UP BND       X309                 7
 UP BND       X310                 8
 UP BND       X311                10
 UP BND       X312                 2
 UP BND       X313                 1
 UP BND       X314                 1
 UP BND       X315                 9
 UP BND       X316                 6
 UP BND       X317                 4
 UP BND       X318                 5
 UP BND       X319                 0
 UP BND       X320                 1
 UP BND       X321                 4
 UP BND       X322                 0
 UP BND       X323                 0
 UP BND       X324                 1
 UP BND       X325                 1
 UP BND       X326                 2
 UP BND       X327                 8
 UP BND       X328                 2
 UP BND       X329                 1
 UP BND       X330                 7
 UP BND       X331                 0
 UP BND       X332                 5
 UP BND       X333                 9
 UP BND       X334                 0
 UP BND       X335                 3
 UP BND       X336                 0
 UP BND       X337                 8
 UP BND       X338                 7
 UP BND       X339                 3
 UP BND       X340                 6
 UP BND       X341                 2
 UP BND       X342                 1
 UP BND       X343                 3
 UP BND       X344                 5
 UP BND       X345                 5
 UP BND       X346                 1
 UP BND       X347                 6
 UP BND       X348                10
 UP BND       X349                 4
 UP BND       X350                 6
 UP BND       X351                 2
 UP BND       X352                 1
 UP BND       X353                 0
 UP BND       X354                 1
 UP BND       X355                 1
 UP BND       X356                 6
 UP BND       X357                 3
 UP BND       X358                 0
 UP BND       X359                11
 UP BND       X360                 1
 UP BND       X361                 0
 UP BND       X362                 6
 UP BND       X363                 3
 UP BND       X364                 7
 UP BND       X365                 5
 UP BND       X366                 4
 UP BND       X367                 4
 UP BND       X368                 6
 UP BND       X369                 3
 UP BND       X370                 0
 UP BND       X371                 1
 UP BND       X372                 2
 UP BND       X373                 1
 UP BND       X374                 2
 UP BND       X375                 0
 UP BND       X376                 0
 UP BND       X377                10
 UP BND       X378                 5
 UP BND       X379                 3
 UP BND       X380                 0
 UP BND       X381                 2
 UP BND       X382                10
 UP BND       X383                 3
 UP BND       X384                 8
 UP BND       X385                 9
 UP BND       X386                 2
 UP BND       X387                 2
 UP BND       X388                 3
 UP BND       X389                 4
 UP BND       X390                 8
 UP BND       X391                 3
 UP BND       X392                 3
 UP BND       X393                 5
 UP BND       X394                 3
 UP BND       X395                 3
 UP BND       X396                 2
 UP BND       X397                 2
 UP BND       X398                 4
 UP BND       X399                 3
 UP BND       X400                 1
 UP BND       X401                10
 UP BND       X402                 2
 UP BND       X403                 7
 UP BND       X404                 7
 UP BND       X405                 0
 UP BND       X406                 0
 UP BND       X407                 3
 UP BND       X408                 5
 UP BND       X409                 2
 UP BND       X410                 9
 UP BND       X411                 0
 UP BND       X412                 0
 UP BND       X413                 1
 UP BND       X414                 6
 UP BND       X415                11
 UP BND       X416                 6
 UP BND       X417                 2
 UP BND       X418                 6
 UP BND       X419                 3
 UP BND       X420                 0
 UP BND       X421                 2
 UP BND       X422                 0
 UP BND       X423                 0
 UP BND       X424                 8
 UP BND       X425                 9
 UP BND       X426                10
 UP BND       X427                12
 UP BND       X428                 2
 UP BND       X429                 8
 UP BND       X430                 7
 UP BND       X431                 1
 UP BND       X432                 3
 UP BND       X433                 0
 UP BND       X434                 8
 UP BND       X435                 3
 UP BND       X436                 5
 UP BND       X437                 6
 UP BND       X438                 5
 UP BND       X439                 2
 UP BND       X440                 2
 UP BND       X441                 8
 UP BND       X442                 2
 UP BND       X443                 1
 UP BND       X444                 0
 UP BND       X445                 1
 UP BND       X446                 2
 UP BND       X447                 0
 UP BND       X448                 0
 UP BND       X449                 1
 UP BND       X450                 9
 UP BND       X451                 8
 UP BND       X452                 8
 UP BND       X453                 4
 UP BND       X454                 9
 UP BND       X455                 5
 UP BND       X456                 0
 UP BND       X457                 1
 UP BND       X458                 1
 UP BND       X459                 3
 UP BND       X460                 2
 UP BND       X461                10
 UP BND       X462                 1
 UP BND       X463                 5
 UP BND       X464                 3
 UP BND       X465                 3
 UP BND       X466                 0
 UP BND       X467                 4
 UP BND       X468                11
 UP BND       X469                 6
 UP BND       X470                 4
 UP BND       X471                11
 UP BND       X472                 0
 UP BND       X473                12
 UP BND       X474                 1
 UP BND       X475                 5
 UP BND       X476                 2
 UP BND       X477                 2
 UP BND       X478                 2
 UP BND       X479                 1
 UP BND       X480                 0
 UP BND       X481                 9
 UP BND       X482                 1
 UP BND       X483                 1
 UP BND       X484                 3
 UP BND       X485                 1
 UP BND       X486                 1
 UP BND       X487                 8
 UP BND       X488                 4
 UP BND       X489                 1
 UP BND       X490                 4
 UP BND       X491                 2
 UP BND       X492                 1
 UP BND       X493                 2
 UP BND       X494                 3
 UP BND       X495                 1
 UP BND       X496                 6
 UP BND       X497                 9
 UP BND       X498                 2
 UP BND       X499                 3
 UP BND       X500                 7
 UP BND       X501                 8
 UP BND       X502                10
 UP BND       X503                 1
 UP BND       X504                 8
 UP BND       X505                 0
 UP BND       X506                 1
 UP BND       X507                 2
 UP BND       X508                 7
 UP BND       X509                 2
 UP BND       X510                 2
 UP BND       X511                11
 UP BND       X512                 5
 UP BND       X513                 1
 UP BND       X514                 5
 UP BND       X515                 4
 UP BND       X516                 1
 UP BND       X517                 2
 UP BND       X518                 8
 UP BND       X519                 9
 UP BND       X520                 2
 UP BND       X521                12
 UP BND       X522                 3
 UP BND       X523                 1
 UP BND       X524                 0
 UP BND       X525                 0
 UP BND       X526                 2
 UP BND       X527                 7
 UP BND       X528                 7
 UP BND       X529                 1
 UP BND       X530                 0
 UP BND       X531                 3
 UP BND       X532                 7
 UP BND       X533                 2
 UP BND       X534                 0
 UP BND       X535                 0
 UP BND       X536                 2
 UP BND       X537                 5
 UP BND       X538                 2
 UP BND       X539                 3
 UP BND       X540                 7
 UP BND       X541                 7
 UP BND       X542                 3
 UP BND       X543                 4
 UP BND       X544                 1
 UP BND       X545                 4
 UP BND       X546                 1
 UP BND       X547                 3
 UP BND       X548                 8
 UP BND       X549                 9
 UP BND       X550                 0
 UP BND       X551                 5
 UP BND       X552                12
 UP BND       X553                 6
 UP BND       X554                 7
 UP BND       X555                 4
 UP BND       X556                 1
 UP BND       X557                 0
 UP BND       X558                 2
 UP BND       X559                 5
 UP BND       X560                 0
 UP BND       X561                 0
 UP BND       X562                 2
 UP BND       X563                 1
 UP BND       X564                 6
 UP BND       X565                 4
 UP BND       X566                 3
 UP BND       X567                 3
 UP BND       X568                 1
 UP BND       X569                 0
 UP BND       X570                 0
 UP BND       X571                 9
 UP BND       X572                 9
 UP BND       X573                 9
 UP BND       X574                 1
 UP BND       X575                 1
 UP BND       X576                 3
 UP BND       X577                 1
 UP BND       X578                 8
 UP BND       X579                 1
 UP BND       X580                 3
 UP BND       X581                10
 UP BND       X582                 1
 UP BND       X583                 4
 UP BND       X584                 9
 UP BND       X585                 7
 UP BND       X586                 7
 UP BND       X587                 7
 UP BND       X588                12
 UP BND       X589                 3
 UP BND       X590                 1
 UP BND       X591                 0
 UP BND       X592                10
 UP BND       X593                 2
 UP BND       X594                 1
 UP BND       X595                 0
 UP BND       X596                12
 UP BND       X597                 9
 UP BND       X598                 2
 UP BND       X599                 2
 UP BND       X600                 2
 UP BND       X601                 3
 UP BND       X602                 1
 UP BND       X603                 5
 UP BND       X604                 9
 UP BND       X605                 2
 UP BND       X606                 3
 UP BND       X607                 2
 UP BND       X608                 2
 UP BND       X609                 0
 UP BND       X610                 0
 UP BND       X611                10
 UP BND       X612                 3
 UP BND       X613                 2
 UP BND       X614                11
 UP BND       X615                 9
 UP BND       X616                 3
 UP BND       X617                 1
 UP BND       X618                 1
 UP BND       X619                 1
 UP BND       X620                 3
 UP BND       X621                 2
 UP BND       X622                 5
 UP BND       X623                 9
 UP BND       X624                 2
 UP BND       X625                 3
 UP BND       X626                 3
 UP BND       X627                 3
 UP BND       X628                 4
 UP BND       X629                 3
 UP BND       X630                 3
 UP BND       X631                 6
 UP BND       X632                 9
 UP BND       X633                 9
 UP BND       X634                 2
 UP BND       X635                 3
 UP BND       X636                10
 UP BND       X637                 2
 UP BND       X638                 5
 UP BND       X639                 3
 UP BND       X640                 0
 UP BND       X641                11
 UP BND       X642                 5
 UP BND       X643                 2
 UP BND       X644                 0
 UP BND       X645                 1
 UP BND       X646                 2
 UP BND       X647                 1
 UP BND       X648                 5
 UP BND       X649                 1
 UP BND       X650                 9
 UP BND       X651                 4
 UP BND       X652                 1
 UP BND       X653                 0
 UP BND       X654                 1
 UP BND       X655                 6
 UP BND       X656                 3
 UP BND       X657                 2
 UP BND       X658                10
 UP BND       X659                 1
 UP BND       X660                 6
 UP BND       X661                 5
 UP BND       X662                 2
 UP BND       X663                 3
 UP BND       X664                 4
 UP BND       X665                 3
 UP BND       X666                10
 UP BND       X667                 0
 UP BND       X668                 2
 UP BND       X669                 0
 UP BND       X670                 6
 UP BND       X671                 3
 UP BND       X672                 3
 UP BND       X673                 1
 UP BND       X674                 7
 UP BND       X675                 0
 UP BND       X676                 4
 UP BND       X677                 2
 UP BND       X678                 3
 UP BND       X679                 3
 UP BND       X680                 5
 UP BND       X681                 2
 UP BND       X682                 8
 UP BND       X683                12
 UP BND       X684                 2
 UP BND       X685                 2
 UP BND       X686                 2
 UP BND       X687                 0
 UP BND       X688                 7
 UP BND       X689                 9
 UP BND       X690                 3
 UP BND       X691                 5
 UP BND       X692                 3
 UP BND       X693                 0
 UP BND       X694                 1
 UP BND       X695                 0
 UP BND       X696                 3
 UP BND       X697                 3
 UP BND       X698                 5
 UP BND       X699                 8
 UP BND       X700                10
 UP BND       X701                 5
 UP BND       X702                 2
 UP BND       X703                11
 UP BND       X704                 2
 UP BND       X705                 1
 UP BND       X706                 8
 UP BND       X707                10
 UP BND       X708                 2
 UP BND       X709                 8
 UP BND       X710                 1
 UP BND       X711                 2
 UP BND       X712                 8
 UP BND       X713                12
 UP BND       X714                11
 UP BND       X715                 3
 UP BND       X716                 2
 UP BND       X717                 0
 UP BND       X718                 3
 UP BND       X719                 1
 UP BND       X720                11
 UP BND       X721                 9
 UP BND       X722                 8
 UP BND       X723                 1
 UP BND       X724                 2
 UP BND       X725                 8
 UP BND       X726                 3
 UP BND       X727                 7
 UP BND       X728                 3
 UP BND       X729                 9
 UP BND       X730                 4
 UP BND       X731                 9
 UP BND       X732                 3
 UP BND       X733                 3
 UP BND       X734                 2
 UP BND       X735                 2
 UP BND       X736                 9
 UP BND       X737                 9
 UP BND       X738                 4
 UP BND       X739                 1
 UP BND       X740                 3
 UP BND       X741                 4
 UP BND       X742                 0
 UP BND       X743                 0
 UP BND       X744                 4
 UP BND       X745                 2
 UP BND       X746                 6
 UP BND       X747                 0
 UP BND       X748                 3
 UP BND       X749                 0
 UP BND       X750                 1
 UP BND       X751                 3
 UP BND       X752                 1
 UP BND       X753                 0
 UP BND       X754                 9
 UP BND       X755                 3
 UP BND       X756                 8
 UP BND       X757                 1
 UP BND       X758                 2
 UP BND       X759                 2
 UP BND       X760                11
 UP BND       X761                 0
 UP BND       X762                 9
 UP BND       X763                 4
 UP BND       X764                 3
 UP BND       X765                 9
 UP BND       X766                 2
 UP BND       X767                 1
 UP BND       X768                 9
 UP BND       X769                 9
 UP BND       X770                 7
 UP BND       X771                 2
 UP BND       X772                 8
 UP BND       X773                 0
 UP BND       X774                 2
 UP BND       X775                 8
 UP BND       X776                 0
 UP BND       X777                 2
 UP BND       X778                 3
 UP BND       X779                 2
 UP BND       X780                 0
 UP BND       X781                 5
 UP BND       X782                 0
 UP BND       X783                 0
 UP BND       X784                 4
 UP BND       X785                 0
 UP BND       X786                 1
 UP BND       X787                 9
 UP BND       X788                 0
 UP BND       X789                 1
 UP BND       X790                 9
 UP BND       X791                10
 UP BND       X792                 0
 UP BND       X793                 4
 UP BND       X794                10
 UP BND       X795                 3
 UP BND       X796                 5
 UP BND       X797                 8
 UP BND       X798                 2
 UP BND       X799                 2
 UP BND       X800                 1
 UP BND       X801                 5
 UP BND       X802                 4
 UP BND       X803                 2
 UP BND       X804                 4
 UP BND       X805                 6
 UP BND       X806                 4
 UP BND       X807                 5
 UP BND       X808                 7
 UP BND       X809                 3
 UP BND       X810                10
 UP BND       X811                 0
 UP BND       X812                 1
 UP BND       X813                 7
 UP BND       X814                 3
 UP BND       X815                 8
 UP BND       X816                12
 UP BND       X817                 3
 UP BND       X818                 9
 UP BND       X819                 0
 UP BND       X820                 0
 UP BND       X821                 2
 UP BND       X822                 2
 UP BND       X823                 8
 UP BND       X824                 0
 UP BND       X825                 3
 UP BND       X826                 4
 UP BND       X827                 2
 UP BND       X828                 1
 UP BND       X829                 5
 UP BND       X830                 5
 UP BND       X831                 2
 UP BND       X832                 9
 UP BND       X833                 3
 UP BND       X834                 0
 UP BND       X835                 1
 UP BND       X836                 4
 UP BND       X837                10
 UP BND       X838                 9
 UP BND       X839                 4
 UP BND       X840                 2
 UP BND       X841                10
 UP BND       X842                10
 UP BND       X843                 3
 UP BND       X844                 2
 UP BND       X845                 2
 UP BND       X846                 0
 UP BND       X847                 2
 UP BND       X848                12
 UP BND       X849                 2
 UP BND       X850                 8
 UP BND       X851                 5
 UP BND       X852                 3
 UP BND       X853                 4
 UP BND       X854                 1
 UP BND       X855                 6
 UP BND       X856                 5
 UP BND       X857                 7
 UP BND       X858                 5
 UP BND       X859                 9
 UP BND       X860                 1
 UP BND       X861                 7
 UP BND       X862                 1
 UP BND       X863                 0
 UP BND       X864                 0
 UP BND       X865                 1
 UP BND       X866                 3
 UP BND       X867                10
 UP BND       X868                 3
 UP BND       X869                12
 UP BND       X870                 2
 UP BND       X871                 3
 UP BND       X872                10
 UP BND       X873                 1
 UP BND       X874                 6
 UP BND       X875                 1
 UP BND       X876                 3
 UP BND       X877                 4
 UP BND       X878                 0
 UP BND       X879                 2
 UP BND       X880                 3
 UP BND       X881                 2
 UP BND       X882                 1
 UP BND       X883                 3
 UP BND       X884                 9
 UP BND       X885                 4
 UP BND       X886                 1
 UP BND       X887                 7
 UP BND       X888                 3
 UP BND       X889                 1
 UP BND       X890                 1
 UP BND       X891                 0
 UP BND       X892                 1
 UP BND       X893                 5
 UP BND       X894                 3
 UP BND       X895                 0
 UP BND       X896                 0
 UP BND       X897                11
 UP BND       X898                 2
 UP BND       X899                 0
 UP BND       X900                 3
 UP BND       X901                 5
 UP BND       X902                 7
 UP BND       X903                12
 UP BND       X904                 3
 UP BND       X905                 3
 UP BND       X906                 9
 UP BND       X907                 2
 UP BND       X908                 7
 UP BND       X909                 0
 UP BND       X910                 1
 UP BND       X911                 4
 UP BND       X912                 0
 UP BND       X913                 7
 UP BND       X914                 3
 UP BND       X915                 3
 UP BND       X916                10
 UP BND       X917                10
 UP BND       X918                 6
 UP BND       X919                10
 UP BND       X920                 3
 UP BND       X921                10
 UP BND       X922                 9
 UP BND       X923                 1
 UP BND       X924                 0
 UP BND       X925                10
 UP BND       X926                 3
 UP BND       X927                 1
 UP BND       X928                 9
 UP BND       X929                 5
 UP BND       X930                 4
 UP BND       X931                 1
 UP BND       X932                 0
 UP BND       X933                 9
 UP BND       X934                 0
 UP BND       X935                 6
 UP BND       X936                 5
 UP BND       X937                 1
 UP BND       X938                 2
 UP BND       X939                 4
 UP BND       X940                 8
 UP BND       X941                 7
 UP BND       X942                 3
 UP BND       X943                 7
 UP BND       X944                 9
 UP BND       X945                 8
 UP BND       X946                 4
 UP BND       X947                 1
 UP BND       X948                 0
 UP BND       X949                 0
 UP BND       X950                 4
 UP BND       X951                 9
 UP BND       X952                 2
 UP BND       X953                 8
 UP BND       X954                 7
 UP BND       X955                 1
 UP BND       X956                 7
 UP BND       X957                 1
 UP BND       X958                 0
 UP BND       X959                 8
 UP BND       X960                 0
 UP BND       X961                 4
 UP BND       X962                 2
 UP BND       X963                 2
 UP BND       X964                 5
 UP BND       X965                 0
 UP BND       X966                 1
 UP BND       X967                 1
 UP BND       X968                10
 UP BND       X969                 2
 UP BND       X970                 3
 UP BND       X971                 1
 UP BND       X972                 3
 UP BND       X973                 2
 UP BND       X974                 3
 UP BND       X975                 0
 UP BND       X976                 2
 UP BND       X977                 2
 UP BND       X978                 3
 UP BND       X979                 2
 UP BND       X980                 2
 UP BND       X981                 0
 UP BND       X982                 2
 UP BND       X983                 7
 UP BND       X984                 7
 UP BND       X985                 7
 UP BND       X986                 2
 UP BND       X987                 1
 UP BND       X988                 3
 UP BND       X989                10
 UP BND       X990                 0
 UP BND       X991                 2
 UP BND       X992                 3
 UP BND       X993                12
 UP BND       X994                 0
 UP BND       X995                 3
 UP BND       X996                 0
 UP BND       X997                 0
 UP BND       X998                 0
 UP BND       X999                 1
 UP BND       X1000                6
 UP BND       X1001                4
 UP BND       X1002                2
 UP BND       X1003                3
 UP BND       X1004                1
 UP BND       X1005                0
 UP BND       X1006                3
 UP BND       X1007                2
 UP BND       X1008                2
 UP BND       X1009                3
 UP BND       X1010                9
 UP BND       X1011                2
 UP BND       X1012                1
 UP BND       X1013                3
 UP BND       X1014                7
 UP BND       X1015                3
 UP BND       X1016                9
 UP BND       X1017               10
 UP BND       X1018                6
 UP BND       X1019                1
 UP BND       X1020                0
 UP BND       X1021                3
 UP BND       X1022                4
 UP BND       X1023                3
 UP BND       X1024                0
 UP BND       X1025                2
 UP BND       X1026                1
 UP BND       X1027                0
 UP BND       X1028                0
 UP BND       X1029                8
 UP BND       X1030                2
 UP BND       X1031                3
 UP BND       X1032                2
 UP BND       X1033               12
 UP BND       X1034                3
 UP BND       X1035                1
 UP BND       X1036                9
 UP BND       X1037                1
 UP BND       X1038                8
 UP BND       X1039               11
 UP BND       X1040                1
 UP BND       X1041                1
 UP BND       X1042                9
 UP BND       X1043                3
 UP BND       X1044                4
 UP BND       X1045                6
 UP BND       X1046                1
 UP BND       X1047                4
 UP BND       X1048                7
 UP BND       X1049                1
 UP BND       X1050               10
 UP BND       X1051                4
 UP BND       X1052                8
 UP BND       X1053                6
 UP BND       X1054                3
 UP BND       X1055                4
 UP BND       X1056                8
 UP BND       X1057                2
 UP BND       X1058                1
 UP BND       X1059                8
 UP BND       X1060                6
 UP BND       X1061                6
 UP BND       X1062                0
 UP BND       X1063                1
 UP BND       X1064                2
 UP BND       X1065                3
 UP BND       X1066                6
 UP BND       X1067                0
 UP BND       X1068               11
 UP BND       X1069                1
 UP BND       X1070                1
 UP BND       X1071                8
 UP BND       X1072                7
 UP BND       X1073                5
 UP BND       X1074                3
 UP BND       X1075               12
 UP BND       X1076                3
 UP BND       X1077               10
 UP BND       X1078                8
 UP BND       X1079                0
 UP BND       X1080               12
 UP BND       X1081                2
 UP BND       X1082                0
 UP BND       X1083                9
 UP BND       X1084                5
 UP BND       X1085                8
 UP BND       X1086                7
 UP BND       X1087                2
 UP BND       X1088                0
 UP BND       X1089                8
 UP BND       X1090                1
 UP BND       X1091                3
 UP BND       X1092                3
 UP BND       X1093                9
 UP BND       X1094                1
 UP BND       X1095                2
 UP BND       X1096                3
 UP BND       X1097                0
 UP BND       X1098                1
 UP BND       X1099                6
 UP BND       X1100               10
 UP BND       X1101                7
 UP BND       X1102                7
 UP BND       X1103                7
 UP BND       X1104                8
 UP BND       X1105                0
 UP BND       X1106                5
 UP BND       X1107                8
 UP BND       X1108                0
 UP BND       X1109                1
 UP BND       X1110                1
 UP BND       X1111                9
 UP BND       X1112                7
 UP BND       X1113                9
 UP BND       X1114                3
 UP BND       X1115                2
 UP BND       X1116                0
 UP BND       X1117                2
 UP BND       X1118                5
 UP BND       X1119                2
 UP BND       X1120                4
 UP BND       X1121                2
 UP BND       X1122                1
 UP BND       X1123                3
 UP BND       X1124                3
 UP BND       X1125                1
 UP BND       X1126                3
 UP BND       X1127                1
 UP BND       X1128                0
 UP BND       X1129                2
 UP BND       X1130                0
 UP BND       X1131                5
 UP BND       X1132               11
 UP BND       X1133                7
 UP BND       X1134                9
 UP BND       X1135               11
 UP BND       X1136                6
 UP BND       X1137                2
 UP BND       X1138               10
 UP BND       X1139                1
 UP BND       X1140               11
 UP BND       X1141                4
 UP BND       X1142                0
 UP BND       X1143                0
 UP BND       X1144                1
 UP BND       X1145                4
 UP BND       X1146                5
 UP BND       X1147                1
 UP BND       X1148                9
 UP BND       X1149                7
 UP BND       X1150                7
 UP BND       X1151                0
 UP BND       X1152                0
 UP BND       X1153                1
 UP BND       X1154                9
 UP BND       X1155                5
 UP BND       X1156                1
 UP BND       X1157                8
 UP BND       X1158                9
 UP BND       X1159                3
 UP BND       X1160                1
 UP BND       X1161                5
 UP BND       X1162                1
 UP BND       X1163                3
 UP BND       X1164                1
 UP BND       X1165                0
 UP BND       X1166               11
 UP BND       X1167                1
 UP BND       X1168                1
 UP BND       X1169                5
 UP BND       X1170                9
 UP BND       X1171                2
 UP BND       X1172                5
 UP BND       X1173                1
 UP BND       X1174                9
 UP BND       X1175                2
 UP BND       X1176                1
 UP BND       X1177                0
 UP BND       X1178                2
 UP BND       X1179                5
 UP BND       X1180                1
 UP BND       X1181                0
 UP BND       X1182                3
 UP BND       X1183                2
 UP BND       X1184                2
 UP BND       X1185                7
 UP BND       X1186                3
 UP BND       X1187                2
 UP BND       X1188                7
 UP BND       X1189                6
 UP BND       X1190                1
 UP BND       X1191                4
 UP BND       X1192                2
 UP BND       X1193                6
 UP BND       X1194                2
 UP BND       X1195               10
 UP BND       X1196                9
 UP BND       X1197                2
 UP BND       X1198                3
 UP BND       X1199               12
 UP BND       X1200                6
 UP BND       X1201                7
 UP BND       X1202                1
 UP BND       X1203                1
 UP BND       X1204                9
 UP BND       X1205                1
 UP BND       X1206                0
 UP BND       X1207                5
 UP BND       X1208                4
 UP BND       X1209                7
 UP BND       X1210               11
 UP BND       X1211                3
 UP BND       X1212                2
 UP BND       X1213                9
 UP BND       X1214                1
 UP BND       X1215                3
 UP BND       X1216                9
 UP BND       X1217                9
 UP BND       X1218                0
 UP BND       X1219                1
 UP BND       X1220                8
 UP BND       X1221               10
 UP BND       X1222                0
 UP BND       X1223                8
 UP BND       X1224               11
 UP BND       X1225                3
 UP BND       X1226                4
 UP BND       X1227                1
 UP BND       X1228                2
 UP BND       X1229                2
 UP BND       X1230                3
 UP BND       X1231                1
 UP BND       X1232                1
 UP BND       X1233                9
 UP BND       X1234                4
 UP BND       X1235                2
 UP BND       X1236                5
 UP BND       X1237                4
 UP BND       X1238                1
 UP BND       X1239                4
 UP BND       X1240               11
 UP BND       X1241                8
 UP BND       X1242                1
 UP BND       X1243                7
 UP BND       X1244                9
 UP BND       X1245                2
 UP BND       X1246                2
 UP BND       X1247                1
 UP BND       X1248                3
 UP BND       X1249                1
 UP BND       X1250               11
 UP BND       X1251                1
 UP BND       X1252                4
 UP BND       X1253                0
 UP BND       X1254                3
 UP BND       X1255                4
 UP BND       X1256                5
 UP BND       X1257                2
 UP BND       X1258                7
 UP BND       X1259               12
 UP BND       X1260                2
 UP BND       X1261                4
 UP BND       X1262               10
 UP BND       X1263                2
 UP BND       X1264                7
 UP BND       X1265                3
 UP BND       X1266                3
 UP BND       X1267                2
 UP BND       X1268                1
 UP BND       X1269                4
 UP BND       X1270                6
 UP BND       X1271                5
 UP BND       X1272                4
 UP BND       X1273                3
 UP BND       X1274               10
 UP BND       X1275                3
 UP BND       X1276                5
 UP BND       X1277                4
 UP BND       X1278                5
 UP BND       X1279                5
 UP BND       X1280                3
 UP BND       X1281                3
 UP BND       X1282                2
 UP BND       X1283                5
 UP BND       X1284                5
 UP BND       X1285               12
 UP BND       X1286                9
 UP BND       X1287                1
 UP BND       X1288                6
 UP BND       X1289                3
 UP BND       X1290                1
 UP BND       X1291                1
 UP BND       X1292                9
 UP BND       X1293                1
 UP BND       X1294                9
 UP BND       X1295                0
 UP BND       X1296                8
 UP BND       X1297                0
 UP BND       X1298                2
 UP BND       X1299                3
 UP BND       X1300                2
 UP BND       X1301                0
 UP BND       X1302                2
 UP BND       X1303                1
 UP BND       X1304                0
 UP BND       X1305                2
 UP BND       X1306                7
 UP BND       X1307                1
 UP BND       X1308                1
 UP BND       X1309                4
 UP BND       X1310                3
 UP BND       X1311                9
 UP BND       X1312               10
 UP BND       X1313                3
 UP BND       X1314               10
 UP BND       X1315               12
 UP BND       X1316                8
 UP BND       X1317                6
 UP BND       X1318                4
 UP BND       X1319                3
 UP BND       X1320                4
 UP BND       X1321                3
 UP BND       X1322                3
 UP BND       X1323                0
 UP BND       X1324                8
 UP BND       X1325                0
 UP BND       X1326                3
 UP BND       X1327                7
 UP BND       X1328               11
 UP BND       X1329               11
 UP BND       X1330                2
 UP BND       X1331               10
 UP BND       X1332                8
 UP BND       X1333                4
 UP BND       X1334                2
 UP BND       X1335                2
 UP BND       X1336                8
 UP BND       X1337                5
 UP BND       X1338                8
 UP BND       X1339                3
 UP BND       X1340                2
 UP BND       X1341               12
 UP BND       X1342                3
 UP BND       X1343                7
 UP BND       X1344                5
 UP BND       X1345                2
 UP BND       X1346                3
 UP BND       X1347                2
 UP BND       X1348                0
 UP BND       X1349               10
 UP BND       X1350                3
 UP BND       X1351                2
 UP BND       X1352                9
 UP BND       X1353                7
 UP BND       X1354                0
 UP BND       X1355                1
 UP BND       X1356                2
 UP BND       X1357                9
 UP BND       X1358                4
 UP BND       X1359                6
 UP BND       X1360                8
 UP BND       X1361               10
 UP BND       X1362                2
 UP BND       X1363                1
 UP BND       X1364                2
 UP BND       X1365                0
 UP BND       X1366                1
 UP BND       X1367                2
 UP BND       X1368                3
 UP BND       X1369                8
 UP BND       X1370                7
 UP BND       X1371                2
 UP BND       X1372                2
 UP BND       X1373                2
 UP BND       X1374                9
 UP BND       X1375                3
 UP BND       X1376                2
 UP BND       X1377                1
 UP BND       X1378                2
 UP BND       X1379               10
 UP BND       X1380                7
 UP BND       X1381                6
 UP BND       X1382                8
 UP BND       X1383                1
 UP BND       X1384               10
 UP BND       X1385               10
 UP BND       X1386                6
 UP BND       X1387                4
 UP BND       X1388                6
 UP BND       X1389                1
 UP BND       X1390                1
 UP BND       X1391               11
 UP BND       X1392               10
 UP BND       X1393                1
 UP BND       X1394                3
 UP BND       X1395                3
 UP BND       X1396                1
 UP BND       X1397                3
 UP BND       X1398                4
 UP BND       X1399                4
 UP BND       X1400                3
 UP BND       X1401                2
 UP BND       X1402                9
 UP BND       X1403                0
 UP BND       X1404                1
 UP BND       X1405                0
 UP BND       X1406                5
 UP BND       X1407                3
 UP BND       X1408                3
 UP BND       X1409                2
 UP BND       X1410                8
 UP BND       X1411                1
 UP BND       X1412               11
 UP BND       X1413                0
 UP BND       X1414                6
 UP BND       X1415                3
 UP BND       X1416                4
 UP BND       X1417                7
 UP BND       X1418                4
 UP BND       X1419                1
 UP BND       X1420                1
 UP BND       X1421                1
 UP BND       X1422                2
 UP BND       X1423                9
 UP BND       X1424                0
 UP BND       X1425                6
 UP BND       X1426                5
 UP BND       X1427                0
 UP BND       X1428                3
 UP BND       X1429                2
 UP BND       X1430                7
 UP BND       X1431                5
 UP BND       X1432                3
 UP BND       X1433                2
 UP BND       X1434                5
 UP BND       X1435               11
 UP BND       X1436                3
 UP BND       X1437                8
 UP BND       X1438                3
 UP BND       X1439                7
 UP BND       X1440                3
 UP BND       X1441                1
 UP BND       X1442                0
 UP BND       X1443                3
 UP BND       X1444                1
 UP BND       X1445                9
 UP BND       X1446                1
 UP BND       X1447                2
 UP BND       X1448                7
 UP BND       X1449                1
 UP BND       X1450                5
 UP BND       X1451                9
 UP BND       X1452                3
 UP BND       X1453                3
 UP BND       X1454                4
 UP BND       X1455               11
 UP BND       X1456                2
 UP BND       X1457                2
 UP BND       X1458                8
 UP BND       X1459                2
 UP BND       X1460                1
 UP BND       X1461                1
 UP BND       X1462                9
 UP BND       X1463                9
 UP BND       X1464                2
 UP BND       X1465                8
 UP BND       X1466                9
 UP BND       X1467                2
 UP BND       X1468                2
 UP BND       X1469                4
 UP BND       X1470                6
 UP BND       X1471               10
 UP BND       X1472                5
 UP BND       X1473                7
 UP BND       X1474                3
 UP BND       X1475                2
 UP BND       X1476                3
 UP BND       X1477                5
 UP BND       X1478                3
 UP BND       X1479                1
 UP BND       X1480                2
 UP BND       X1481                5
 UP BND       X1482                3
 UP BND       X1483                2
 UP BND       X1484                3
 UP BND       X1485                2
 UP BND       X1486                3
 UP BND       X1487                3
 UP BND       X1488                0
 UP BND       X1489                3
 UP BND       X1490                3
 UP BND       X1491                6
 UP BND       X1492                1
 UP BND       X1493                1
 UP BND       X1494                1
 UP BND       X1495                4
 UP BND       X1496               10
 UP BND       X1497                0
 UP BND       X1498                2
 UP BND       X1499                3
 UP BND       X1500                8
 UP BND       X1501                3
 UP BND       X1502                3
 UP BND       X1503                3
 UP BND       X1504                0
 UP BND       X1505                7
 UP BND       X1506                1
 UP BND       X1507                1
 UP BND       X1508                3
 UP BND       X1509                3
 UP BND       X1510                7
 UP BND       X1511                1
 UP BND       X1512                1
 UP BND       X1513               10
 UP BND       X1514                8
 UP BND       X1515                1
 UP BND       X1516                1
 UP BND       X1517                3
 UP BND       X1518                3
 UP BND       X1519                0
 UP BND       X1520                3
 UP BND       X1521                4
 UP BND       X1522                3
 UP BND       X1523                2
 UP BND       X1524                6
 UP BND       X1525                0
 UP BND       X1526               10
 UP BND       X1527                5
 UP BND       X1528                9
 UP BND       X1529                3
 UP BND       X1530                3
 UP BND       X1531                1
 UP BND       X1532                2
 UP BND       X1533                3
 UP BND       X1534                1
 UP BND       X1535                5
 UP BND       X1536               10
 UP BND       X1537                6
 UP BND       X1538                3
 UP BND       X1539                0
 UP BND       X1540                6
 UP BND       X1541               10
 UP BND       X1542                4
 UP BND       X1543                9
 UP BND       X1544               10
 UP BND       X1545                3
 UP BND       X1546                3
 UP BND       X1547                6
 UP BND       X1548                6
 UP BND       X1549                2
 UP BND       X1550                5
 UP BND       X1551               12
 UP BND       X1552                8
 UP BND       X1553                1
 UP BND       X1554               11
 UP BND       X1555                9
 UP BND       X1556                5
 UP BND       X1557               10
 UP BND       X1558                1
 UP BND       X1559                1
 UP BND       X1560                0
 UP BND       X1561                3
 UP BND       X1562                1
 UP BND       X1563                2
 UP BND       X1564                2
 UP BND       X1565                9
 UP BND       X1566                6
 UP BND       X1567                3
 UP BND       X1568               11
 UP BND       X1569                7
 UP BND       X1570                1
 UP BND       X1571                2
 UP BND       X1572                8
 UP BND       X1573                9
 UP BND       X1574                6
 UP BND       X1575                3
 UP BND       X1576                3
 UP BND       X1577                0
 UP BND       X1578                4
 UP BND       X1579                0
 UP BND       X1580                6
 UP BND       X1581                6
 UP BND       X1582                0
 UP BND       X1583                6
 UP BND       X1584                1
 UP BND       X1585                1
 UP BND       X1586                3
 UP BND       X1587                7
 UP BND       X1588                1
 UP BND       X1589                1
 UP BND       X1590                2
 UP BND       X1591                3
 UP BND       X1592                0
 UP BND       X1593                0
 UP BND       X1594                2
 UP BND       X1595                3
 UP BND       X1596                8
 UP BND       X1597                5
 UP BND       X1598                0
 UP BND       X1599                6
 UP BND       X1600                0
 UP BND       X1601                3
 UP BND       X1602                6
 UP BND       X1603                6
 UP BND       X1604                7
 UP BND       X1605                0
 UP BND       X1606                0
 UP BND       X1607                3
 UP BND       X1608                6
 UP BND       X1609                2
 UP BND       X1610                3
 UP BND       X1611               10
 UP BND       X1612                3
 UP BND       X1613               12
 UP BND       X1614                2
 UP BND       X1615                0
 UP BND       X1616                6
 UP BND       X1617                4
 UP BND       X1618                7
 UP BND       X1619                4
 UP BND       X1620                0
 UP BND       X1621                8
 UP BND       X1622                9
 UP BND       X1623                3
 UP BND       X1624                0
 UP BND       X1625                1
 UP BND       X1626                4
 UP BND       X1627                7
 UP BND       X1628                8
 UP BND       X1629                3
 UP BND       X1630                8
 UP BND       X1631                7
 UP BND       X1632                8
 UP BND       X1633                8
 UP BND       X1634                2
 UP BND       X1635                0
 UP BND       X1636                9
 UP BND       X1637                4
 UP BND       X1638                2
 UP BND       X1639               10
 UP BND       X1640                5
 UP BND       X1641                3
 UP BND       X1642                1
 UP BND       X1643                5
 UP BND       X1644                2
 UP BND       X1645                0
 UP BND       X1646                5
 UP BND       X1647                8
 UP BND       X1648                0
 UP BND       X1649                2
 UP BND       X1650                2
 UP BND       X1651                1
 UP BND       X1652                0
 UP BND       X1653                5
 UP BND       X1654                3
 UP BND       X1655                3
 UP BND       X1656                1
 UP BND       X1657               10
 UP BND       X1658                0
 UP BND       X1659                5
 UP BND       X1660               11
 UP BND       X1661                3
 UP BND       X1662               10
 UP BND       X1663               11
 UP BND       X1664                0
 UP BND       X1665                4
 UP BND       X1666                0
 UP BND       X1667                2
 UP BND       X1668                7
 UP BND       X1669                1
 UP BND       X1670                1
 UP BND       X1671                6
 UP BND       X1672               10
 UP BND       X1673                8
 UP BND       X1674                1
 UP BND       X1675                3
 UP BND       X1676                4
 UP BND       X1677                0
 UP BND       X1678                8
 UP BND       X1679               12
 UP BND       X1680               10
 UP BND       X1681                0
 UP BND       X1682                8
 UP BND       X1683                3
 UP BND       X1684                2
 UP BND       X1685                3
 UP BND       X1686                0
 UP BND       X1687                3
 UP BND       X1688                2
 UP BND       X1689                5
 UP BND       X1690                5
 UP BND       X1691               10
 UP BND       X1692                1
 UP BND       X1693                2
 UP BND       X1694                0
 UP BND       X1695                1
 UP BND       X1696                0
 UP BND       X1697                2
 UP BND       X1698                0
 UP BND       X1699                9
 UP BND       X1700                4
 UP BND       X1701                1
 UP BND       X1702                1
 UP BND       X1703                7
 UP BND       X1704                8
 UP BND       X1705                2
 UP BND       X1706                1
 UP BND       X1707               10
 UP BND       X1708                8
 UP BND       X1709                7
 UP BND       X1710                0
 UP BND       X1711                5
 UP BND       X1712                0
 UP BND       X1713                0
 UP BND       X1714                4
 UP BND       X1715                7
 UP BND       X1716                3
 UP BND       X1717                8
 UP BND       X1718                3
 UP BND       X1719                9
 UP BND       X1720                0
 UP BND       X1721                0
 UP BND       X1722                8
 UP BND       X1723                9
 UP BND       X1724                0
 UP BND       X1725                4
 UP BND       X1726                0
 UP BND       X1727                0
 UP BND       X1728                1
 UP BND       X1729                5
 UP BND       X1730                2
 UP BND       X1731                0
 UP BND       X1732                1
 UP BND       X1733                7
 UP BND       X1734                3
 UP BND       X1735               11
 UP BND       X1736                1
 UP BND       X1737                8
 UP BND       X1738                3
 UP BND       X1739                1
 UP BND       X1740                0
 UP BND       X1741                4
 UP BND       X1742                1
 UP BND       X1743                5
 UP BND       X1744                2
 UP BND       X1745                1
 UP BND       X1746                0
 UP BND       X1747                1
 UP BND       X1748                8
 UP BND       X1749                8
 UP BND       X1750                2
 UP BND       X1751                1
 UP BND       X1752               11
 UP BND       X1753                2
 UP BND       X1754                2
 UP BND       X1755                1
 UP BND       X1756                0
 UP BND       X1757                3
 UP BND       X1758                1
 UP BND       X1759                3
 UP BND       X1760                3
 UP BND       X1761                3
 UP BND       X1762                6
 UP BND       X1763                4
 UP BND       X1764                6
 UP BND       X1765                1
 UP BND       X1766                1
 UP BND       X1767               10
 UP BND       X1768                4
 UP BND       X1769                3
 UP BND       X1770               12
 UP BND       X1771               10
 UP BND       X1772                2
 UP BND       X1773                6
 UP BND       X1774                0
 UP BND       X1775                0
 UP BND       X1776                3
 UP BND       X1777                4
 UP BND       X1778                3
 UP BND       X1779                2
 UP BND       X1780                2
 UP BND       X1781                3
 UP BND       X1782                1
 UP BND       X1783                3
 UP BND       X1784                3
 UP BND       X1785                1
 UP BND       X1786                4
 UP BND       X1787                1
 UP BND       X1788                8
 UP BND       X1789                4
 UP BND       X1790                3
 UP BND       X1791                9
 UP BND       X1792                0
 UP BND       X1793                7
 UP BND       X1794                0
 UP BND       X1795                2
 UP BND       X1796                6
 UP BND       X1797                5
 UP BND       X1798                1
 UP BND       X1799                1
 UP BND       X1800                0
 UP BND       X1801                6
 UP BND       X1802                9
 UP BND       X1803                0
 UP BND       X1804               11
 UP BND       X1805                3
 UP BND       X1806                8
 UP BND       X1807                2
 UP BND       X1808                4
 UP BND       X1809                8
 UP BND       X1810                7
 UP BND       X1811                1
 UP BND       X1812                0
 UP BND       X1813                9
 UP BND       X1814                6
 UP BND       X1815                9
 UP BND       X1816                6
 UP BND       X1817                5
 UP BND       X1818                4
 UP BND       X1819                8
 UP BND       X1820                3
 UP BND       X1821                3
 UP BND       X1822                1
 UP BND       X1823                1
 UP BND       X1824                4
 UP BND       X1825               12
 UP BND       X1826                2
 UP BND       X1827                2
 UP BND       X1828                9
 UP BND       X1829               11
 UP BND       X1830                8
 UP BND       X1831                7
 UP BND       X1832                3
 UP BND       X1833                9
 UP BND       X1834                0
 UP BND       X1835                0
 UP BND       X1836                7
 UP BND       X1837                0
 UP BND       X1838                2
 UP BND       X1839                5
 UP BND       X1840                3
 UP BND       X1841                3
 UP BND       X1842                5
 UP BND       X1843               10
 UP BND       X1844                9
 UP BND       X1845                2
 UP BND       X1846               11
 UP BND       X1847                7
 UP BND       X1848                4
 UP BND       X1849                9
 UP BND       X1850                8
 UP BND       X1851                4
 UP BND       X1852                5
 UP BND       X1853                3
 UP BND       X1854                6
 UP BND       X1855                2
 UP BND       X1856                8
 UP BND       X1857                8
 UP BND       X1858                2
 UP BND       X1859                2
 UP BND       X1860                1
 UP BND       X1861                0
 UP BND       X1862                2
 UP BND       X1863                6
 UP BND       X1864                9
 UP BND       X1865                7
 UP BND       X1866                3
 UP BND       X1867               10
 UP BND       X1868                3
 UP BND       X1869                3
 UP BND       X1870                2
 UP BND       X1871                3
 UP BND       X1872                6
 UP BND       X1873                9
 UP BND       X1874                3
 UP BND       X1875                3
 UP BND       X1876               10
 UP BND       X1877                0
 UP BND       X1878                0
 UP BND       X1879                3
 UP BND       X1880                8
 UP BND       X1881                3
 UP BND       X1882                0
 UP BND       X1883               12
 UP BND       X1884                3
 UP BND       X1885                1
 UP BND       X1886                1
 UP BND       X1887                2
 UP BND       X1888                9
 UP BND       X1889                2
 UP BND       X1890                7
 UP BND       X1891                6
 UP BND       X1892                1
 UP BND       X1893                2
 UP BND       X1894                1
 UP BND       X1895               10
 UP BND       X1896                9
 UP BND       X1897                7
 UP BND       X1898                1
 UP BND       X1899                3
 UP BND       X1900                9
 UP BND       X1901                2
 UP BND       X1902                2
 UP BND       X1903                0
 UP BND       X1904                1
 UP BND       X1905                8
 UP BND       X1906                1
 UP BND       X1907                1
 UP BND       X1908                2
 UP BND       X1909                3
 UP BND       X1910                0
 UP BND       X1911                3
 UP BND       X1912                7
 UP BND       X1913                4
 UP BND       X1914                0
 UP BND       X1915                0
 UP BND       X1916                3
 UP BND       X1917                3
 UP BND       X1918                0
 UP BND       X1919                1
 UP BND       X1920                1
 UP BND       X1921                8
 UP BND       X1922                3
 UP BND       X1923               11
 UP BND       X1924                3
 UP BND       X1925                7
 UP BND       X1926                3
 UP BND       X1927                1
 UP BND       X1928                5
 UP BND       X1929                2
 UP BND       X1930                9
 UP BND       X1931                2
 UP BND       X1932                6
 UP BND       X1933                5
 UP BND       X1934                3
 UP BND       X1935                0
 UP BND       X1936                5
 UP BND       X1937                5
 UP BND       X1938                0
 UP BND       X1939                4
 UP BND       X1940                8
 UP BND       X1941               10
 UP BND       X1942                7
 UP BND       X1943                0
 UP BND       X1944                3
 UP BND       X1945                5
 UP BND       X1946                4
 UP BND       X1947                1
 UP BND       X1948                1
 UP BND       X1949                5
 UP BND       X1950                8
 UP BND       X1951                4
 UP BND       X1952                3
 UP BND       X1953                1
 UP BND       X1954                6
 UP BND       X1955                5
 UP BND       X1956                0
 UP BND       X1957                1
 UP BND       X1958                8
 UP BND       X1959                0
 UP BND       X1960                2
 UP BND       X1961                2
 UP BND       X1962                2
 UP BND       X1963                4
 UP BND       X1964                3
 UP BND       X1965                1
 UP BND       X1966                0
 UP BND       X1967                2
 UP BND       X1968                2
 UP BND       X1969                3
 UP BND       X1970                6
 UP BND       X1971               10
 UP BND       X1972                0
 UP BND       X1973                3
 UP BND       X1974                3
 UP BND       X1975                3
 UP BND       X1976                6
 UP BND       X1977                3
 UP BND       X1978                3
 UP BND       X1979                0
 UP BND       X1980                4
 UP BND       X1981                0
 UP BND       X1982                5
 UP BND       X1983                4
 UP BND       X1984                0
 UP BND       X1985                0
 UP BND       X1986                3
 UP BND       X1987                0
 UP BND       X1988                3
 UP BND       X1989               10
 UP BND       X1990                0
 UP BND       X1991                0
 UP BND       X1992                9
 UP BND       X1993                2
 UP BND       X1994                1
 UP BND       X1995                7
 UP BND       X1996                1
 UP BND       X1997                2
 UP BND       X1998                3
 UP BND       X1999                8
 UP BND       X2000                0
 UP BND       X2001                6
 UP BND       X2002                3
 UP BND       X2003                3
 UP BND       X2004                9
 UP BND       X2005                8
 UP BND       X2006                3
 UP BND       X2007                9
 UP BND       X2008                1
 UP BND       X2009                3
 UP BND       X2010                2
 UP BND       X2011               12
 UP BND       X2012                8
 UP BND       X2013                3
 UP BND       X2014                4
 UP BND       X2015                2
 UP BND       X2016                5
 UP BND       X2017                3
 UP BND       X2018                9
 UP BND       X2019                4
 UP BND       X2020                7
 UP BND       X2021                6
 UP BND       X2022                3
 UP BND       X2023                2
 UP BND       X2024                4
 UP BND       X2025                0
 UP BND       X2026                1
 UP BND       X2027                8
 UP BND       X2028                6
 UP BND       X2029                3
 UP BND       X2030                4
 UP BND       X2031                8
 UP BND       X2032                5
 UP BND       X2033                6
 UP BND       X2034                8
 UP BND       X2035                1
 UP BND       X2036                1
 UP BND       X2037                2
 UP BND       X2038                1
 UP BND       X2039                3
 UP BND       X2040                5
 UP BND       X2041                0
 UP BND       X2042                0
 UP BND       X2043               10
 UP BND       X2044                4
 UP BND       X2045                4
 UP BND       X2046                3
 UP BND       X2047                2
 UP BND       X2048                6
 UP BND       X2049               11
 UP BND       X2050               10
 UP BND       X2051                0
 UP BND       X2052                1
 UP BND       X2053                1
 UP BND       X2054                3
 UP BND       X2055                3
 UP BND       X2056                0
 UP BND       X2057               11
 UP BND       X2058                3
 UP BND       X2059                3
 UP BND       X2060                6
 UP BND       X2061                1
 UP BND       X2062                1
 UP BND       X2063               10
 UP BND       X2064                2
 UP BND       X2065                1
 UP BND       X2066                1
 UP BND       X2067                1
 UP BND       X2068               10
 UP BND       X2069                3
 UP BND       X2070                2
 UP BND       X2071                0
 UP BND       X2072                2
 UP BND       X2073                1
 UP BND       X2074                0
 UP BND       X2075               11
 UP BND       X2076                2
 UP BND       X2077                2
 UP BND       X2078                7
 UP BND       X2079                2
 UP BND       X2080                1
 UP BND       X2081                1
 UP BND       X2082                2
 UP BND       X2083                7
 UP BND       X2084                0
 UP BND       X2085                6
 UP BND       X2086                0
 UP BND       X2087                1
 UP BND       X2088                0
 UP BND       X2089                5
 UP BND       X2090                0
 UP BND       X2091                6
 UP BND       X2092                1
 UP BND       X2093                3
 UP BND       X2094                2
 UP BND       X2095                5
 UP BND       X2096                5
 UP BND       X2097                8
 UP BND       X2098                1
 UP BND       X2099                4
 UP BND       X2100                4
 UP BND       X2101                7
 UP BND       X2102                1
 UP BND       X2103                1
 UP BND       X2104                9
 UP BND       X2105                1
 UP BND       X2106                5
 UP BND       X2107                8
 UP BND       X2108                2
 UP BND       X2109                0
 UP BND       X2110                8
 UP BND       X2111                2
 UP BND       X2112                1
 UP BND       X2113                0
 UP BND       X2114                2
 UP BND       X2115                0
 UP BND       X2116                1
 UP BND       X2117                2
 UP BND       X2118                3
 UP BND       X2119               10
 UP BND       X2120                8
 UP BND       X2121                7
 UP BND       X2122                1
 UP BND       X2123                0
 UP BND       X2124                3
 UP BND       X2125                3
 UP BND       X2126               12
 UP BND       X2127                2
 UP BND       X2128                2
 UP BND       X2129                0
 UP BND       X2130                0
 UP BND       X2131                1
 UP BND       X2132                7
 UP BND       X2133                9
 UP BND       X2134               11
 UP BND       X2135                3
 UP BND       X2136                0
 UP BND       X2137                7
 UP BND       X2138               10
 UP BND       X2139                2
 UP BND       X2140                9
 UP BND       X2141                1
 UP BND       X2142                8
 UP BND       X2143                4
 UP BND       X2144                1
 UP BND       X2145                4
 UP BND       X2146                1
 UP BND       X2147                3
 UP BND       X2148                3
 UP BND       X2149                0
 UP BND       X2150                8
 UP BND       X2151                1
 UP BND       X2152               10
 UP BND       X2153                8
 UP BND       X2154                0
 UP BND       X2155                6
 UP BND       X2156                1
 UP BND       X2157                1
 UP BND       X2158                6
 UP BND       X2159                6
 UP BND       X2160               11
 UP BND       X2161                1
 UP BND       X2162                8
 UP BND       X2163                9
 UP BND       X2164                6
 UP BND       X2165               10
 UP BND       X2166                6
 UP BND       X2167                9
 UP BND       X2168                1
 UP BND       X2169                8
 UP BND       X2170                5
 UP BND       X2171                1
 UP BND       X2172                2
 UP BND       X2173                3
 UP BND       X2174                3
 UP BND       X2175                2
 UP BND       X2176               10
 UP BND       X2177                1
 UP BND       X2178                6
 UP BND       X2179                2
 UP BND       X2180                3
 UP BND       X2181                7
 UP BND       X2182               10
 UP BND       X2183                5
 UP BND       X2184                5
 UP BND       X2185                1
 UP BND       X2186                2
 UP BND       X2187                1
 UP BND       X2188                2
 UP BND       X2189               10
 UP BND       X2190                4
 UP BND       X2191                3
 UP BND       X2192                1
 UP BND       X2193                3
 UP BND       X2194                1
 UP BND       X2195                2
 UP BND       X2196                8
 UP BND       X2197                9
 UP BND       X2198                5
 UP BND       X2199                6
 UP BND       X2200                8
 UP BND       X2201                1
 UP BND       X2202                3
 UP BND       X2203                0
 UP BND       X2204                0
 UP BND       X2205                9
 UP BND       X2206                5
 UP BND       X2207                8
 UP BND       X2208                4
 UP BND       X2209                1
 UP BND       X2210                0
 UP BND       X2211               10
 UP BND       X2212                3
 UP BND       X2213                7
 UP BND       X2214                2
 UP BND       X2215               10
 UP BND       X2216                1
 UP BND       X2217                4
 UP BND       X2218                8
 UP BND       X2219                0
 UP BND       X2220                1
 UP BND       X2221               11
 UP BND       X2222                5
 UP BND       X2223                7
 UP BND       X2224                9
 UP BND       X2225                1
 UP BND       X2226                1
 UP BND       X2227                2
 UP BND       X2228                6
 UP BND       X2229               11
 UP BND       X2230                4
 UP BND       X2231                1
 UP BND       X2232                6
 UP BND       X2233                8
 UP BND       X2234                2
 UP BND       X2235                1
 UP BND       X2236                7
 UP BND       X2237                5
 UP BND       X2238                9
 UP BND       X2239                7
 UP BND       X2240                5
 UP BND       X2241                6
 UP BND       X2242                1
 UP BND       X2243                8
 UP BND       X2244                2
 UP BND       X2245                1
 UP BND       X2246                2
 UP BND       X2247                5
 UP BND       X2248               10
 UP BND       X2249                1
 UP BND       X2250                8
 UP BND       X2251                3
 UP BND       X2252                0
 UP BND       X2253                3
 UP BND       X2254                0
 UP BND       X2255                2
 UP BND       X2256                2
 UP BND       X2257                8
 UP BND       X2258                6
 UP BND       X2259                1
 UP BND       X2260                0
 UP BND       X2261                2
 UP BND       X2262                5
 UP BND       X2263               12
 UP BND       X2264                1
 UP BND       X2265                2
 UP BND       X2266                6
 UP BND       X2267                0
 UP BND       X2268                2
 UP BND       X2269                2
 UP BND       X2270                2
 UP BND       X2271                1
 UP BND       X2272                3
 UP BND       X2273                0
 UP BND       X2274                6
 UP BND       X2275                2
 UP BND       X2276                7
 UP BND       X2277                8
 UP BND       X2278                6
 UP BND       X2279                3
 UP BND       X2280                4
 UP BND       X2281                9
 UP BND       X2282                4
 UP BND       X2283                1
 UP BND       X2284                9
 UP BND       X2285                0
 UP BND       X2286                1
 UP BND       X2287                2
 UP BND       X2288                9
 UP BND       X2289                0
 UP BND       X2290                3
 UP BND       X2291                0
 UP BND       X2292                3
 UP BND       X2293                6
 UP BND       X2294                3
 UP BND       X2295                3
 UP BND       X2296                0
 UP BND       X2297                0
 UP BND       X2298                3
 UP BND       X2299                3
 UP BND       X2300                6
 UP BND       X2301                1
 UP BND       X2302                3
 UP BND       X2303                0
 UP BND       X2304               11
 UP BND       X2305                4
 UP BND       X2306                8
 UP BND       X2307                6
 UP BND       X2308                1
 UP BND       X2309                4
 UP BND       X2310                5
 UP BND       X2311                4
 UP BND       X2312                1
 UP BND       X2313               10
 UP BND       X2314                8
 UP BND       X2315                6
 UP BND       X2316                8
 UP BND       X2317                3
 UP BND       X2318                9
 UP BND       X2319                4
 UP BND       X2320                5
 UP BND       X2321                1
 UP BND       X2322                3
 UP BND       X2323                4
 UP BND       X2324                7
 UP BND       X2325                1
 UP BND       X2326               11
 UP BND       X2327                0
 UP BND       X2328                1
 UP BND       X2329                3
 UP BND       X2330                0
 UP BND       X2331                2
 UP BND       X2332                8
 UP BND       X2333                3
 UP BND       X2334               11
 UP BND       X2335                3
 UP BND       X2336                3
 UP BND       X2337                2
 UP BND       X2338                0
 UP BND       X2339               10
 UP BND       X2340                1
 UP BND       X2341                3
 UP BND       X2342                2
 UP BND       X2343                1
 UP BND       X2344                0
 UP BND       X2345                3
 UP BND       X2346                3
 UP BND       X2347                3
 UP BND       X2348                4
 UP BND       X2349                7
 UP BND       X2350                0
 UP BND       X2351                5
 UP BND       X2352                3
 UP BND       X2353                7
 UP BND       X2354                9
 UP BND       X2355                3
 UP BND       X2356                2
 UP BND       X2357                2
 UP BND       X2358                8
 UP BND       X2359                6
 UP BND       X2360                4
 UP BND       X2361                5
 UP BND       X2362                4
 UP BND       X2363                2
 UP BND       X2364                5
 UP BND       X2365               11
 UP BND       X2366                1
 UP BND       X2367                4
 UP BND       X2368               10
 UP BND       X2369                2
 UP BND       X2370                1
 UP BND       X2371                2
 UP BND       X2372                5
 UP BND       X2373                3
 UP BND       X2374                2
 UP BND       X2375                3
 UP BND       X2376                9
 UP BND       X2377                2
 UP BND       X2378                1
 UP BND       X2379                8
 UP BND       X2380                0
 UP BND       X2381                7
 UP BND       X2382               11
 UP BND       X2383                3
 UP BND       X2384                1
 UP BND       X2385                7
 UP BND       X2386                0
 UP BND       X2387               10
 UP BND       X2388                0
 UP BND       X2389                8
 UP BND       X2390                2
 UP BND       X2391                8
 UP BND       X2392                2
 UP BND       X2393                8
 UP BND       X2394                1
 UP BND       X2395                0
 UP BND       X2396                2
 UP BND       X2397                9
 UP BND       X2398                9
 UP BND       X2399                6
 UP BND       X2400                9
 UP BND       X2401                4
 UP BND       X2402               11
 UP BND       X2403                3
 UP BND       X2404                3
 UP BND       X2405                2
 UP BND       X2406               12
 UP BND       X2407                2
 UP BND       X2408                6
 UP BND       X2409               12
 UP BND       X2410                3
 UP BND       X2411                4
 UP BND       X2412                3
 UP BND       X2413                4
 UP BND       X2414                8
 UP BND       X2415                9
 UP BND       X2416                0
 UP BND       X2417                0
 UP BND       X2418                2
 UP BND       X2419                2
 UP BND       X2420               10
 UP BND       X2421                0
 UP BND       X2422                7
 UP BND       X2423                2
 UP BND       X2424                8
 UP BND       X2425                8
 UP BND       X2426                2
 UP BND       X2427                1
 UP BND       X2428                7
 UP BND       X2429                1
 UP BND       X2430                3
 UP BND       X2431                5
 UP BND       X2432                2
 UP BND       X2433                8
 UP BND       X2434                2
 UP BND       X2435                7
 UP BND       X2436                2
 UP BND       X2437                3
 UP BND       X2438                0
 UP BND       X2439                6
 UP BND       X2440                5
 UP BND       X2441                2
 UP BND       X2442                1
 UP BND       X2443                2
 UP BND       X2444                9
 UP BND       X2445               11
 UP BND       X2446                8
 UP BND       X2447                0
 UP BND       X2448                2
 UP BND       X2449                8
 UP BND       X2450               10
 UP BND       X2451                3
 UP BND       X2452                3
 UP BND       X2453                7
 UP BND       X2454                0
 UP BND       X2455                3
 UP BND       X2456                3
 UP BND       X2457                8
 UP BND       X2458                0
 UP BND       X2459                0
 UP BND       X2460                3
 UP BND       X2461                7
 UP BND       X2462               10
 UP BND       X2463                6
 UP BND       X2464                9
 UP BND       X2465                9
 UP BND       X2466                9
 UP BND       X2467                0
 UP BND       X2468                6
 UP BND       X2469               10
 UP BND       X2470               10
 UP BND       X2471                7
 UP BND       X2472               10
 UP BND       X2473                4
 UP BND       X2474                3
 UP BND       X2475                6
 UP BND       X2476               10
 UP BND       X2477                1
 UP BND       X2478                6
 UP BND       X2479                2
 UP BND       X2480                0
 UP BND       X2481               10
 UP BND       X2482                6
 UP BND       X2483                7
 UP BND       X2484                0
 UP BND       X2485                0
 UP BND       X2486                4
 UP BND       X2487                7
 UP BND       X2488                2
 UP BND       X2489                8
 UP BND       X2490                2
 UP BND       X2491                3
 UP BND       X2492                6
 UP BND       X2493                7
 UP BND       X2494                6
 UP BND       X2495                4
 UP BND       X2496                7
 UP BND       X2497                5
 UP BND       X2498                0
 UP BND       X2499                0
 UP BND       X2500                8
 UP BND       X2501                4
 UP BND       X2502                1
 UP BND       X2503                5
 UP BND       X2504                8
 UP BND       X2505                5
 UP BND       X2506                5
 UP BND       X2507                6
 UP BND       X2508                1
 UP BND       X2509                1
 UP BND       X2510                3
 UP BND       X2511                6
 UP BND       X2512                5
 UP BND       X2513                6
 UP BND       X2514                1
 UP BND       X2515                5
 UP BND       X2516                5
 UP BND       X2517                1
 UP BND       X2518                0
 UP BND       X2519                8
 UP BND       X2520                3
 UP BND       X2521                1
 UP BND       X2522                4
 UP BND       X2523               10
 UP BND       X2524                7
 UP BND       X2525               10
 UP BND       X2526                2
 UP BND       X2527                0
 UP BND       X2528                3
 UP BND       X2529                1
 UP BND       X2530                1
 UP BND       X2531                3
 UP BND       X2532                4
 UP BND       X2533                1
 UP BND       X2534                5
 UP BND       X2535                5
 UP BND       X2536                3
 UP BND       X2537                6
 UP BND       X2538                0
 UP BND       X2539                0
 UP BND       X2540                9
 UP BND       X2541                0
 UP BND       X2542                2
 UP BND       X2543                0
 UP BND       X2544                3
 UP BND       X2545                0
 UP BND       X2546                3
 UP BND       X2547                7
 UP BND       X2548               11
 UP BND       X2549                0
 UP BND       X2550                9
 UP BND       X2551                8
 UP BND       X2552                3
 UP BND       X2553               12
 UP BND       X2554               11
 UP BND       X2555                8
 UP BND       X2556                2
 UP BND       X2557                8
 UP BND       X2558                0
 UP BND       X2559                4
 UP BND       X2560                2
 UP BND       X2561               10
 UP BND       X2562                3
 UP BND       X2563                0
 UP BND       X2564                3
 UP BND       X2565                2
 UP BND       X2566                0
 UP BND       X2567                7
 UP BND       X2568               12
 UP BND       X2569                7
 UP BND       X2570                2
 UP BND       X2571                9
 UP BND       X2572                8
 UP BND       X2573                7
 UP BND       X2574                6
 UP BND       X2575                6
 UP BND       X2576                1
 UP BND       X2577                3
 UP BND       X2578                0
 UP BND       X2579                3
 UP BND       X2580                2
 UP BND       X2581                4
 UP BND       X2582                3
 UP BND       X2583                7
 UP BND       X2584                6
 UP BND       X2585               10
 UP BND       X2586                0
 UP BND       X2587                3
 UP BND       X2588                1
 UP BND       X2589                9
 UP BND       X2590                4
 UP BND       X2591                1
 UP BND       X2592                5
 UP BND       X2593                4
 UP BND       X2594                0
 UP BND       X2595                3
 UP BND       X2596                3
 UP BND       X2597                7
 UP BND       X2598                4
 UP BND       X2599                0
 UP BND       X2600                1
 UP BND       X2601                5
 UP BND       X2602                1
 UP BND       X2603                0
 UP BND       X2604                9
 UP BND       X2605                3
 UP BND       X2606                3
 UP BND       X2607                9
 UP BND       X2608                0
 UP BND       X2609                2
 UP BND       X2610               10
 UP BND       X2611                1
 UP BND       X2612                3
 UP BND       X2613                4
 UP BND       X2614                7
 UP BND       X2615                2
 UP BND       X2616                6
 UP BND       X2617                0
 UP BND       X2618                8
 UP BND       X2619                6
 UP BND       X2620                3
 UP BND       X2621                8
 UP BND       X2622                3
 UP BND       X2623                1
 UP BND       X2624                1
 UP BND       X2625                7
 UP BND       X2626                2
 UP BND       X2627                0
 UP BND       X2628                2
 UP BND       X2629                6
 UP BND       X2630                5
 UP BND       X2631                8
 UP BND       X2632                3
 UP BND       X2633                1
 UP BND       X2634                3
 UP BND       X2635                3
 UP BND       X2636                5
 UP BND       X2637                2
 UP BND       X2638                9
 UP BND       X2639                0
 UP BND       X2640                6
 UP BND       X2641                7
 UP BND       X2642                0
 UP BND       X2643                7
 UP BND       X2644                6
 UP BND       X2645                9
 UP BND       X2646                1
 UP BND       X2647                1
 UP BND       X2648                1
 UP BND       X2649                3
 UP BND       X2650               12
 UP BND       X2651                3
 UP BND       X2652                4
 UP BND       X2653               10
 UP BND       X2654                1
 UP BND       X2655                2
 UP BND       X2656                2
 UP BND       X2657                8
 UP BND       X2658                1
 UP BND       X2659                8
 UP BND       X2660                0
 UP BND       X2661                2
 UP BND       X2662                7
 UP BND       X2663                2
 UP BND       X2664                4
 UP BND       X2665                8
 UP BND       X2666                1
 UP BND       X2667                1
 UP BND       X2668                7
 UP BND       X2669                3
 UP BND       X2670                0
 UP BND       X2671                3
 UP BND       X2672                3
 UP BND       X2673                0
 UP BND       X2674                4
 UP BND       X2675                1
 UP BND       X2676                0
 UP BND       X2677                8
 UP BND       X2678                3
 UP BND       X2679                7
 UP BND       X2680                6
 UP BND       X2681                3
 UP BND       X2682                6
 UP BND       X2683                3
 UP BND       X2684               11
 UP BND       X2685                0
 UP BND       X2686                0
 UP BND       X2687                1
 UP BND       X2688                0
 UP BND       X2689                8
 UP BND       X2690                1
 UP BND       X2691                1
 UP BND       X2692                5
 UP BND       X2693                3
 UP BND       X2694                6
 UP BND       X2695                2
 UP BND       X2696                9
 UP BND       X2697                8
 UP BND       X2698                1
 UP BND       X2699                6
 UP BND       X2700               12
 UP BND       X2701                6
 UP BND       X2702                7
 UP BND       X2703                2
 UP BND       X2704                0
 UP BND       X2705                7
 UP BND       X2706                1
 UP BND       X2707                6
 UP BND       X2708                6
 UP BND       X2709                0
 UP BND       X2710                6
 UP BND       X2711                0
 UP BND       X2712                3
 UP BND       X2713                2
 UP BND       X2714                8
 UP BND       X2715                6
 UP BND       X2716                5
 UP BND       X2717                5
 UP BND       X2718                0
 UP BND       X2719                3
 UP BND       X2720                2
 UP BND       X2721                5
 UP BND       X2722                6
 UP BND       X2723                5
 UP BND       X2724                3
 UP BND       X2725                7
 UP BND       X2726                4
 UP BND       X2727                1
 UP BND       X2728                5
 UP BND       X2729                0
 UP BND       X2730                3
 UP BND       X2731                1
 UP BND       X2732                1
 UP BND       X2733                2
 UP BND       X2734                2
 UP BND       X2735                5
 UP BND       X2736                3
 UP BND       X2737                6
 UP BND       X2738                8
 UP BND       X2739                3
 UP BND       X2740                3
 UP BND       X2741                3
 UP BND       X2742                2
 UP BND       X2743                1
 UP BND       X2744                6
 UP BND       X2745                3
 UP BND       X2746                3
 UP BND       X2747                1
 UP BND       X2748                3
 UP BND       X2749               12
 UP BND       X2750                0
 UP BND       X2751                4
 UP BND       X2752                2
 UP BND       X2753                4
 UP BND       X2754                9
 UP BND       X2755                3
 UP BND       X2756                1
 UP BND       X2757                0
 UP BND       X2758                5
 UP BND       X2759                2
 UP BND       X2760                6
 UP BND       X2761                0
 UP BND       X2762                9
 UP BND       X2763                3
 UP BND       X2764                9
 UP BND       X2765                3
 UP BND       X2766                3
 UP BND       X2767                2
 UP BND       X2768                1
 UP BND       X2769                4
 UP BND       X2770                2
 UP BND       X2771                5
 UP BND       X2772               11
 UP BND       X2773                2
 UP BND       X2774                9
 UP BND       X2775                0
 UP BND       X2776                0
 UP BND       X2777                3
 UP BND       X2778               10
 UP BND       X2779                2
 UP BND       X2780                3
 UP BND       X2781                9
 UP BND       X2782                2
 UP BND       X2783                1
 UP BND       X2784                5
 UP BND       X2785                3
 UP BND       X2786                2
 UP BND       X2787                2
 UP BND       X2788                5
 UP BND       X2789                0
 UP BND       X2790                9
 UP BND       X2791                1
 UP BND       X2792                1
 UP BND       X2793                4
 UP BND       X2794               12
 UP BND       X2795                0
 UP BND       X2796                2
 UP BND       X2797                2
 UP BND       X2798                7
 UP BND       X2799               11
 UP BND       X2800                4
 UP BND       X2801                1
 UP BND       X2802                4
 UP BND       X2803                3
 UP BND       X2804                6
 UP BND       X2805                0
 UP BND       X2806                7
 UP BND       X2807                4
 UP BND       X2808                7
 UP BND       X2809                3
 UP BND       X2810                6
 UP BND       X2811                5
 UP BND       X2812                3
 UP BND       X2813                2
 UP BND       X2814                6
 UP BND       X2815                2
 UP BND       X2816               11
 UP BND       X2817                6
 UP BND       X2818                6
 UP BND       X2819               11
 UP BND       X2820                7
 UP BND       X2821                0
 UP BND       X2822                2
 UP BND       X2823                5
 UP BND       X2824                0
 UP BND       X2825                9
 UP BND       X2826                5
 UP BND       X2827                6
 UP BND       X2828                5
 UP BND       X2829                1
 UP BND       X2830                3
 UP BND       X2831                1
 UP BND       X2832                1
 UP BND       X2833                9
 UP BND       X2834                1
 UP BND       X2835                3
 UP BND       X2836                2
 UP BND       X2837                6
 UP BND       X2838                1
 UP BND       X2839                9
 UP BND       X2840                1
 UP BND       X2841                1
 UP BND       X2842                8
 UP BND       X2843                3
 UP BND       X2844                4
 UP BND       X2845               12
 UP BND       X2846                9
 UP BND       X2847                8
 UP BND       X2848                0
 UP BND       X2849                6
 UP BND       X2850                1
 UP BND       X2851                6
 UP BND       X2852                1
 UP BND       X2853                2
 UP BND       X2854                4
 UP BND       X2855                4
 UP BND       X2856                2
 UP BND       X2857                2
 UP BND       X2858                5
 UP BND       X2859                3
 UP BND       X2860                3
 UP BND       X2861                2
 UP BND       X2862                6
 UP BND       X2863                0
 UP BND       X2864                2
 UP BND       X2865                0
 UP BND       X2866                7
 UP BND       X2867                2
 UP BND       X2868                0
 UP BND       X2869                4
 UP BND       X2870                8
 UP BND       X2871                6
 UP BND       X2872                3
 UP BND       X2873                3
 UP BND       X2874                0
 UP BND       X2875                0
 UP BND       X2876                9
 UP BND       X2877                2
 UP BND       X2878                5
 UP BND       X2879                0
 UP BND       X2880                8
 UP BND       X2881                1
 UP BND       X2882                1
 UP BND       X2883                5
 UP BND       X2884                4
 UP BND       X2885                8
 UP BND       X2886                1
 UP BND       X2887                2
 UP BND       X2888                0
 UP BND       X2889                2
 UP BND       X2890                8
 UP BND       X2891                1
 UP BND       X2892                9
 UP BND       X2893                8
 UP BND       X2894                9
 UP BND       X2895                9
 UP BND       X2896                6
 UP BND       X2897                8
 UP BND       X2898                4
 UP BND       X2899                8
 UP BND       X2900                5
 UP BND       X2901                0
 UP BND       X2902                4
 UP BND       X2903                1
 UP BND       X2904                0
 UP BND       X2905                7
 UP BND       X2906                7
 UP BND       X2907                9
 UP BND       X2908                3
 UP BND       X2909                0
 UP BND       X2910                0
 UP BND       X2911                2
 UP BND       X2912                1
 UP BND       X2913                0
 UP BND       X2914                8
 UP BND       X2915                0
 UP BND       X2916                0
 UP BND       X2917                1
 UP BND       X2918                6
 UP BND       X2919                9
 UP BND       X2920               10
 UP BND       X2921                1
 UP BND       X2922                1
 UP BND       X2923                7
 UP BND       X2924                2
 UP BND       X2925                7
 UP BND       X2926                7
 UP BND       X2927                6
 UP BND       X2928                5
 UP BND       X2929               12
 UP BND       X2930                2
 UP BND       X2931                3
 UP BND       X2932                7
 UP BND       X2933                1
 UP BND       X2934                6
 UP BND       X2935                4
 UP BND       X2936                1
 UP BND       X2937                6
 UP BND       X2938                2
 UP BND       X2939                7
 UP BND       X2940               11
 UP BND       X2941                5
 UP BND       X2942                2
 UP BND       X2943                2
 UP BND       X2944                1
 UP BND       X2945                7
 UP BND       X2946                8
 UP BND       X2947                3
 UP BND       X2948                0
 UP BND       X2949                5
 UP BND       X2950                1
 UP BND       X2951                3
 UP BND       X2952                8
 UP BND       X2953               10
 UP BND       X2954                1
 UP BND       X2955                3
 UP BND       X2956                2
 UP BND       X2957                2
 UP BND       X2958                0
 UP BND       X2959                7
 UP BND       X2960                1
 UP BND       X2961                7
 UP BND       X2962                2
 UP BND       X2963                3
 UP BND       X2964                2
 UP BND       X2965               10
 UP BND       X2966                5
 UP BND       X2967                4
 UP BND       X2968                2
 UP BND       X2969                0
 UP BND       X2970                7
 UP BND       X2971                2
 UP BND       X2972                0
 UP BND       X2973                3
 UP BND       X2974                3
 UP BND       X2975                4
 UP BND       X2976                2
 UP BND       X2977                0
 UP BND       X2978                3
 UP BND       X2979                0
 UP BND       X2980                3
 UP BND       X2981                8
 UP BND       X2982                2
 UP BND       X2983               11
 UP BND       X2984                3
 UP BND       X2985                8
 UP BND       X2986                1
 UP BND       X2987                2
 UP BND       X2988                8
 UP BND       X2989                3
 UP BND       X2990                3
 UP BND       X2991                3
 UP BND       X2992                6
 UP BND       X2993                5
 UP BND       X2994                3
 UP BND       X2995               12
 UP BND       X2996               10
 UP BND       X2997                7
 UP BND       X2998                4
 UP BND       X2999                6
ENDATA
